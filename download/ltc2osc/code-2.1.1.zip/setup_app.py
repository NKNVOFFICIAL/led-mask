# -*- coding: utf-8 -*-
"""Установка и автообновление LTC2OSC в Windows (без внешних установщиков).

Один и тот же LTC2OSC.exe:
  • скачали и запустили — предлагает «Установить» или «Запустить без установки»;
  • установленная копия: %LOCALAPPDATA%\\Programs\\LTC2OSC (права администратора не нужны),
    ярлыки в «Пуске» и на рабочем столе, строка в «Установленных приложениях» (удаление оттуда);
  • обновление: программа скачивает новый exe (с проверкой SHA-256) и запускает его
    с --install-silent <папка> --launch; он дожидается закрытия старой копии, заменяет её и запускает.
  • копия без установки обновляется на месте: старый exe → .old, новый на его место.
"""
import hashlib
import json
import os
import queue
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox

APP_NAME = "LTC2OSC"
PUBLISHER = "Video Land"
EXE_NAME = "LTC2OSC.exe"
REG_KEY = r"Software\Microsoft\Windows\CurrentVersion\Uninstall\LTC2OSC"
UPDATE_URL = "https://nknvofficial.github.io/led-mask/download/ltc2osc/version.json"
NO_WINDOW = 0x08000000
DETACHED = 0x00000008 | 0x00000200          # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP

C = {"bg": "#14161b", "card": "#1d2027", "fg": "#e9ebf0", "muted": "#8b91a0", "accent": "#f5b525",
     "on_accent": "#14161b", "border": "#2c3039"}


# ----------------------------------------------------------------------------
# Пути и состояние
# ----------------------------------------------------------------------------
def available():
    return sys.platform == "win32" and bool(getattr(sys, "frozen", False))


def exe_path():
    return os.path.abspath(sys.executable) if available() else ""


def default_dir():
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return os.path.join(base, "Programs", APP_NAME)


def _same(a, b):
    return os.path.normcase(os.path.abspath(a)) == os.path.normcase(os.path.abspath(b))


def installed_info():
    """{'dir', 'version'} установленной копии или None."""
    if sys.platform != "win32":
        return None
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_KEY) as k:
            d = winreg.QueryValueEx(k, "InstallLocation")[0]
            v = winreg.QueryValueEx(k, "DisplayVersion")[0]
        if d and os.path.isfile(os.path.join(d, EXE_NAME)):
            return {"dir": d, "version": v}
    except OSError:
        pass
    return None


def is_installed_run():
    exe = exe_path()
    if not exe:
        return False
    here = os.path.dirname(exe)
    inst = installed_info()
    return bool(inst and _same(inst["dir"], here)) or _same(here, default_dir())


def ver_tuple(v):
    out = []
    for p in str(v).strip().lstrip("vV").split("."):
        n = "".join(ch for ch in p if ch.isdigit())
        out.append(int(n) if n else 0)
    return tuple(out + [0] * (4 - len(out)))


def _flag_file():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    return os.path.join(base, APP_NAME, "setup.json")


def _flags():
    try:
        with open(_flag_file(), encoding="utf-8") as fh:
            d = json.load(fh)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _set_flag(key, val):
    d = _flags()
    d[key] = val
    try:
        os.makedirs(os.path.dirname(_flag_file()), exist_ok=True)
        with open(_flag_file(), "w", encoding="utf-8") as fh:
            json.dump(d, fh)
    except Exception:
        pass


# ----------------------------------------------------------------------------
# Ярлыки, реестр, копирование
# ----------------------------------------------------------------------------
def _ps(cmd):
    try:
        subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", cmd],
                       capture_output=True, timeout=30, creationflags=NO_WINDOW)
        return True
    except Exception:
        return False


def _shortcut_paths():
    appdata = os.environ.get("APPDATA") or ""
    start = os.path.join(appdata, "Microsoft", "Windows", "Start Menu", "Programs", APP_NAME + ".lnk")
    desk = os.path.join(os.path.expanduser("~"), "Desktop", APP_NAME + ".lnk")
    try:                                   # «Рабочий стол» может быть перенесён (OneDrive)
        import ctypes
        from ctypes import wintypes
        buf = ctypes.create_unicode_buffer(wintypes.MAX_PATH)
        if ctypes.windll.shell32.SHGetFolderPathW(None, 0x0010, None, 0, buf) == 0:
            desk = os.path.join(buf.value, APP_NAME + ".lnk")
    except Exception:
        pass
    return start, desk


def make_shortcut(lnk, target, workdir):
    q = lambda s: s.replace("'", "''")                                          # noqa: E731
    return _ps("$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%s');$s.TargetPath='%s';"
               "$s.WorkingDirectory='%s';$s.IconLocation='%s,0';$s.Description='%s';$s.Save()"
               % (q(lnk), q(target), q(workdir), q(target), "LTC timecode to OSC"))


def register(dst, version):
    import winreg
    exe = os.path.join(dst, EXE_NAME)
    try:
        size_kb = os.path.getsize(exe) // 1024
    except OSError:
        size_kb = 0
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, REG_KEY) as k:
        for name, val in (("DisplayName", APP_NAME), ("DisplayVersion", version), ("Publisher", PUBLISHER),
                          ("DisplayIcon", exe + ",0"), ("InstallLocation", dst),
                          ("UninstallString", '"%s" --uninstall' % exe),
                          ("QuietUninstallString", '"%s" --uninstall --quiet' % exe)):
            winreg.SetValueEx(k, name, 0, winreg.REG_SZ, val)
        winreg.SetValueEx(k, "NoModify", 0, winreg.REG_DWORD, 1)
        winreg.SetValueEx(k, "NoRepair", 0, winreg.REG_DWORD, 1)
        winreg.SetValueEx(k, "EstimatedSize", 0, winreg.REG_DWORD, int(size_kb))


def _copy_wait(src, dst, wait):
    """Копировать файл; если цель занята (старая копия ещё работает) — ждать до wait секунд."""
    deadline = time.time() + wait
    tmp = dst + ".part"
    shutil.copyfile(src, tmp)
    while True:
        try:
            if os.path.exists(dst):
                os.replace(tmp, dst)
            else:
                os.rename(tmp, dst)
            return
        except PermissionError:
            if time.time() > deadline:
                try:
                    os.remove(tmp)
                except OSError:
                    pass
                raise RuntimeError("старая версия программы всё ещё запущена — закройте её и повторите")
            time.sleep(0.5)


def install(dst, version, desktop=True, wait=0.0, src=None):
    src = src or exe_path()
    if not src:
        raise RuntimeError("установка работает только в собранной программе (LTC2OSC.exe)")
    os.makedirs(dst, exist_ok=True)
    exe = os.path.join(dst, EXE_NAME)
    if not _same(src, exe):
        _copy_wait(src, exe, wait)
    with open(os.path.join(dst, "installed.json"), "w", encoding="utf-8") as fh:
        json.dump({"version": version, "time": time.strftime("%Y-%m-%d %H:%M")}, fh)
    start, desk = _shortcut_paths()
    make_shortcut(start, exe, dst)
    if desktop:
        make_shortcut(desk, exe, dst)
    register(dst, version)
    return exe


def launch(exe, *args):
    subprocess.Popen([exe] + list(args), cwd=os.path.dirname(exe), close_fds=True, creationflags=DETACHED)


def cleanup_old():
    """После обновления копии без установки рядом остаётся LTC2OSC.exe.old — удалить."""
    exe = exe_path()
    for p in (exe + ".old", exe + ".new") if exe else ():
        try:
            if os.path.exists(p):
                os.remove(p)
        except OSError:
            pass


# ----------------------------------------------------------------------------
# Окна установки (до запуска основной программы)
# ----------------------------------------------------------------------------
def _style(root):
    sc = max(1.0, root.winfo_fpixels("1i") / 96.0)
    root.configure(bg=C["bg"])
    st = ttk.Style(root)
    try:
        st.theme_use("clam")
    except tk.TclError:
        pass
    fam = "Segoe UI" if sys.platform == "win32" else "TkDefaultFont"
    f = {"h": (fam, 15, "bold"), "b": (fam, 10), "s": (fam, 9), "bb": (fam, 10, "bold")}
    st.configure("S.TFrame", background=C["bg"])
    st.configure("S.TLabel", background=C["bg"], foreground=C["fg"], font=f["b"])
    st.configure("SMuted.TLabel", background=C["bg"], foreground=C["muted"], font=f["s"])
    st.configure("SH.TLabel", background=C["bg"], foreground=C["fg"], font=f["h"])
    st.configure("SA.TLabel", background=C["bg"], foreground=C["accent"], font=f["h"])
    st.configure("S.TCheckbutton", background=C["bg"], foreground=C["fg"], indicatorcolor=C["card"], font=f["b"])
    st.map("S.TCheckbutton", background=[("active", C["bg"])], indicatorcolor=[("selected", C["accent"])])
    st.configure("S.TButton", background=C["card"], foreground=C["fg"], bordercolor=C["border"],
                 padding=(int(14 * sc), int(7 * sc)), focuscolor=C["card"], font=f["b"])
    st.map("S.TButton", background=[("active", C["border"])])
    st.configure("SAcc.TButton", background=C["accent"], foreground=C["on_accent"], bordercolor=C["accent"],
                 padding=(int(14 * sc), int(7 * sc)), font=f["bb"], focuscolor=C["accent"])
    st.map("SAcc.TButton", background=[("active", "#ffc94d")])
    st.configure("S.TEntry", fieldbackground=C["card"], foreground=C["fg"], bordercolor=C["border"],
                 insertcolor=C["fg"])
    st.configure("S.Horizontal.TProgressbar", background=C["accent"], troughcolor=C["card"],
                 bordercolor=C["card"], lightcolor=C["accent"], darkcolor=C["accent"])
    return sc


def _window(root, title, w, h):
    root.title(title)
    root.resizable(False, False)
    sc = _style(root)
    W, H = int(w * sc), int(h * sc)
    root.update_idletasks()
    x = (root.winfo_screenwidth() - W) // 2
    y = (root.winfo_screenheight() - H) // 3
    root.geometry("%dx%d+%d+%d" % (W, H, x, y))
    box = ttk.Frame(root, style="S.TFrame", padding=(int(26 * sc), int(22 * sc)))
    box.pack(fill="both", expand=True)
    hd = ttk.Frame(box, style="S.TFrame")
    hd.pack(fill="x")
    ttk.Label(hd, text="LTC", style="SA.TLabel").pack(side="left")
    ttk.Label(hd, text="2OSC", style="SH.TLabel").pack(side="left")
    return box, sc


def _install_form(root, box, sc, version, inst, on_done, portable_text="Запустить без установки"):
    if inst:
        msg = ("Программа уже установлена (версия %s) в папку:\n%s\n\nУстановить версию %s поверх неё?"
               % (inst["version"], inst["dir"], version))
    else:
        msg = ("Версия %s. Программу можно установить — появятся ярлыки в «Пуске» и на рабочем столе, "
               "удаление через «Установленные приложения», а обновления будут ставиться сами.\n\n"
               "Или запустить без установки, как раньше." % version)
    ttk.Label(box, text=msg, style="S.TLabel", wraplength=int(520 * sc), justify="left").pack(
        anchor="w", pady=(14, 10))
    row = ttk.Frame(box, style="S.TFrame")
    row.pack(fill="x", pady=(2, 4))
    ttk.Label(row, text="Папка:", style="SMuted.TLabel").pack(side="left")
    dvar = tk.StringVar(value=(inst or {}).get("dir") or default_dir())
    ttk.Entry(row, textvariable=dvar, style="S.TEntry").pack(side="left", fill="x", expand=True, padx=(8, 6))

    def browse():
        from tkinter import filedialog
        d = filedialog.askdirectory(parent=root, initialdir=os.path.dirname(dvar.get()))
        if d:
            d = os.path.normpath(d)
            dvar.set(d if d.rstrip("\\/").endswith(APP_NAME) else os.path.join(d, APP_NAME))
    ttk.Button(row, text="Обзор…", style="S.TButton", command=browse).pack(side="left")
    desk = tk.BooleanVar(value=True)
    ttk.Checkbutton(box, text="Ярлык на рабочем столе", variable=desk, style="S.TCheckbutton").pack(
        anchor="w", pady=(6, 0))
    never = tk.BooleanVar(value=False)
    if portable_text:
        ttk.Checkbutton(box, text="Больше не предлагать установку", variable=never,
                        style="S.TCheckbutton").pack(anchor="w")
    btns = ttk.Frame(box, style="S.TFrame")
    btns.pack(side="bottom", fill="x")

    def done(r):
        on_done({"choice": r, "dir": dvar.get().strip() or default_dir(), "desktop": bool(desk.get()),
                 "never": bool(never.get())})
    ttk.Button(btns, text="Установить", style="SAcc.TButton", command=lambda: done("install")).pack(side="right")
    ttk.Button(btns, text=portable_text or "Отмена", style="S.TButton",
               command=lambda: done("portable" if portable_text else None)).pack(side="right", padx=(0, 8))
    return done


def offer(version, inst=None):
    """Первый запуск скачанного exe. -> {'choice': 'install'|'portable'|None, ...}"""
    root = tk.Tk()
    box, sc = _window(root, "Установка — " + APP_NAME, 580, 360)
    out = {}

    def fin(r):
        out.update(r)
        root.destroy()
    done = _install_form(root, box, sc, version, inst, fin)
    root.protocol("WM_DELETE_WINDOW", lambda: fin({"choice": None}))
    root.mainloop()
    return out


def run_install(version, dst, desktop=True, wait=0.0, silent=False, launch_after=True, src=None):
    """Окно с прогрессом установки. -> путь к установленному exe или None."""
    root = tk.Tk()
    box, sc = _window(root, ("Обновление — " if silent else "Установка — ") + APP_NAME, 520, 200)
    ttk.Label(box, text=("Обновление до версии %s…" if silent else "Установка версии %s…") % version,
              style="S.TLabel").pack(anchor="w", pady=(16, 8))
    pb = ttk.Progressbar(box, mode="indeterminate", style="S.Horizontal.TProgressbar")
    pb.pack(fill="x")
    pb.start(12)
    sub = ttk.Label(box, text="ожидание закрытия старой версии…" if wait else "", style="SMuted.TLabel")
    sub.pack(anchor="w", pady=(6, 0))
    res = {}

    def work():
        try:
            res["exe"] = install(dst, version, desktop=desktop, wait=wait, src=src)
        except Exception as ex:
            res["err"] = str(ex)

    th = threading.Thread(target=work, daemon=True)
    th.start()

    def poll():
        if th.is_alive():
            root.after(150, poll)
            return
        pb.stop()
        if res.get("exe"):
            pb.configure(mode="determinate", maximum=1.0, value=1.0)
            sub.configure(text="Готово.")
            root.after(500, root.destroy)
        else:
            root.destroy()
    root.after(150, poll)
    root.mainloop()
    if res.get("err"):
        r = tk.Tk()
        r.withdraw()
        messagebox.showerror(APP_NAME, "Не удалось установить:\n\n%s" % res["err"])
        r.destroy()
        return None
    if launch_after and res.get("exe"):
        launch(res["exe"])
    return res.get("exe")


def uninstall(quiet=False):
    inst = installed_info()
    d = (inst or {}).get("dir") or os.path.dirname(exe_path() or ".")
    if not quiet:
        r = tk.Tk()
        r.withdraw()
        ok = messagebox.askyesno(APP_NAME, "Удалить %s из папки\n%s?\n\nНастройки и списки команд останутся."
                                 % (APP_NAME, d))
        r.destroy()
        if not ok:
            return False
    for lnk in _shortcut_paths():
        try:
            os.remove(lnk)
        except OSError:
            pass
    try:
        import winreg
        winreg.DeleteKey(winreg.HKEY_CURRENT_USER, REG_KEY)
    except OSError:
        pass
    # сам exe удаляется после выхода (сейчас он запущен)
    bat = os.path.join(os.environ.get("TEMP") or tempfile.gettempdir(), "ltc2osc_uninstall.cmd")
    with open(bat, "w", encoding="cp866", errors="replace") as fh:
        fh.write('@echo off\r\nping -n 4 127.0.0.1 >nul\r\ndel /f /q "%s"\r\ndel /f /q "%s"\r\n'
                 'rmdir "%s"\r\ndel "%%~f0"\r\n'
                 % (os.path.join(d, EXE_NAME), os.path.join(d, "installed.json"), d))
    subprocess.Popen(["cmd", "/c", bat], creationflags=NO_WINDOW | 0x00000008, close_fds=True)
    if not quiet:
        r = tk.Tk()
        r.withdraw()
        messagebox.showinfo(APP_NAME, "Программа удалена.")
        r.destroy()
    return True


def setup_flow(version, argv):
    """Вызывается в начале main(). True — основную программу дальше не запускать."""
    if not available():
        return False
    if "--uninstall" in argv:
        uninstall(quiet="--quiet" in argv)
        return True
    if "--install-silent" in argv:                 # обновление установленной копии
        i = argv.index("--install-silent")
        dst = argv[i + 1] if i + 1 < len(argv) and not argv[i + 1].startswith("--") else default_dir()
        desk = os.path.exists(_shortcut_paths()[1])
        run_install(version, dst, desktop=desk, wait=40.0, silent=True, launch_after="--launch" in argv)
        return True
    cleanup_old()
    if is_installed_run():
        return False
    if _flags().get("no_install_offer") and "--install-offer" not in argv:
        return False
    r = offer(version, installed_info())
    if not r.get("choice"):
        return True                                # закрыли окно — выходим
    if r.get("never"):
        _set_flag("no_install_offer", True)
    if r["choice"] == "install":
        return run_install(version, r["dir"], r["desktop"]) is not None
    return False


# ----------------------------------------------------------------------------
# Изнутри работающей программы
# ----------------------------------------------------------------------------
def offer_install(app, force=True):
    """Меню «Справка → Установить…»: окно поверх программы, установка, запуск установленной копии."""
    if not available():
        messagebox.showinfo(APP_NAME, "Установка работает в собранной программе LTC2OSC.exe для Windows.",
                            parent=app.root)
        return
    ver = _app_ver()
    top = tk.Toplevel(app.root)
    top.transient(app.root)
    box, sc = _window(top, "Установка — " + APP_NAME, 580, 330)

    def fin(r):
        top.destroy()
        if r.get("choice") != "install":
            return
        try:
            exe = install(r["dir"], ver, desktop=r["desktop"])
        except Exception as ex:
            messagebox.showerror(APP_NAME, "Не удалось установить:\n\n%s" % ex, parent=app.root)
            return
        if messagebox.askyesno(APP_NAME, "Установлено в\n%s\n\nПерезапустить из установленной копии?" % r["dir"],
                               parent=app.root):
            launch(exe)
            app._on_close()
    _install_form(top, box, sc, ver, installed_info(), fin, portable_text=None)
    top.protocol("WM_DELETE_WINDOW", lambda: fin({"choice": None}))
    top.grab_set()


def _exe_ver():
    m = sys.modules.get("__main__")
    return str(getattr(m, "EXE_VER", None) or _app_ver())


def _app_ver():
    m = sys.modules.get("__main__")
    return str(getattr(m, "APP_VER", None) or getattr(sys.modules.get("ltc_to_osc"), "APP_VER", "0"))


def _log(app, text):
    try:
        app.log(text)
    except Exception:
        pass


def check_updates(app, manual=False):
    """Проверить version.json; если есть новее — спросить, скачать, заменить себя и перезапустить."""
    cur = _app_ver()
    root = app.root
    if getattr(app, "_updating", False):
        return
    if not available():
        if manual:
            messagebox.showinfo("Обновления", "Обновление изнутри работает в собранной программе "
                                "LTC2OSC.exe для Windows.\n\nТекущая версия: %s" % cur, parent=root)
        return
    q = queue.Queue()

    def fetch():
        try:
            import urllib.request
            req = urllib.request.Request(UPDATE_URL + "?t=%d" % int(time.time()),
                                         headers={"User-Agent": "LTC2OSC/" + cur, "Cache-Control": "no-cache"})
            with urllib.request.urlopen(req, timeout=10) as r:
                q.put(("info", json.loads(r.read().decode("utf-8")), None))
        except Exception as ex:
            q.put(("info", None, str(ex)))

    def poll():
        try:
            kind, a, b = q.get_nowait()
        except queue.Empty:
            root.after(200, poll)
            return
        if kind == "info":
            _on_info(a, b)
        elif kind == "prog":
            app._upd_status = "Обновление: %d%%" % int(a * 100)
            root.after(200, poll)
        elif kind == "code_done":
            app._updating = False
            _log(app, "Код %s скачан." % a)
            if messagebox.askyesno("Обновление", "Версия %s загружена. Перезапустить программу сейчас?" % a,
                                   parent=root):
                try:
                    launch(exe_path())
                except Exception as ex:
                    messagebox.showerror("Обновление", "Перезапустите программу вручную.\n%s" % ex, parent=root)
                    return
                root.after(300, app._on_close)
        elif kind == "done":
            _on_downloaded(a)
        elif kind == "fail":
            app._updating = False
            messagebox.showerror("Обновление", "Не удалось обновить:\n\n%s" % a, parent=root)

    def _on_info(j, err):
        if err or not isinstance(j, dict):
            if manual:
                messagebox.showwarning("Обновления", "Не удалось проверить обновления — нет связи с сайтом.\n\n%s"
                                       % (err or ""), parent=root)
            return
        ver = str(j.get("version", ""))          # версия exe
        it = j.get("windows") or {}
        code = j.get("code") or {}
        exe = _exe_ver()
        cver = str(code.get("version", ""))
        if code.get("url") and ver_tuple(cver) > ver_tuple(cur):
            if ver_tuple(exe) >= ver_tuple(code.get("min_exe", "0")):
                return _offer_code(code, cver, j.get("notes") or "")
            if it.get("url") and ver_tuple(ver) >= ver_tuple(code.get("min_exe", "0")) and ver_tuple(ver) > ver_tuple(exe):
                pass                                  # для нового кода нужен новый exe — ниже предложим exe
            elif manual:
                messagebox.showinfo("Обновления", "Есть версия %s, но для неё нужна новая сборка программы, "
                                    "которой пока нет на сайте. У вас %s." % (cver, cur), parent=root)
                return
        if not it.get("url") or ver_tuple(ver) <= ver_tuple(exe) or ver_tuple(ver) <= ver_tuple(cur):
            if manual:
                messagebox.showinfo("Обновления", "У вас последняя версия %s." % cur, parent=root)
            return
        later = "%s|%s" % (ver, time.strftime("%Y-%m-%d"))
        if not manual and _flags().get("update_later") == later:
            return
        notes = j.get("notes") or ""
        if not messagebox.askyesno("Обновление", "Доступна версия %s (у вас %s).\n\n%s\n\nПрограмма скачает "
                                   "новую версию, заменит себя и перезапустится. Обновить сейчас?"
                                   % (ver, cur, notes), parent=root):
            _set_flag("update_later", later)
            return
        app._updating = True
        _log(app, "Обновление: загружаю версию %s…" % ver)
        threading.Thread(target=download, args=(it["url"], str(it.get("sha256", "")).lower()),
                         daemon=True).start()
        root.after(200, poll)

    def _offer_code(code, cver, notes):
        later = "code%s|%s" % (cver, time.strftime("%Y-%m-%d"))
        if not manual and _flags().get("update_later") == later:
            return
        if not messagebox.askyesno("Обновление", "Доступна версия %s (у вас %s).\n\n%s\n\nСкачается только "
                                   "обновлённый код (быстро), потом программа перезапустится. Обновить сейчас?"
                                   % (cver, cur, notes), parent=root):
            _set_flag("update_later", later)
            return
        app._updating = True
        _log(app, "Обновление: загружаю код %s…" % cver)
        threading.Thread(target=download_code, args=(code, cver), daemon=True).start()
        root.after(200, poll)

    def download_code(code, cver):
        try:
            import urllib.request
            import zipfile
            import io
            sha = str(code.get("sha256", "")).lower()
            if not sha:
                raise RuntimeError("в описании обновления нет контрольной суммы")
            req = urllib.request.Request(code["url"], headers={"User-Agent": "LTC2OSC/" + cur, "Cache-Control": "no-cache"})
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = resp.read()
            if hashlib.sha256(data).hexdigest() != sha:
                raise RuntimeError("контрольная сумма не совпала — файл повреждён или подменён")
            m = sys.modules.get("__main__")
            dst = m.code_dir() if hasattr(m, "code_dir") else os.path.join(os.path.dirname(_flag_file()), "code")
            tmp = dst + ".new"
            shutil.rmtree(tmp, ignore_errors=True)
            os.makedirs(tmp)
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                names = [n for n in z.namelist() if n.endswith(".py") and "/" not in n and "\\" not in n]
                if "ltc_to_osc.py" not in names:
                    raise RuntimeError("в обновлении нет ltc_to_osc.py")
                for n in names:
                    with open(os.path.join(tmp, n), "wb") as fh:
                        fh.write(z.read(n))
            compile(open(os.path.join(tmp, "ltc_to_osc.py"), encoding="utf-8").read(), "ltc_to_osc.py", "exec")
            with open(os.path.join(tmp, "meta.json"), "w", encoding="utf-8") as fh:
                json.dump({"version": cver, "min_exe": str(code.get("min_exe", "0"))}, fh)
            old = dst + ".old"
            shutil.rmtree(old, ignore_errors=True)
            if os.path.isdir(dst):
                os.replace(dst, old)
            os.replace(tmp, dst)
            shutil.rmtree(old, ignore_errors=True)
            q.put(("code_done", cver, None))
        except Exception as ex:
            q.put(("fail", str(ex), None))

    def download(url, sha):
        try:
            import urllib.request
            if not sha:
                raise RuntimeError("в описании обновления нет контрольной суммы")
            new = os.path.join(tempfile.gettempdir(), "LTC2OSC-update.exe")
            h = hashlib.sha256()
            req = urllib.request.Request(url, headers={"User-Agent": "LTC2OSC/" + cur, "Cache-Control": "no-cache"})
            with urllib.request.urlopen(req, timeout=60) as resp, open(new, "wb") as out:
                total = int(resp.headers.get("Content-Length") or 0)
                done, lastp = 0, -1.0
                while True:
                    chunk = resp.read(256 * 1024)
                    if not chunk:
                        break
                    out.write(chunk)
                    h.update(chunk)
                    done += len(chunk)
                    if total and done / total - lastp >= 0.05:
                        lastp = done / total
                        q.put(("prog", lastp, None))
            if h.hexdigest() != sha:
                try:
                    os.remove(new)
                except OSError:
                    pass
                raise RuntimeError("контрольная сумма не совпала — файл повреждён или подменён")
            q.put(("done", new, None))
        except Exception as ex:
            q.put(("fail", str(ex), None))

    def _on_downloaded(new):
        exe = exe_path()
        try:
            if is_installed_run():
                # новый exe сам заменит установленную копию (дождётся закрытия этой) и запустит её
                launch(new, "--install-silent", os.path.dirname(exe), "--launch")
            else:
                # копия без установки: работающий exe можно переименовать, но не перезаписать
                old = exe + ".old"
                try:
                    if os.path.exists(old):
                        os.remove(old)
                except OSError:
                    pass
                os.replace(exe, old)
                try:
                    shutil.copyfile(new, exe)
                except Exception:
                    os.replace(old, exe)
                    raise
                launch(exe)
        except PermissionError:
            app._updating = False
            messagebox.showerror("Обновление", "Нет прав на запись в папку программы — скачайте новую "
                                 "версию вручную или установите программу.", parent=root)
            return
        except Exception as ex:
            app._updating = False
            messagebox.showerror("Обновление", "Не удалось запустить обновление:\n%s" % ex, parent=root)
            return
        _log(app, "Обновление скачано — перезапуск.")
        root.after(300, app._on_close)

    threading.Thread(target=fetch, daemon=True).start()
    root.after(200, poll)
