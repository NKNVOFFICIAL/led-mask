#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LTC -> OSC
==========
Слушает линейный таймкод (LTC) со звукового входа и отправляет
ваши OSC-команды, когда таймкод доходит до нужного момента.

Установка:
    pip install numpy sounddevice python-osc
Запуск:
    python ltc_to_osc.py
"""

import concurrent.futures
import bisect
import itertools
import json
import os
import queue
import re
import shlex
import socket
import struct
import sys
import subprocess
import threading
import time
import math
import tkinter as tk
import tkinter.font as tkfont
import urllib.request
from tkinter import ttk, messagebox, filedialog

import numpy as np
from pythonosc.udp_client import SimpleUDPClient
from pythonosc.osc_message_builder import OscMessageBuilder
try:
    import psutil                      # список сетевых адаптеров с именами
except Exception:                      # без него — только IP-адреса
    psutil = None

try:
    import serial                        # pyserial — табло на Arduino по USB
    import serial.tools.list_ports
    SERIAL_ERROR = None
except Exception as e:
    serial = None
    SERIAL_ERROR = str(e)

try:
    import sounddevice as sd
    SD_ERROR = None
except Exception as e:  # нет PortAudio и т.п. — тестовый режим всё равно работает
    sd = None
    SD_ERROR = str(e)

APP_NAME = "LTC2OSC"
IS_MAC = sys.platform == "darwin"
IS_WIN = sys.platform == "win32"


def _config_dir():
    """Папка настроек пользователя (работает и для собранных .exe / .app)."""
    if IS_WIN:
        base = os.environ.get("APPDATA") or os.path.expanduser("~")
    elif IS_MAC:
        base = os.path.expanduser("~/Library/Application Support")
    else:
        base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    d = os.path.join(base, APP_NAME)
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        d = os.path.dirname(os.path.abspath(__file__))
    return d


CONFIG_FILE = os.path.join(_config_dir(), "config.json")
PREFS_FILE = os.path.join(_config_dir(), "ui.json")     # вид программы: тема, таймлайн, рамка, размер окна
APP_VER = "2.1.1"


def load_prefs():
    try:
        with open(PREFS_FILE, encoding="utf-8") as fh:
            d = json.load(fh)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def save_prefs(d):
    try:
        with open(PREFS_FILE, "w", encoding="utf-8") as fh:
            json.dump(d, fh, ensure_ascii=False, indent=2)
    except Exception:
        pass


def resource_path(name):
    """Путь к файлу рядом с программой (и внутри собранного .exe / .app)."""
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, name)


def set_window_icon(win):
    path = resource_path("icon.png")
    if os.path.exists(path):
        try:
            win._icon_img = tk.PhotoImage(file=path)
            win.iconphoto(True, win._icon_img)
        except tk.TclError:
            pass
SCAN_WORKERS = 64 if IS_MAC else 128          # у macOS низкий лимит открытых файлов
TC_RE = re.compile(r"^\s*(\d{1,2})[:.](\d{1,2})[:.](\d{1,2})[:.;](\d{1,2})\s*$")
_ids = itertools.count(1)

RESOLUME_WEB_PORT = 8080   # веб-сервер Arena/Avenue (Preferences → Web Server)
RESOLUME_OSC_PORT = 7000   # OSC-вход Resolume по умолчанию (Preferences → OSC)
TEST_ADDRESS = "/ltc2osc/test"   # тестовая команда: видна в OSC-мониторе Resolume
TEST_ARGS = "1"


# ----------------------------------------------------------- темы оформления
# Три темы с общей раскладкой окна: «Графит» (как Volumetric Mapper), «Broadcast» (пульт, LED-цифры),
# «Студия» (глубокий синий, сине-фиолетовый акцент). Цвета — глобальные имена ниже: set_palette()
# переписывает их, а окно пересобирается (App._apply_theme).
THEMES = {
    "graphite": dict(
        name="Графит", bg="#16181d", header="#121418", card="#1f2229", stripe="#23262e", field="#16181d",
        hover="#2a2e37", border="#2c3039", fg="#e9ebf0", muted="#8b91a0", dim="#646b7a",
        accent="#f5b525", accent_hi="#ffc94a", accent_lo="#d99a10", on_accent="#16181d", accent2="#ff8a00",
        green="#3ddc84", amber="#ff9f43", red="#ff5c66", sel="#3b3420",
        next_bg="#2c2818", next_fg="#ffd166", fired_bg="#16301f",
        tc_live="#ffffff", tc_test="#ffd166", tc_colon="#f5b525", tc_ghost="#25282f",
        radius=10, fonts="graphite", caps_track=True),
    "broadcast": dict(
        name="Broadcast", bg="#09090a", header="#0d0d0f", card="#111214", stripe="#141517", field="#0b0b0d",
        hover="#1d1e21", border="#24262a", fg="#e6e6e6", muted="#9a9da4", dim="#5c5f66",
        accent="#ffb000", accent_hi="#ffc640", accent_lo="#d99500", on_accent="#111111", accent2="#ff3b30",
        green="#2bd66b", amber="#ffb000", red="#ff3b30", sel="#2a2006",
        next_bg="#1c1506", next_fg="#ffcf5a", fired_bg="#0f2a17",
        tc_live="#ffb000", tc_test="#ff8a3d", tc_colon="#ffb000", tc_ghost="#1f1808",
        radius=3, fonts="broadcast", caps_track=True),
    "studio": dict(
        name="Студия", bg="#0d1018", header="#0a0d14", card="#151a24", stripe="#181e29", field="#10141d",
        hover="#1f2633", border="#252d3b", fg="#eef1f7", muted="#8f98ad", dim="#5c657c",
        accent="#5b7cff", accent_hi="#8494ff", accent_lo="#4a62e0", on_accent="#ffffff", accent2="#9b5cff",
        green="#34d399", amber="#fbbf24", red="#f87171", sel="#27305a",
        next_bg="#211d44", next_fg="#c4b5fd", fired_bg="#12302a",
        tc_live="#ffffff", tc_test="#a5b4fc", tc_colon="#56607a", tc_ghost="#1a2030",
        radius=14, fonts="studio", caps_track=False),
}
DEFAULT_THEME = "graphite"
T = dict(THEMES[DEFAULT_THEME])


def set_palette(key):
    """Делает тему текущей: глобальные цвета и словарь T."""
    global BG, HEADER, PANEL, STRIPE, FIELD, HOVER, BORDER, FG, MUTED, DIM, ACCENT, ACCENT_HI, ACCENT_LO
    global ON_ACCENT, ACCENT2, GREEN, AMBER, RED, SEL, NEXT_BG, NEXT_FG, FIRED_BG
    T.clear()
    T.update(THEMES.get(key) or THEMES[DEFAULT_THEME])
    T["key"] = key if key in THEMES else DEFAULT_THEME
    BG, HEADER, PANEL, STRIPE, FIELD = T["bg"], T["header"], T["card"], T["stripe"], T["field"]
    HOVER, BORDER, FG, MUTED, DIM = T["hover"], T["border"], T["fg"], T["muted"], T["dim"]
    ACCENT, ACCENT_HI, ACCENT_LO, ON_ACCENT, ACCENT2 = T["accent"], T["accent_hi"], T["accent_lo"], T["on_accent"], T["accent2"]
    GREEN, AMBER, RED, SEL = T["green"], T["amber"], T["red"], T["sel"]
    NEXT_BG, NEXT_FG, FIRED_BG = T["next_bg"], T["next_fg"], T["fired_bg"]


def mix(c1, c2, k):
    """Смесь двух цветов #rrggbb: k=0 → c1, k=1 → c2."""
    a = [int(c1[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(c2[i:i + 2], 16) for i in (1, 3, 5)]
    return "#%02x%02x%02x" % tuple(int(round(a[i] + (b[i] - a[i]) * k)) for i in range(3))


set_palette(DEFAULT_THEME)

FONTS = {}

# Встроенные шрифты (лицензия SIL OFL, файлы лежат в папке fonts рядом с программой)
FONT_FILES = ["Inter-Regular.ttf", "Inter-Bold.ttf", "InterDisplay-Bold.ttf",
              "JetBrainsMono-Regular.ttf", "JetBrainsMono-Bold.ttf",
              "IBMPlexSans-Regular.ttf", "IBMPlexSans-Bold.ttf",
              "IBMPlexMono-Regular.ttf", "IBMPlexMono-Bold.ttf",
              "DSEG7Classic-Bold.ttf"]

# ключ: (название, шрифт интерфейса, шрифт таймкода, моноширинный, масштаб таймкода, «погасшие» сегменты)
FONT_THEMES = [
    ("graphite", "Графит", "Inter", "JetBrains Mono", "JetBrains Mono", 1.0, False),
    ("broadcast", "Broadcast", "IBM Plex Sans", "DSEG7 Classic", "IBM Plex Mono", 0.86, True),
    ("studio", "Студия", "Inter", "Inter Display", "JetBrains Mono", 1.08, False),
    ("led", "Пульт (LED)", "Inter", "DSEG7 Classic", "JetBrains Mono", 0.82, True),
    ("modern", "Современный", "Inter", "JetBrains Mono", "JetBrains Mono", 1.0, False),
    ("strict", "Строгий", "IBM Plex Sans", "IBM Plex Mono", "IBM Plex Mono", 1.0, False),
    ("soft", "Мягкий", "Inter", "Inter Display", "JetBrains Mono", 1.05, False),
    ("system", "Системный", None, None, None, 1.0, False),
]
DEFAULT_FONT_THEME = "modern"


def load_bundled_fonts():
    """Подключает шрифты из папки fonts только для этой программы (в систему не ставятся)."""
    d = resource_path("fonts")
    files = [os.path.join(d, f) for f in FONT_FILES if os.path.exists(os.path.join(d, f))]
    if not files:
        return
    try:
        if IS_WIN:
            import ctypes
            add = ctypes.windll.gdi32.AddFontResourceExW
            for f in files:
                add(f, 0x10, 0)                       # FR_PRIVATE
        elif IS_MAC:
            import ctypes
            cf = ctypes.cdll.LoadLibrary("/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation")
            ct = ctypes.cdll.LoadLibrary("/System/Library/Frameworks/CoreText.framework/CoreText")
            cf.CFURLCreateFromFileSystemRepresentation.restype = ctypes.c_void_p
            cf.CFURLCreateFromFileSystemRepresentation.argtypes = [ctypes.c_void_p, ctypes.c_char_p,
                                                                  ctypes.c_long, ctypes.c_bool]
            cf.CFRelease.argtypes = [ctypes.c_void_p]
            ct.CTFontManagerRegisterFontsForURL.argtypes = [ctypes.c_void_p, ctypes.c_uint32,
                                                            ctypes.c_void_p]
            ct.CTFontManagerRegisterFontsForURL.restype = ctypes.c_bool
            for f in files:
                b = f.encode("utf-8")
                url = cf.CFURLCreateFromFileSystemRepresentation(None, b, len(b), False)
                if url:
                    ct.CTFontManagerRegisterFontsForURL(url, 1, None)   # только для процесса
                    cf.CFRelease(url)
        else:
            import shutil
            import subprocess
            dst = os.path.join(os.path.expanduser("~/.local/share/fonts"), APP_NAME)
            os.makedirs(dst, exist_ok=True)
            new = False
            for f in files:
                t = os.path.join(dst, os.path.basename(f))
                if not os.path.exists(t):
                    shutil.copy(f, t)
                    new = True
            if new:
                subprocess.run(["fc-cache", "-f", dst], stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL, timeout=20)
    except Exception:
        pass


def dark_titlebar(win):
    """Тёмный заголовок окна в Windows 10/11 (на других ОС ничего не делает)."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        win.update_idletasks()
        hwnd = ctypes.windll.user32.GetParent(win.winfo_id())
        val = ctypes.c_int(1)
        for attr in (20, 19):
            if ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, attr, ctypes.byref(val),
                                                          ctypes.sizeof(val)) == 0:
                break
        color = ctypes.c_int(0x171312)          # цвет заголовка = фон окна (Windows 11), BGR
        ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 35, ctypes.byref(color),
                                                   ctypes.sizeof(color))
    except Exception:
        pass


def _pick_family(root, prefs, fallback):
    try:
        fams = set(tkfont.families(root))
    except tk.TclError:
        fams = set()
    for f in prefs:
        if f in fams:
            return f
    return fallback


def _system_families(root):
    default = tkfont.nametofont("TkDefaultFont")
    if IS_MAC:
        ui = default.actual("family")        # системный шрифт San Francisco
    else:
        ui = _pick_family(root, ["Segoe UI Variable Text", "Segoe UI", "Noto Sans",
                                 "DejaVu Sans"], default.actual("family"))
    mono = _pick_family(root, ["SF Mono", "Menlo", "Cascadia Mono", "Consolas",
                               "DejaVu Sans Mono"], "Courier")
    return ui, mono


def _init_fonts(root):
    ui, mono = _system_families(root)
    base = 13 if IS_MAC else 10

    def F(**kw):
        return tkfont.Font(root=root, **kw)

    FONTS.update(
        ui=F(family=ui, size=base),
        ui_b=F(family=ui, size=base, weight="bold"),
        small=F(family=ui, size=base - 1),
        caps=F(family=ui, size=base - 2, weight="bold"),
        title=F(family=ui, size=base + 4, weight="bold"),
        next=F(family=ui, size=base + 5, weight="bold"),
        small_b=F(family=ui, size=base - 1, weight="bold"),
        brand=F(family=ui, size=base + 1, weight="bold"),
        eta=F(family=mono, size=base + 12, weight="bold"),
        tc=F(family=mono, size=44, weight="bold"),
        mono=F(family=mono, size=base),
        mono_s=F(family=mono, size=base - 1),
    )
    apply_font_theme(root, "system")


def font_theme(key):
    for t in FONT_THEMES:
        if t[0] == key:
            return t
    return font_theme(DEFAULT_FONT_THEME)


def apply_font_theme(root, key):
    """Меняет шрифты на лету: все виджеты, использующие FONTS, обновятся сами."""
    _, _, ui, tc, mono, scale, ghost = font_theme(key)
    sys_ui, sys_mono = _system_families(root)
    try:
        fams = set(tkfont.families(root))
    except tk.TclError:
        fams = set()
    ui = ui if ui in fams else sys_ui
    mono = mono if mono in fams else sys_mono
    tc = tc if tc in fams else mono
    base = 13 if IS_MAC else 10
    compact = root.winfo_screenheight() < 860          # ноутбуки с невысоким экраном
    tc_size = (58 if IS_MAC else 44) if not compact else (44 if IS_MAC else 34)
    for name in ("ui", "ui_b", "small", "caps", "title", "next", "small_b", "brand"):
        FONTS[name].configure(family=ui)
    for name in ("mono", "mono_s"):
        FONTS[name].configure(family=mono)
    # крупный обратный отсчёт до следующей команды — шрифтом таймкода (DSEG в Broadcast)
    FONTS["eta"].configure(family=tc if key in ("broadcast", "led") else (mono if key != "studio" else tc),
                           size=(22 if IS_MAC else 17) if key not in ("broadcast", "led") else (19 if IS_MAC else 15))
    FONTS["tc"].configure(family=tc, size=int(round(tc_size * scale)))
    for name in ("TkDefaultFont", "TkTextFont", "TkMenuFont", "TkHeadingFont"):
        try:
            tkfont.nametofont(name).configure(family=ui, size=base)
        except tk.TclError:
            pass
    try:
        ttk.Style(root).configure("Treeview", rowheight=FONTS["ui"].metrics("linespace") + 14)
    except tk.TclError:
        pass
    return ghost


UI_K = 1.0          # масштаб интерфейса Windows (100 % → 1.0, 150 % → 1.5)


def px(n):
    return int(round(n * UI_K))


def _flat_button(style, name, bg, fg, hover, press, disabled_bg=None):
    disabled_bg = disabled_bg or FIELD
    style.configure(name, background=bg, foreground=fg, bordercolor=bg, lightcolor=bg,
                    darkcolor=bg, focuscolor=bg, relief="flat", padding=(px(12), px(7)),
                    font=FONTS["ui_b"], anchor="center")
    states = [("disabled", disabled_bg), ("pressed", press), ("active", hover)]
    style.map(name, background=states, bordercolor=states, lightcolor=states,
              darkcolor=states, focuscolor=states[1:], foreground=[("disabled", DIM)])


_SKIN = []          # картинки скруглений текущей темы (ссылки держим, иначе Tk их удалит)


def _skin(root, style):
    """Скруглённые кнопки, поля, флажки, карточки и чипы — картинками (ui_skin), под текущую тему."""
    import ui_skin as us
    sk = us.Skin(root)
    R = max(2, px(T["radius"] * 0.62))
    RC = max(2, px(T["radius"]))
    BW, BH = px(120), px(44)
    for nm in ("TButton", "TEntry", "TCombobox", "TSpinbox", "TCheckbutton"):
        if nm not in us._BASE:
            try:
                us._BASE[nm] = style.layout(nm)
            except tk.TclError:
                pass

    def lay(stl, base, top, el):
        b = us._BASE.get(base)
        if b is not None:
            style.layout(stl, us._replace(b, {top: el}))

    def btn(bg, fill, hover, press, border=None, bhover=None):
        return [("", us.rounded(BW, BH, R, fill, border, bg=bg)),
                ("disabled", us.rounded(BW, BH, R, mix(fill, bg, 0.55), border, bg=bg)),
                ("pressed", us.rounded(BW, BH, R, press, bhover or border, bg=bg)),
                ("active", us.rounded(BW, BH, R, hover, bhover or border, bg=bg))]
    danger_fill = mix(RED, PANEL, 0.78)
    kinds = {
        "TButton": (FIELD if T["key"] != "graphite" else HOVER, mix(HOVER, FG, 0.08), BORDER, BORDER),
        "Accent.TButton": (ACCENT, ACCENT_HI, ACCENT_LO),
        "Danger.TButton": (danger_fill, mix(danger_fill, RED, 0.25), mix(danger_fill, RED, 0.12), mix(RED, PANEL, 0.5)),
        "Ghost.TButton": (PANEL, HOVER, BORDER),
    }
    for ctx, bg in (("", PANEL), ("Bg.", BG), ("Head.", HEADER)):
        for stl, cols in kinds.items():
            el = sk.element(style, "b", btn(bg, *cols), border=R + 1, padding=(px(6), px(3)))
            for size in ("", "Small"):
                name = ctx + (size + stl if size and stl != "TButton" else ("Small.TButton" if size else stl))
                if size and stl == "Ghost.TButton":
                    continue
                lay(name, "TButton", "Button.border", el)
                style.configure(name, background=bg)
        # маленькие варианты с другими именами (старые стили программы)
        for alias, src in (("SmallPlain.TButton", "TButton"), ("SmallAccent.TButton", "Accent.TButton"),
                           ("SmallDanger.TButton", "Danger.TButton")):
            el = sk.element(style, "b", btn(bg, *kinds[src]), border=R + 1, padding=(px(6), px(2)))
            lay(ctx + alias, "TButton", "Button.border", el)
            style.configure(ctx + alias, background=bg)
    # поля ввода — на карточке и на фоне окна
    for ctx, bg in (("", PANEL), ("Bg.", BG)):
        fld = [("", us.rounded(BW * 2, BH, R, FIELD, BORDER, bg=bg)),
               ("focus", us.rounded(BW * 2, BH, R, FIELD, ACCENT, bg=bg)),
               ("disabled", us.rounded(BW * 2, BH, R, mix(FIELD, bg, 0.5), BORDER, bg=bg))]
        for stl, top in (("TEntry", "Entry.field"), ("TCombobox", "Combobox.field"), ("TSpinbox", "Spinbox.field")):
            el = sk.element(style, "f", fld, border=R + 1, padding=(px(6), px(3)))
            lay(ctx + stl, stl, top, el)
            style.configure(ctx + stl, padding=(px(4), px(2)), bordercolor=FIELD, lightcolor=FIELD, darkcolor=FIELD)
    # флажки
    CB = px(16)
    for ctx, bg in (("", BG), ("Card.", PANEL)):
        el = sk.element(style, "cb", [("", us.checkbox(CB, FIELD, BORDER, bg=bg)),
                                      ("selected", us.checkbox(CB, ACCENT, ACCENT, ON_ACCENT, bg=bg)),
                                      ("active", us.checkbox(CB, FIELD, MUTED, bg=bg))], border=0, sticky="")
        lay(ctx + "TCheckbutton", "TCheckbutton", "Checkbutton.indicator", el)
        style.configure(ctx + "TCheckbutton", indicatormargin=(0, 0, px(8), 0))
    # карточка (скруглённая, стоит на фоне окна); внутренние рамки — обычный Card.TFrame
    el = sk.element(style, "card", [("", us.rounded(px(400), px(300), RC, PANEL, BORDER, bg=BG))], border=RC + 1)
    style.layout("Box.TFrame", [(el, {"sticky": "nsew"})])
    style.configure("Box.TFrame", background=PANEL)
    # чипы-индикаторы: в шапке и на карточке
    chips = {"live": (mix(GREEN, HEADER, 0.84), GREEN), "test": (mix(ACCENT, HEADER, 0.82), ACCENT_HI),
             "nosig": (mix(AMBER, HEADER, 0.82), AMBER), "stop": (HOVER, MUTED), "plain": (HOVER, FG),
             "accent": (ACCENT, ON_ACCENT), "warn": (mix(AMBER, HEADER, 0.82), AMBER)}
    RR = px(T["radius"]) if T["key"] == "broadcast" else px(30)
    for ctx, bg in (("Head", HEADER), ("Card", PANEL)):
        for k, (fill, fg) in chips.items():
            f2 = fill if ctx == "Head" else (mix(fill, PANEL, 0.25) if k not in ("accent",) else fill)
            rr = min(RR, px(12))                 # рамка 9-slice должна быть меньше половины картинки
            el = sk.element(style, "chip", [("", us.rounded(BW, px(40), rr, f2, bg=bg))], border=rr + 1)
            name = "%sChip%s.TLabel" % (ctx, k.capitalize())
            style.layout(name, [(el, {"sticky": "nsew", "children": [
                ("Label.padding", {"sticky": "nsew", "children": [("Label.label", {"sticky": "nsew"})]})]})])
            style.configure(name, background=f2, foreground=fg, font=FONTS["small_b"], padding=(px(11), px(4)))
    # полосы прокрутки: тонкие, без стрелок
    th = sk.element(style, "thumb", [("", us.rounded(px(8), px(160), px(4), BORDER, bg=PANEL)),
                                     ("active", us.rounded(px(8), px(160), px(4), MUTED, bg=PANEL))],
                    border=(0, px(5)), sticky="nsew")
    style.layout("Vertical.TScrollbar", [("Vertical.Scrollbar.trough", {"sticky": "ns", "children": [
        (th, {"expand": "1", "sticky": "nswe"})]})])
    style.configure("Vertical.TScrollbar", troughcolor=PANEL, background=PANEL, bordercolor=PANEL,
                    lightcolor=PANEL, darkcolor=PANEL, width=px(10))
    _SKIN[:] = [sk]


def apply_dark_theme(root, theme=None):
    if theme is not None:
        set_palette(theme)
    if not FONTS:
        _init_fonts(root)
    style = ttk.Style(root)
    style.theme_use("clam")
    root.configure(bg=BG)
    style.configure(".", background=BG, foreground=FG, fieldbackground=FIELD,
                    bordercolor=BORDER, lightcolor=BG, darkcolor=BG, troughcolor=FIELD,
                    focuscolor=BG, selectbackground=SEL, selectforeground=FG,
                    insertcolor=FG, arrowcolor=MUTED, font=FONTS["ui"])
    style.configure("TFrame", background=BG)
    style.configure("Card.TFrame", background=PANEL)
    style.configure("Head.TFrame", background=HEADER)
    style.configure("TLabel", background=BG, foreground=FG)
    style.configure("Muted.TLabel", background=BG, foreground=MUTED)
    style.configure("Card.TLabel", background=PANEL, foreground=FG)
    style.configure("CardMuted.TLabel", background=PANEL, foreground=MUTED, font=FONTS["small"])
    style.configure("Caps.TLabel", background=PANEL, foreground=DIM, font=FONTS["caps"])
    style.configure("Head.TLabel", background=HEADER, foreground=FG)
    style.configure("HeadMuted.TLabel", background=HEADER, foreground=MUTED, font=FONTS["small"])

    _flat_button(style, "TButton", FIELD, FG, HOVER, BORDER)
    _flat_button(style, "Accent.TButton", ACCENT, ON_ACCENT, ACCENT_HI, ACCENT_LO)
    _flat_button(style, "Danger.TButton", mix(RED, PANEL, 0.78), RED, mix(RED, PANEL, 0.68), mix(RED, PANEL, 0.85))
    _flat_button(style, "Ghost.TButton", PANEL, MUTED, HOVER, BORDER)
    style.map("Ghost.TButton", foreground=[("disabled", DIM), ("active", FG)])
    _flat_button(style, "Small.TButton", FIELD, FG, HOVER, BORDER)
    _flat_button(style, "Link.TButton", PANEL, ACCENT_HI, PANEL, PANEL)
    style.configure("Link.TButton", padding=(0, 0), font=FONTS["small"])
    style.map("Link.TButton", foreground=[("active", FG)])
    style.configure("Small.TButton", padding=(px(10), px(4)), font=FONTS["small"])
    _flat_button(style, "SmallAccent.TButton", ACCENT, ON_ACCENT, ACCENT_HI, ACCENT_LO)
    style.configure("SmallAccent.TButton", padding=(px(9), px(5)), font=FONTS["small"])
    _flat_button(style, "SmallDanger.TButton", mix(RED, PANEL, 0.78), RED, mix(RED, PANEL, 0.68), mix(RED, PANEL, 0.85))
    style.configure("SmallDanger.TButton", padding=(px(9), px(5)), font=FONTS["small"])
    _flat_button(style, "SmallPlain.TButton", FIELD, FG, HOVER, BORDER)
    style.configure("SmallPlain.TButton", padding=(px(9), px(5)), font=FONTS["small"])
    for nm in ("Head.TButton", "Bg.TButton"):
        _flat_button(style, nm, HEADER if nm.startswith("Head") else BG, FG, HOVER, BORDER)

    for w in ("TEntry", "TCombobox", "TSpinbox"):
        style.configure(w, fieldbackground=FIELD, background=FIELD, foreground=FG,
                        insertcolor=FG, bordercolor=FIELD, lightcolor=FIELD, darkcolor=FIELD,
                        arrowcolor=MUTED, padding=px(6), relief="flat")
        style.map(w, bordercolor=[("focus", ACCENT)], lightcolor=[("focus", FIELD)],
                  arrowcolor=[("active", FG)])
    style.map("TCombobox",
              fieldbackground=[("readonly", FIELD)], foreground=[("readonly", FG)],
              selectbackground=[("readonly", FIELD)], selectforeground=[("readonly", FG)],
              background=[("active", HOVER), ("readonly", FIELD)],
              bordercolor=[("focus", ACCENT)])
    style.configure("TSpinbox", arrowsize=px(12))

    for nm, bg in (("Card.TCheckbutton", PANEL), ("TCheckbutton", BG)):
        style.configure(nm, background=bg, foreground=FG,
                        indicatorbackground=FIELD, indicatorforeground=ON_ACCENT,
                        indicatorrelief="flat", indicatormargin=(0, 0, px(8), 0), focuscolor=bg)
        style.map(nm, background=[("active", bg)],
                  indicatorbackground=[("selected", ACCENT), ("active", HOVER)])

    for name in ("Horizontal.TProgressbar", "Scan.Horizontal.TProgressbar"):
        style.configure(name, background=ACCENT, troughcolor=FIELD, bordercolor=FIELD,
                        lightcolor=ACCENT, darkcolor=ACCENT, thickness=px(6))

    rowh = FONTS["ui"].metrics("linespace") + px(16)
    style.layout("Treeview", [("Treeview.treearea", {"sticky": "nswe"})])
    style.configure("Treeview", background=PANEL, fieldbackground=PANEL, foreground=FG,
                    rowheight=rowh, borderwidth=0, font=FONTS["ui"])
    style.map("Treeview", background=[("selected", SEL)], foreground=[("selected", FG)])
    style.configure("Treeview.Heading", background=PANEL, foreground=DIM, relief="flat",
                    bordercolor=PANEL, lightcolor=PANEL, darkcolor=PANEL,
                    font=FONTS["caps"], padding=(px(8), px(8)))
    style.map("Treeview.Heading", background=[("active", PANEL)], foreground=[("active", MUTED)])

    style.layout("Vertical.TScrollbar", [("Vertical.Scrollbar.trough", {"sticky": "ns", "children":
                 [("Vertical.Scrollbar.thumb", {"expand": "1", "sticky": "nswe"})]})])
    style.configure("Vertical.TScrollbar", background=HOVER, troughcolor=PANEL,
                    bordercolor=PANEL, lightcolor=HOVER, darkcolor=HOVER, arrowsize=8,
                    gripcount=0, relief="flat")
    style.map("Vertical.TScrollbar", background=[("active", DIM)])
    try:
        _skin(root, style)
    except Exception as e:                       # без скруглений программа всё равно работает
        print("skin:", e)

    root.option_add("*TCombobox*Listbox.background", FIELD)
    root.option_add("*TCombobox*Listbox.foreground", FG)
    root.option_add("*TCombobox*Listbox.selectBackground", SEL)
    root.option_add("*TCombobox*Listbox.selectForeground", FG)
    root.option_add("*TCombobox*Listbox.font", FONTS["ui"])
    root.option_add("*TCombobox*Listbox.relief", "flat")
    root.option_add("*Menu.background", PANEL)
    root.option_add("*Menu.foreground", FG)
    root.option_add("*Menu.activeBackground", SEL)
    root.option_add("*Menu.activeForeground", FG)
    root.option_add("*Menu.relief", "flat")
    dark_titlebar(root)


def caps(text):
    """Подпись заголовка карточки: в «Графите» и «Broadcast» — капсом с разрядкой."""
    t = text.upper()
    return " ".join(t) if T["key"] == "broadcast" else t


def card(parent, title=None):
    """Карточка: скруглённая панель с тонкой рамкой. Возвращает (рамка, тело, строка заголовка)."""
    outer = ttk.Frame(parent, style="Box.TFrame", padding=max(2, px(T["radius"] * 0.45)))
    head = None
    if title:
        head = ttk.Frame(outer, style="Card.TFrame")
        head.pack(fill="x", padx=px(14), pady=(px(10), 0))
        ttk.Label(head, text=caps(title), style="Caps.TLabel").pack(side="left")
    body = ttk.Frame(outer, style="Card.TFrame")
    body.pack(fill="both", expand=True, padx=px(14), pady=(px(6) if title else px(12), px(12)))
    return outer, body, head


class VuMeter(tk.Canvas):
    """Вертикальный VU-метр входа, как на пульте: два канала, зелёный → жёлтый → красный,
    удержание пика. Канал, с которого читается LTC, подписан акцентом. Шкала −48…0 дБFS."""

    SEGMENTS = 22
    HOLD = 1.2

    def __init__(self, parent, channels=2):
        super().__init__(parent, width=px(36), height=px(60), bg=PANEL, highlightthickness=0, bd=0)
        self.n = channels
        self.lit = [0] * channels
        self.hold = [0] * channels
        self.hold_t = [0.0] * channels
        self.active = 0
        self.db = None
        self.rects = []
        self.labels = []
        self.bind("<Configure>", lambda e: self._draw())

    def _color(self, i):
        frac = i / float(self.SEGMENTS)
        return GREEN if frac < 0.68 else AMBER if frac < 0.88 else RED

    def _off(self, i):
        return mix(self._color(i), FIELD, 0.86)

    def _draw(self):
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        if h < 40:
            return
        lab_h = px(16)
        bw, gap = px(11), px(6)
        x0 = (w - (bw * self.n + gap * (self.n - 1))) / 2.0
        sg = max(1, px(2))
        seg_h = (h - lab_h - sg * (self.SEGMENTS - 1)) / float(self.SEGMENTS)
        self.rects, self.labels = [], []
        for c in range(self.n):
            x = x0 + c * (bw + gap)
            col = []
            for i in range(self.SEGMENTS):
                y1 = h - lab_h - i * (seg_h + sg)
                col.append(self.create_rectangle(x, y1 - seg_h, x + bw, y1, width=0, fill=self._off(i)))
            self.rects.append(col)
            self.labels.append(self.create_text(x + bw / 2.0, h - lab_h / 2.0 + px(2), text=str(c + 1),
                                                font=FONTS["small_b"], fill=MUTED))
        self.lit = [0] * self.n
        self._labels()
        for c in range(self.n):
            self._paint(c, 0, self.SEGMENTS)

    def _labels(self):
        for c, t in enumerate(self.labels):
            self.itemconfigure(t, fill=ACCENT if c == self.active else DIM)

    def _fill(self, c, i):
        if i < self.lit[c] or (self.hold[c] and i == self.hold[c] - 1):
            return self._color(i)
        return self._off(i)

    def _paint(self, c, lo, hi):
        if c >= len(self.rects):
            return
        for i in range(max(lo, 0), min(hi, self.SEGMENTS)):
            self.itemconfigure(self.rects[c][i], fill=self._fill(c, i))

    def set_levels(self, peaks, active=0):
        """peaks — пики каналов 0..1 (короче списка каналов — остальные 0)."""
        if active != self.active:
            self.active = active
            self._labels()
        now = time.time()
        for c in range(self.n):
            p = peaks[c] if c < len(peaks) else 0.0
            db = 20 * math.log10(p) if p > 1e-5 else None
            if c == active:
                self.db = db
            n = 0 if db is None else int(round(min(max((db + 48) / 48.0, 0.0), 1.0) * self.SEGMENTS))
            old_n, old_h = self.lit[c], self.hold[c]
            if n >= self.hold[c]:
                self.hold[c], self.hold_t[c] = n, now
            elif now - self.hold_t[c] > self.HOLD:
                self.hold[c] = max(n, self.hold[c] - 1)
            self.lit[c] = n
            if not self.rects:
                continue
            if n != old_n:
                self._paint(c, min(old_n, n), max(old_n, n))
            if old_h != self.hold[c]:
                self._paint(c, min(old_h, self.hold[c]) - 1, max(old_h, self.hold[c]))


class LevelMeter(tk.Canvas):
    """VU-метр входа LTC, как на пульте: зелёный → жёлтый → красный, с удержанием пика.
    Шкала −48…0 дБFS. Погашенные сегменты чуть подсвечены своим цветом — шкалу видно и без сигнала."""

    SEGMENTS = 40
    HOLD = 1.2            # сек удержания пика

    def __init__(self, parent, height=12):
        super().__init__(parent, height=height, bg=PANEL, highlightthickness=0, bd=0)
        self.lit = 0
        self.peak_seg = 0
        self.peak_t = 0.0
        self.db = None
        self.rects = []
        self.bind("<Configure>", lambda e: self._draw())

    def _color(self, i):
        frac = i / float(self.SEGMENTS)
        return GREEN if frac < 0.7 else AMBER if frac < 0.9 else RED

    def _off(self, i):
        return mix(self._color(i), FIELD, 0.84)

    def _draw(self):
        self.delete("all")
        w, h = self.winfo_width(), int(self["height"])
        gap = max(2, px(3))
        seg = (w - gap * (self.SEGMENTS - 1)) / float(self.SEGMENTS)
        self.rects = [self.create_rectangle(i * (seg + gap), 0, i * (seg + gap) + seg, h,
                                            width=0, fill=self._off(i)) for i in range(self.SEGMENTS)]
        self.lit = 0
        self._paint(0, self.SEGMENTS)

    def _fill(self, i):
        if i < self.lit or (self.peak_seg and i == self.peak_seg - 1):
            return self._color(i)
        return self._off(i)

    def _paint(self, lo, hi):
        for i in range(max(lo, 0), min(hi, len(self.rects))):
            self.itemconfigure(self.rects[i], fill=self._fill(i))

    def set_level(self, peak):
        """peak 0..1 → сегменты; self.db — уровень в дБFS (None — тишина)."""
        if peak <= 1e-5:
            self.db = None
            n = 0
        else:
            self.db = 20 * math.log10(peak)
            n = int(round(min(max((self.db + 48) / 48.0, 0.0), 1.0) * self.SEGMENTS))
        now = time.time()
        old_peak = self.peak_seg
        if n >= self.peak_seg:
            self.peak_seg, self.peak_t = n, now
        elif now - self.peak_t > self.HOLD:
            self.peak_seg = max(n, self.peak_seg - 1)
        self.set_lit(n, old_peak)

    def set_lit(self, n, old_peak=None):
        old = self.lit
        self.lit = n
        if not self.rects:
            return
        if n != old:
            self._paint(min(old, n), max(old, n))
        if old_peak is not None and old_peak != self.peak_seg:
            self._paint(min(old_peak, self.peak_seg) - 1, max(old_peak, self.peak_seg))


class ProgressBar(tk.Canvas):
    """Тонкая скруглённая полоса: сколько прошло от прошлой команды до следующей."""

    def __init__(self, parent, height=6):
        super().__init__(parent, height=height, bg=PANEL, highlightthickness=0, bd=0)
        self.frac = 0.0
        self.bind("<Configure>", lambda e: self._draw())

    def set(self, frac):
        frac = max(0.0, min(1.0, frac))
        w = max(1, self.winfo_width())
        if int(frac * w / 2) != int(self.frac * w / 2) or (frac in (0.0, 1.0) and frac != self.frac):
            self.frac = frac
            self._draw()

    def _round(self, x0, x1, h, fill):
        r = h / 2.0
        if x1 - x0 < h:
            x1 = x0 + h
        if T["radius"] <= 4:
            self.create_rectangle(x0, 0, x1, h, fill=fill, width=0)
            return
        self.create_oval(x0, 0, x0 + h, h, fill=fill, width=0)
        self.create_oval(x1 - h, 0, x1, h, fill=fill, width=0)
        self.create_rectangle(x0 + r, 0, x1 - r, h, fill=fill, width=0)

    def _draw(self):
        self.delete("all")
        w, h = self.winfo_width(), int(self["height"])
        if w < 4:
            return
        self._round(0, w, h, FIELD if T["key"] != "graphite" else mix(PANEL, "#000000", 0.35))
        if self.frac > 0:
            x1 = max(h, w * self.frac)
            if T["key"] == "studio":            # градиент синий → фиолетовый
                n = 24
                for k in range(n):
                    a, b = x1 * k / n, x1 * (k + 1) / n + 1
                    col = mix(ACCENT, ACCENT2, k / float(n - 1))
                    if k == 0:
                        self._round(0, max(h, b), h, col)
                    elif k == n - 1:
                        self._round(max(0, a - h / 2), x1, h, col)
                    else:
                        self.create_rectangle(a, 0, b, h, fill=col, width=0)
            else:
                self._round(0, x1, h, ACCENT)


class Timeline(tk.Canvas):
    """Таймлайн: метки команд и бегущий таймкод. Колесо — масштаб, щелчок — выбрать, двойной — открыть."""

    def __init__(self, parent, app, height=64):
        super().__init__(parent, height=height, bg=PANEL, highlightthickness=0, bd=0)
        self.app = app
        self.span = 300.0             # секунд на ширину
        self.marks = []               # (x, cue)
        self._state = None
        self._hover = None
        self.bind("<Configure>", lambda e: self.redraw(force=True))
        self.bind("<MouseWheel>", self._wheel)
        self.bind("<Button-4>", lambda e: self._zoom(0.8))
        self.bind("<Button-5>", lambda e: self._zoom(1.25))
        self.bind("<Motion>", self._motion)
        self.bind("<Leave>", lambda e: self._set_hover(None))
        self.bind("<Button-1>", self._click)
        self.bind("<Double-Button-1>", self._dbl)

    def _wheel(self, e):
        self._zoom(0.8 if e.delta > 0 else 1.25)

    def _zoom(self, k):
        self.span = max(15.0, min(4 * 3600.0, self.span * k))
        self.redraw(force=True)

    def _cue_at(self, x):
        best, bd = None, px(9)
        for mx, c in self.marks:
            d = abs(mx - x)
            if d < bd:
                best, bd = c, d
        return best

    def _motion(self, e):
        self._set_hover(self._cue_at(e.x))

    def _set_hover(self, c):
        if c is not self._hover:
            self._hover = c
            self.configure(cursor="hand2" if c else "")
            self.redraw(force=True)

    def _click(self, e):
        c = self._cue_at(e.x)
        if c is not None and self.app.tree.exists(str(c["id"])):
            self.app.tree.selection_set(str(c["id"]))
            self.app.tree.see(str(c["id"]))

    def _dbl(self, e):
        c = self._cue_at(e.x)
        if c is not None:
            self.app._open_cue(c)

    def redraw(self, force=False):
        a = self.app
        fps = max(1, a.fps)
        cur = a.cur_frames
        live = bool(a.mode and cur is not None and time.monotonic() - a.last_frame_time < 0.5)
        W0 = max(1, self.winfo_width())
        pos = None if cur is None else int(cur / float(fps) * W0 / self.span)    # сдвиг в пикселях
        key = (pos, fps, a._cues_ver, id(a.cues), self.span, live, a._row_state and a._row_state[0],
               W0, getattr(self._hover, "get", None) and id(self._hover))
        if not force and key == self._state:
            return
        tnow = time.monotonic()
        if not force and self._state and key[1:] == self._state[1:] and tnow - getattr(self, "_last_draw", 0) < 0.15:
            return                              # только прокрутка — не чаще ~6 раз в секунду
        self._last_draw = tnow
        self._state = key
        self.delete("all")
        W, H = self.winfo_width(), int(self["height"])
        if W < 40:
            return
        cues = [c for c in a.cues]
        if cur is not None:
            now = cur / float(fps)
        elif cues:
            now = tc_to_frames(cues[0]["tc"], fps) / float(fps) - self.span * 0.1
        else:
            now = 0.0
        t0 = now - self.span * 0.22
        k = W / self.span
        base = H - px(24)

        def X(sec):
            return (sec - t0) * k
        # шкала: шаг, чтобы меток было 5–9
        for step in (5, 10, 15, 30, 60, 120, 300, 600, 900, 1800, 3600):
            if self.span / step <= 9:
                break
        self.create_line(0, base, W, base, fill=BORDER)
        first = int(math.floor(t0 / step) * step)
        sec = first
        while sec <= t0 + self.span:
            x = X(sec)
            if x >= 0:
                self.create_line(x, base, x, base + px(5), fill=mix(BORDER, FG, 0.25))
                hh, rem = divmod(int(sec) % 86400, 3600)
                mm, ss = divmod(rem, 60)
                self.create_text(x, base + px(7), anchor="n", text="%02d:%02d:%02d" % (hh, mm, ss),
                                 fill=DIM, font=FONTS["mono_s"])
            sec += step
        # метки команд
        self.marks = []
        next_id = a._row_state[0] if a._row_state else None
        labels = []
        sz = px(6)
        for c in cues:
            sec = tc_to_frames(c["tc"], fps) / float(fps)
            x = X(sec)
            if x < -sz or x > W + sz:
                continue
            done = cur is not None and sec * fps <= cur
            if not c["enabled"]:
                col = mix(DIM, PANEL, 0.4)
            elif c["id"] == next_id:
                col = ACCENT2 if T["key"] == "studio" else ACCENT
            elif done:
                col = mix(DIM, PANEL, 0.15)
            else:
                col = dict((k2, cc) for k2, _, cc in CUE_COLORS if k2).get(c.get("color"), ACCENT if T["key"] != "studio" else ACCENT)
            y = base - px(14)
            if c["id"] == next_id and T["key"] != "broadcast":
                self.create_oval(x - sz * 2, y - sz * 2, x + sz * 2, y + sz * 2, fill=mix(col, PANEL, 0.75), width=0)
            if T["key"] == "broadcast":
                self.create_rectangle(x - px(2), y - sz * 1.6, x + px(2), y + sz * 1.2, fill=col, width=0)
            else:
                self.create_polygon(x, y - sz, x + sz, y, x, y + sz, x - sz, y, fill=col, outline="")
            self.marks.append((x, c))
            if c["id"] == next_id or c is self._hover:
                labels.append((0, x, c, col))
            elif not done:
                labels.append((1, x, c, col))
        # подписи: сначала следующая и под мышью, остальные — где есть место
        used = []
        for pri, x, c, col in sorted(labels, key=lambda t: (t[0], t[1])):
            txt = (c["note"] or c["address"])[:28]
            f = FONTS["small_b"] if pri == 0 else FONTS["small"]
            w = f.measure(txt) + px(10)
            x0 = min(max(0, x - w / 2), W - w)
            if any(not (x0 + w < u0 or x0 > u1) for u0, u1 in used):
                continue
            used.append((x0, x0 + w))
            self.create_text(x0 + w / 2, px(2), anchor="n", text=txt, font=f,
                             fill=FG if pri == 0 else MUTED)
        # бегущий таймкод
        if cur is not None:
            x = X(now)
            col = T["tc_live"] if live else DIM
            self.create_line(x, px(16), x, base + px(2), fill=col, width=2)
            self.create_polygon(x - px(5), px(14), x + px(5), px(14), x, px(20), fill=col, outline="")


# ------------------------------------------------- поиск Resolume в сети

_no_proxy = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def local_ipv4s():
    """IP-адреса этого компьютера в локальных сетях."""
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))     # пакеты не отправляются
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        ips.update(socket.gethostbyname_ex(socket.gethostname())[2])
    except OSError:
        pass
    return sorted(ip for ip in ips if not ip.startswith("127."))


def list_adapters():
    """Сетевые адаптеры с IPv4: [{'name', 'ip', 'mask', 'up'}]. Петлю и 169.254.* пропускаем."""
    out = []
    if psutil is not None:
        try:
            stats = psutil.net_if_stats()
            for name, addrs in psutil.net_if_addrs().items():
                for a in addrs:
                    if a.family == socket.AF_INET and a.address and not a.address.startswith(("127.", "169.254.")):
                        st = stats.get(name)
                        out.append(dict(name=name, ip=a.address, mask=a.netmask or "255.255.255.0",
                                        up=bool(st.isup) if st else True))
        except Exception:
            out = []
    if not out:
        out = [dict(name=ip, ip=ip, mask="255.255.255.0", up=True) for ip in local_ipv4s()]
    out.sort(key=lambda a: (not a["up"], a["name"].lower(), a["ip"]))
    return out


def _ip_int(ip):
    try:
        return struct.unpack("!I", socket.inet_aton(ip))[0]
    except (OSError, struct.error):
        return None


def same_subnet(ip, ad):
    a, b, m = _ip_int(ip), _ip_int(ad["ip"]), _ip_int(ad.get("mask") or "255.255.255.0")
    return None not in (a, b, m) and (a & m) == (b & m)


def subnet_hosts(ad, limit=1024):
    """Адреса подсети адаптера для поиска (большие сети — только ближайшие /22)."""
    b, m = _ip_int(ad["ip"]), _ip_int(ad.get("mask") or "255.255.255.0")
    if None in (b, m):
        return []
    size = (~m & 0xFFFFFFFF) + 1
    if size > limit:
        m = (0xFFFFFFFF << 10) & 0xFFFFFFFF
        size = limit
    net = b & m
    return [socket.inet_ntoa(struct.pack("!I", net + i)) for i in range(1, size - 1)]


class OscOut:
    """OSC по UDP через выбранные сетевые адаптеры: по сокету на каждый адрес-источник.
    sources = [None] — как решит Windows по таблице маршрутов."""

    def __init__(self, ip, port, sources=(None,)):
        self.addr = (ip, port)
        self.socks = []
        for src in sources:
            sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                sk.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                if src:
                    sk.bind((src, 0))
            except OSError:
                sk.close()
                continue
            self.socks.append(sk)
        if not self.socks:
            raise OSError("нет доступного сетевого адаптера")
        self.sources = list(sources)

    def send_message(self, address, value):
        b = OscMessageBuilder(address=address)
        if value is None:
            values = []
        elif isinstance(value, (list, tuple)):
            values = value
        else:
            values = [value]
        for v in values:
            b.add_arg(v)
        dgram = b.build().dgram
        err = None
        for sk in self.socks:
            try:
                sk.sendto(dgram, self.addr)
            except OSError as e:
                err = e
        if err is not None and len(self.socks) == 1:
            raise err

    def close(self):
        for sk in self.socks:
            try:
                sk.close()
            except OSError:
                pass


def probe_resolume(ip, port, timeout=0.4):
    """Возвращает строку вида 'Resolume Arena 7.20.1', если на ip:port отвечает Resolume."""
    try:
        with socket.create_connection((ip, port), timeout=timeout):
            pass
    except OSError:
        return None
    try:
        with _no_proxy.open("http://%s:%d/api/v1/product" % (ip, port), timeout=2) as r:
            d = json.loads(r.read(65536).decode("utf-8", "replace"))
        name = d.get("name") or ""
        if name:
            ver = ".".join(str(d[k]) for k in ("major", "minor", "micro") if k in d)
            return ("Resolume %s %s" % (name, ver)).strip()
    except Exception:
        pass
    try:   # старые версии: продукта нет, но есть композиция
        with _no_proxy.open("http://%s:%d/api/v1/composition" % (ip, port), timeout=2) as r:
            raw = r.read(65536)
        if b'"layers"' in raw or b'"columns"' in raw or b'"deck' in raw:
            return "Resolume"
    except Exception:
        pass
    return None


class ResolumeFinder(tk.Toplevel):
    """Окно поиска компьютеров с запущенным Resolume."""

    def __init__(self, app, add_mode=False):
        super().__init__(app.root)
        self.app = app
        self.title("Поиск Resolume в сети")
        self.configure(bg=BG)
        self.geometry("720x500")
        self.minsize(600, 420)
        self.transient(app.root)
        set_window_icon(self)
        self.q = queue.Queue()
        self.stop_evt = threading.Event()
        self.running = False
        self.found = 0

        wrap = ttk.Frame(self)
        wrap.pack(fill="both", expand=True, padx=18, pady=16)
        head = ttk.Frame(wrap)
        head.pack(fill="x")
        tk.Label(head, text="Поиск Resolume", font=FONTS["title"], bg=BG, fg=FG).pack(side="left")
        self.scan_btn = ttk.Button(head, text="Искать снова", style="Small.TButton", command=self.start)
        self.scan_btn.pack(side="right")
        self.web_port = tk.StringVar(value=str(RESOLUME_WEB_PORT))
        ttk.Entry(head, textvariable=self.web_port, width=6, font=FONTS["mono"]).pack(side="right", padx=8)
        ttk.Label(head, text="порт веб-сервера", style="Muted.TLabel").pack(side="right")

        self.status = ttk.Label(wrap, text="", style="Muted.TLabel")
        self.status.pack(anchor="w", pady=(10, 6))
        self.pb = ttk.Progressbar(wrap, maximum=1.0, style="Scan.Horizontal.TProgressbar")
        self.pb.pack(fill="x")

        bot = ttk.Frame(wrap)
        bot.pack(side="bottom", fill="x", pady=(12, 0))
        ttk.Button(bot, text="Сделать основным", style="Accent.TButton" if not add_mode else "TButton",
                   command=self.use).pack(side="right")
        ttk.Button(bot, text="+ Добавить к получателям", style="Accent.TButton" if add_mode else "TButton",
                   command=self.add).pack(side="right", padx=8)
        ttk.Button(bot, text="Закрыть", command=self.close).pack(side="left")

        tip = ttk.Label(wrap, style="Muted.TLabel", wraplength=660, justify="left", foreground=DIM,
                        text="Не находится? В Resolume включите Preferences → Web Server и "
                             "Preferences → OSC → OSC Input (порт %d). Компьютеры должны быть в одной "
                             "сети, а брандмауэр не должен блокировать порты." % RESOLUME_OSC_PORT)
        tip.pack(side="bottom", fill="x", pady=(10, 0))

        tc, tb, _ = card(wrap)
        tc.pack(fill="both", expand=True, pady=(12, 0))
        self.tree = ttk.Treeview(tb, columns=("ip", "host", "prod"), show="headings",
                                 selectmode="browse", height=5)
        for c, t, w in (("ip", "IP-АДРЕС", 140), ("host", "КОМПЬЮТЕР", 220), ("prod", "ПРОГРАММА", 220)):
            self.tree.heading(c, text=t, anchor="w")
            self.tree.column(c, width=w, anchor="w")
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<Double-1>", lambda e: self.add() if add_mode else self.use())

        self.protocol("WM_DELETE_WINDOW", self.close)
        dark_titlebar(self)
        self.start()
        self.after(50, self._poll)

    def start(self):
        if self.running:
            return
        try:
            port = int(self.web_port.get())
        except ValueError:
            messagebox.showerror("Порт", "Неверный порт", parent=self)
            return
        self.tree.delete(*self.tree.get_children())
        self.found = 0
        self.pb["value"] = 0
        self.stop_evt.clear()
        self.running = True
        self.scan_btn.state(["disabled"])
        threading.Thread(target=self._scan, args=(port,), daemon=True).start()

    def _scan(self, port):
        ads = [a for a in list_adapters() if a["up"]]
        if self.app.adapters:
            ads = [a for a in ads if a["ip"] in self.app.adapters] or ads
        my_ips = [a["ip"] for a in ads]
        hosts = []
        for a in ads:
            for h in subnet_hosts(a):
                if h not in hosts and h != a["ip"]:
                    hosts.append(h)
        if not hosts:
            hosts = ["127.0.0.1"]
        self.q.put(("status", "Сканирую %s (%d адресов)…" %
                    (", ".join(n + ".x" for n in nets) or "этот компьютер", len(hosts))))
        total, done = len(hosts), 0
        ex = concurrent.futures.ThreadPoolExecutor(max_workers=SCAN_WORKERS)
        futs = {ex.submit(probe_resolume, h, port): h for h in hosts}
        try:
            for fut in concurrent.futures.as_completed(futs):
                if self.stop_evt.is_set():
                    break
                done += 1
                self.q.put(("progress", done / total))
                prod = fut.result()
                if prod:
                    ip = futs[fut]
                    try:
                        host = socket.gethostbyaddr(ip)[0]
                    except OSError:
                        host = "—"
                    if ip in my_ips:
                        host += "  (этот компьютер)"
                    self.q.put(("found", ip, host, prod))
        finally:
            try:
                ex.shutdown(wait=False, cancel_futures=True)
            except TypeError:          # Python 3.7–3.8
                for f in futs:
                    f.cancel()
                ex.shutdown(wait=False)
            self.q.put(("done",))

    def _poll(self):
        if not self.winfo_exists():
            return
        while not self.q.empty():
            msg = self.q.get_nowait()
            if msg[0] == "status":
                self.status.configure(text=msg[1])
            elif msg[0] == "progress":
                self.pb["value"] = msg[1]
            elif msg[0] == "found":
                self.found += 1
                iid = self.tree.insert("", "end", values=msg[1:])
                if self.found == 1:
                    self.tree.selection_set(iid)
            elif msg[0] == "done":
                self.running = False
                self.scan_btn.state(["!disabled"])
                self.pb["value"] = 1.0
                self.status.configure(
                    text="Найдено: %d. Выберите и нажмите «Использовать»." % self.found
                    if self.found else "Resolume не найден.")
        self.after(80, self._poll)

    def use(self):
        sel = self.tree.selection()
        if not sel:
            return
        ip, host, prod = self.tree.item(sel[0], "values")
        self.app.ip_var.set(ip)
        self.app.port_var.set(str(RESOLUME_OSC_PORT))
        self.app.log("OSC → %s (%s, %s), порт %d" % (ip, host, prod, RESOLUME_OSC_PORT))
        self.close()

    def add(self):
        sel = self.tree.selection()
        if not sel:
            return
        ip, host, prod = self.tree.item(sel[0], "values")
        name = (host or ip).split(".")[0][:24].replace(",", " ")
        if self.app.add_target(ip, RESOLUME_OSC_PORT, name):
            self.status.configure(text="Добавлен: %s (%s). Можно выбрать ещё." % (name, ip))

    def close(self):
        self.stop_evt.set()
        self.destroy()


class CueDialog(tk.Toplevel):
    """Окно одной команды: все поля и дополнительные настройки."""

    def __init__(self, app, cue):
        super().__init__(app.root)
        self.app, self.cue = app, cue
        o = cue_opts(cue)
        self.title("Команда — " + (cue.get("note") or cue["address"]))
        self.configure(bg=BG)
        self.geometry("%dx%d" % (px(900), min(px(860), self.winfo_screenheight() - px(80))))
        self.minsize(px(700), px(620))
        self.transient(app.root)
        set_window_icon(self)
        outer = ttk.Frame(self)
        outer.pack(fill="both", expand=True, padx=18, pady=14)
        head = ttk.Frame(outer)
        head.pack(fill="x")
        tk.Label(head, text="Команда", font=FONTS["title"], bg=BG, fg=FG).pack(side="left")
        self.v_on = tk.BooleanVar(value=bool(cue.get("enabled", True)))
        ttk.Checkbutton(head, text="Включена", variable=self.v_on).pack(side="right")

        # ---------------- основное
        mc, mb, _ = card(outer, "ОСНОВНОЕ")
        mc.pack(fill="x", pady=(10, 0))
        g = ttk.Frame(mb, style="Card.TFrame")
        g.pack(fill="x")
        self.v_tc = tk.StringVar(value=fmt_tc(cue["tc"]))
        self.v_note = tk.StringVar(value=cue.get("note", ""))
        self.v_addr = tk.StringVar(value=cue["address"])
        self.v_args = tk.StringVar(value=cue.get("args", ""))
        self.v_type = tk.StringVar(value=dict(ARG_TYPES)[o["argtype"]])

        def lab(r, c, t):
            ttk.Label(g, text=t, style="Caps.TLabel").grid(row=r, column=c, sticky="w", pady=(6, 3))
        lab(0, 0, "ТАЙМКОД")
        lab(0, 2, "ЗАМЕТКА")
        tcrow = ttk.Frame(g, style="Card.TFrame")
        tcrow.grid(row=1, column=0, columnspan=2, sticky="w")
        ttk.Entry(tcrow, textvariable=self.v_tc, width=12, font=FONTS["mono"]).pack(side="left")
        ttk.Button(tcrow, text="◉ сейчас", style="Small.TButton", command=self._now).pack(side="left", padx=(6, 14))
        ttk.Entry(g, textvariable=self.v_note).grid(row=1, column=2, columnspan=2, sticky="we")
        lab(2, 0, "OSC-АДРЕС")
        ttk.Entry(g, textvariable=self.v_addr, font=FONTS["mono"]).grid(row=3, column=0, columnspan=4, sticky="we")
        lab(4, 0, "АРГУМЕНТЫ")
        lab(4, 2, "ТИП АРГУМЕНТОВ")
        ttk.Entry(g, textvariable=self.v_args, font=FONTS["mono"]).grid(row=5, column=0, columnspan=2, sticky="we", padx=(0, 10))
        ttk.Combobox(g, textvariable=self.v_type, state="readonly", width=18,
                     values=[t for _, t in ARG_TYPES]).grid(row=5, column=2, sticky="w")
        g.columnconfigure(1, weight=1)
        g.columnconfigure(3, weight=2)

        # куда — галочки по получателям
        lab(6, 0, "КУДА")
        self.to_frame = ttk.Frame(g, style="Card.TFrame")
        self.to_frame.grid(row=7, column=0, columnspan=4, sticky="w")
        want = split_targets(cue.get("to", ""))
        names = [t["name"] for t in app.all_targets()]
        self.v_all = tk.BooleanVar(value=("все" in want) or not [w for w in want if not parse_ip_dest(w)])
        self.v_to = []
        ttk.Checkbutton(self.to_frame, style="Card.TCheckbutton", text="Всем", variable=self.v_all, command=self._to_all).pack(side="left", padx=(0, 12))
        for n in names:
            v = tk.BooleanVar(value=n.strip().lower() in want)
            ttk.Checkbutton(self.to_frame, style="Card.TCheckbutton", text=n, variable=v, command=self._to_some).pack(side="left", padx=(0, 12))
            self.v_to.append((n, v))
        low = [n.strip().lower() for n in names]
        raw = [x.strip() for x in (cue.get("to", "") or "").replace(";", ",").split(",") if x.strip()]
        self.v_ipto = tk.StringVar(value=", ".join(x for x in raw if parse_ip_dest(x)))
        self.unknown_to = [w for w in want if w not in low and not parse_ip_dest(w)
                           and w not in ("все", "всем", "all", "*")]
        ttk.Label(self.to_frame, text="и/или IP:порт", style="CardMuted.TLabel").pack(side="left", padx=(4, 6))
        ttk.Entry(self.to_frame, textvariable=self.v_ipto, width=22, font=FONTS["mono"]).pack(side="left", padx=(0, 10))
        if self.unknown_to:
            ttk.Label(self.to_frame, text="(нет получателя: %s)" % ", ".join(self.unknown_to),
                      style="CardMuted.TLabel").pack(side="left")

        # ---------------- дополнительно
        ac, ab, _ = card(outer, "ДОПОЛНИТЕЛЬНО")
        ac.pack(fill="both", expand=True, pady=(12, 0))
        a = ttk.Frame(ab, style="Card.TFrame")
        a.pack(fill="x")
        self.v_off = tk.StringVar(value=str(o["offset_ms"]))
        self.v_rep = tk.StringVar(value=str(o["repeat"]))
        self.v_repms = tk.StringVar(value=str(o["repeat_ms"]))
        self.v_chase = tk.BooleanVar(value=bool(o["chase"]))
        self.v_color = tk.StringVar(value=dict((k, t) for k, t, _ in CUE_COLORS)[o["color"]])

        ttk.Label(a, text="Сдвиг", style="Card.TLabel").grid(row=0, column=0, sticky="w", pady=4)
        r0 = ttk.Frame(a, style="Card.TFrame")
        r0.grid(row=0, column=1, sticky="w", pady=4)
        ttk.Spinbox(r0, from_=-5000, to=5000, increment=10, textvariable=self.v_off, width=7,
                    font=FONTS["mono"]).pack(side="left")
        ttk.Label(r0, text="мс   минус — раньше таймкода, плюс — позже (компенсация задержки)",
                  style="CardMuted.TLabel").pack(side="left", padx=(8, 0))

        ttk.Label(a, text="Повтор", style="Card.TLabel").grid(row=1, column=0, sticky="w", pady=4)
        r1 = ttk.Frame(a, style="Card.TFrame")
        r1.grid(row=1, column=1, sticky="w", pady=4)
        ttk.Label(r1, text="отправить", style="Card.TLabel").pack(side="left")
        ttk.Spinbox(r1, from_=1, to=20, textvariable=self.v_rep, width=4, font=FONTS["mono"]).pack(side="left", padx=6)
        ttk.Label(r1, text="раз(а) через", style="Card.TLabel").pack(side="left")
        ttk.Spinbox(r1, from_=1, to=5000, increment=10, textvariable=self.v_repms, width=6,
                    font=FONTS["mono"]).pack(side="left", padx=6)
        ttk.Label(r1, text="мс  — надёжнее по Wi-Fi", style="CardMuted.TLabel").pack(side="left")

        ttk.Label(a, text="Перемотка", style="Card.TLabel").grid(row=2, column=0, sticky="w", pady=4)
        ttk.Checkbutton(a, style="Card.TCheckbutton", text="срабатывать, если таймкод перескочил вперёд через команду",
                        variable=self.v_chase).grid(row=2, column=1, sticky="w", pady=4)

        ttk.Label(a, text="Цвет строки", style="Card.TLabel").grid(row=3, column=0, sticky="w", pady=4)
        ttk.Combobox(a, textvariable=self.v_color, state="readonly", width=14,
                     values=[t for _, t, _ in CUE_COLORS]).grid(row=3, column=1, sticky="w", pady=4)
        a.columnconfigure(1, weight=1)

        eh = ttk.Frame(ab, style="Card.TFrame")
        eh.pack(fill="x", pady=(12, 4))
        ttk.Label(eh, text=caps("Ещё адреса — уходят вместе с этой командой"), style="Caps.TLabel").pack(side="left")
        ttk.Button(eh, text="+  Добавить адрес", style="SmallAccent.TButton",
                   command=lambda: self._add_extra(focus=True)).pack(side="right")
        self.ex_names = [SAME_TO, "все"] + names
        wrap = tk.Frame(ab, bg=PANEL)
        wrap.pack(fill="both", expand=True)
        self.ex_canvas = tk.Canvas(wrap, bg=PANEL, highlightthickness=0, bd=0, height=px(150))
        sb = ttk.Scrollbar(wrap, orient="vertical", command=self.ex_canvas.yview)
        self.ex_canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.ex_canvas.pack(side="left", fill="both", expand=True)
        self.ex_box = ttk.Frame(self.ex_canvas, style="Card.TFrame")
        self._ex_win = self.ex_canvas.create_window(0, 0, window=self.ex_box, anchor="nw")
        self.ex_box.bind("<Configure>", lambda e: self.ex_canvas.configure(scrollregion=self.ex_canvas.bbox("all")))
        self.ex_canvas.bind("<Configure>", lambda e: self.ex_canvas.itemconfigure(self._ex_win, width=e.width))
        wheel = lambda e: self.ex_canvas.yview_scroll(int(-e.delta / 120) or (-1 if e.delta > 0 else 1), "units")
        wrap.bind("<Enter>", lambda e: self.ex_canvas.bind_all("<MouseWheel>", wheel))
        wrap.bind("<Leave>", lambda e: self.ex_canvas.unbind_all("<MouseWheel>"))
        for c, (t, w) in enumerate((("МС", 0), ("OSC-АДРЕС", 3), ("АРГУМЕНТЫ", 1), ("КУДА", 2), ("", 0))):
            ttk.Label(self.ex_box, text=caps(t) if t else "", style="Caps.TLabel").grid(
                row=0, column=c, sticky="w", padx=(0, px(6)), pady=(0, px(3)))
            self.ex_box.columnconfigure(c, weight=w)
        self.ex_rows = []
        for e in o["extra"]:
            self._add_extra(e)
        self.ex_hint = ttk.Label(ab, style="CardMuted.TLabel", justify="left",
                                 text="«Куда»: «как у команды», «все», имя получателя или прямо IP:порт, "
                                      "например 192.168.1.50:7000. Можно несколько через запятую.")
        self.ex_hint.pack(anchor="w", pady=(6, 0), side="bottom", before=wrap)

        # ---------------- кнопки
        btns = ttk.Frame(outer)
        btns.pack(fill="x", pady=(12, 0), side="bottom", before=mc)     # кнопки всегда видны
        ttk.Button(btns, text="Сохранить", style="Accent.TButton", command=self.save).pack(side="left")
        ttk.Button(btns, text="▶  Тест", command=self.test).pack(side="left", padx=6)
        self.msg = ttk.Label(btns, text="", style="Muted.TLabel")
        self.msg.pack(side="left", padx=8)
        ttk.Button(btns, text="Закрыть", command=self.destroy).pack(side="right")
        self.bind("<Escape>", lambda e: self.destroy())
        self.bind("<Control-Return>" if not IS_MAC else "<Command-Return>", lambda e: self.save())
        self.protocol("WM_DELETE_WINDOW", self.destroy)
        dark_titlebar(self)

    def _add_extra(self, e=None, focus=False):
        e = e or {}
        r = len(self.ex_rows) + 1
        row = dict(d=tk.StringVar(value=str(e.get("delay_ms", 0) or 0)),
                   a=tk.StringVar(value=e.get("address", "/composition/")),
                   g=tk.StringVar(value=e.get("args", "")),
                   t=tk.StringVar(value=e.get("to") or SAME_TO))
        w = [ttk.Spinbox(self.ex_box, from_=0, to=600000, increment=100, textvariable=row["d"], width=7,
                         font=FONTS["mono"]),
             ttk.Entry(self.ex_box, textvariable=row["a"], font=FONTS["mono"], width=20),
             ttk.Entry(self.ex_box, textvariable=row["g"], font=FONTS["mono"], width=8),
             ttk.Combobox(self.ex_box, textvariable=row["t"], values=self.ex_names, width=18)]
        w.append(ttk.Button(self.ex_box, text="×", style="Small.TButton", width=3,
                            command=lambda: self._del_extra(row)))
        for c, x in enumerate(w):
            x.grid(row=r, column=c, sticky="we", padx=(0, px(6)), pady=px(2))
        row["w"] = w
        self.ex_rows.append(row)
        if focus:
            w[1].focus_set()
            w[1].icursor("end")
            self.after(50, lambda: self.ex_canvas.yview_moveto(1.0))
        return row

    def _del_extra(self, row):
        for x in row["w"]:
            x.destroy()
        self.ex_rows.remove(row)
        for i, rw in enumerate(self.ex_rows, 1):
            for c, x in enumerate(rw["w"]):
                x.grid(row=i, column=c)

    def _collect_extra(self):
        out, errs = [], []
        for n, rw in enumerate(self.ex_rows, 1):
            addr = rw["a"].get().strip()
            if addr in ("", "/", "/composition/"):
                continue                                # пустая строка — пропускаем
            if not addr.startswith("/") or " " in addr:
                errs.append("строка %d: адрес должен начинаться с / и быть без пробелов" % n)
                continue
            try:
                d = int(float(rw["d"].get() or 0))
            except ValueError:
                errs.append("строка %d: «через» — число миллисекунд" % n)
                continue
            if not 0 <= d <= 600000:
                errs.append("строка %d: задержка от 0 до 600000 мс" % n)
                continue
            to = rw["t"].get().strip()
            if to in ("", SAME_TO):
                to = ""
            elif to.lower() not in ("все", "всем", "all", "*"):
                known = [x.strip().lower() for x in self.ex_names]
                bad = [x.strip() for x in to.replace(";", ",").split(",")
                       if x.strip() and not parse_ip_dest(x) and x.strip().lower() not in known]
                if bad:
                    errs.append("строка %d: «Куда» — нет получателя «%s» (впишите имя или IP:порт)" % (n, bad[0]))
                    continue
            out.append(clean_extra(dict(delay_ms=d, address=addr, args=rw["g"].get().strip(), to=to)))
        return out, errs

    def _now(self):
        a = self.app
        if a.cur_frames is not None:
            self.v_tc.set(fmt_tc(frames_to_tc(a.cur_frames, a.fps)))

    def _to_all(self):
        if self.v_all.get():
            for _, v in self.v_to:
                v.set(False)

    def _to_some(self):
        self.v_all.set(not any(v.get() for _, v in self.v_to))

    def _collect(self):
        """Поля → словарь команды или None (с сообщением об ошибке)."""
        tc = parse_tc(self.v_tc.get())
        if tc is None:
            messagebox.showerror("Таймкод", "Таймкод в формате ЧЧ:ММ:СС:КК, например 00:01:30:12", parent=self)
            return None
        addr = self.v_addr.get().strip()
        if not addr.startswith("/") or len(addr) < 2 or " " in addr:
            messagebox.showerror("OSC-адрес", "Адрес должен начинаться с / и быть без пробелов", parent=self)
            return None
        try:
            off = int(float(self.v_off.get() or 0))
            rep = int(float(self.v_rep.get() or 1))
            repms = int(float(self.v_repms.get() or 40))
        except ValueError:
            messagebox.showerror("Числа", "Сдвиг и повтор — целые числа", parent=self)
            return None
        if not -60000 <= off <= 60000 or not 1 <= rep <= 20 or not 1 <= repms <= 5000:
            messagebox.showerror("Числа", "Сдвиг: от −60000 до 60000 мс\nПовтор: от 1 до 20 раз, интервал 1–5000 мс",
                                 parent=self)
            return None
        extra, errs = self._collect_extra()
        if errs:
            messagebox.showerror("Ещё адреса", "\n".join(errs[:8]), parent=self)
            return None
        ips = [x.strip() for x in self.v_ipto.get().replace(";", ",").split(",") if x.strip()]
        bad = [x for x in ips if not parse_ip_dest(x)]
        if bad:
            messagebox.showerror("Куда", "«%s» — не похоже на IP:порт, например 192.168.1.50:7000" % bad[0], parent=self)
            return None
        ips = ["%s:%d" % parse_ip_dest(x) for x in ips]
        if self.v_all.get() and not ips:
            to = ""
        elif self.v_all.get():
            to = ", ".join(["все"] + ips)
        else:
            to = ", ".join([n for n, v in self.v_to if v.get()] + self.unknown_to + ips)
        argtype = next(k for k, t in ARG_TYPES if t == self.v_type.get())
        color = next(k for k, t, _ in CUE_COLORS if t == self.v_color.get())
        return dict(tc=tc, note=self.v_note.get().strip(), address=addr, args=self.v_args.get().strip(),
                    to=to, enabled=bool(self.v_on.get()), offset_ms=off, repeat=rep, repeat_ms=repms,
                    argtype=argtype, extra=extra, color=color, chase=bool(self.v_chase.get()))

    def save(self):
        new = self._collect()
        if new is None:
            return
        if self.cue not in self.app.cues:            # команду удалили, пока окно было открыто
            messagebox.showwarning("Команда", "Этой команды уже нет в списке.", parent=self)
            return
        self.app._apply_cue_edit(self.cue, new)
        self.app.log("Команда сохранена: %s %s" % (fmt_tc(new["tc"]), new["note"] or new["address"]))
        self.destroy()

    def test(self):
        new = self._collect()
        if new is None:
            return
        self.app._send_cue(new, manual=True)
        self.msg.configure(text="отправлено в %s" % time.strftime("%H:%M:%S"))


class AdaptersDialog(tk.Toplevel):
    """Через какие сетевые адаптеры слать OSC (один или несколько)."""

    def __init__(self, app):
        super().__init__(app.root)
        self.app = app
        self.title("Сетевые адаптеры")
        self.configure(bg=BG)
        self.transient(app.root)
        set_window_icon(self)
        wrap = ttk.Frame(self)
        wrap.pack(fill="both", expand=True, padx=px(18), pady=px(16))
        tk.Label(wrap, text="Сетевые адаптеры", font=FONTS["title"], bg=BG, fg=FG).pack(anchor="w")
        ttk.Label(wrap, style="Muted.TLabel", wraplength=px(560), justify="left",
                  text="Через какие сети отправлять команды. Если не выбрано ничего — как решит Windows. "
                       "Получателю из подсети адаптера команды идут через этот адаптер; "
                       "остальным — через все отмеченные сразу (дублирование по нескольким сетям). "
                       "«Найти Resolume» ищет в сетях отмеченных адаптеров.").pack(anchor="w", pady=(px(6), px(10)))
        c, self.box, _ = card(wrap)
        c.pack(fill="both", expand=True)
        self.v_auto = tk.BooleanVar(value=not app.adapters)
        self.vars = []
        btns = ttk.Frame(wrap)
        btns.pack(fill="x", pady=(px(12), 0))
        ttk.Button(btns, text="Готово", style="Accent.TButton", command=self.ok).pack(side="left")
        ttk.Button(btns, text="Обновить список", command=lambda: self.fill(True)).pack(side="left", padx=px(6))
        ttk.Button(btns, text="Отмена", command=self.destroy).pack(side="right")
        self.fill()
        self.bind("<Escape>", lambda e: self.destroy())
        dark_titlebar(self)

    def fill(self, refresh=False):
        for w in self.box.winfo_children():
            w.destroy()
        if refresh:
            self.app._ad_t = -99
        ads = self.app._adapters_now()
        chosen = set(self.app.adapters) if not self.vars else {ip for ip, v in self.vars if v.get()}
        ttk.Checkbutton(self.box, text="Авто — как решит Windows", style="Card.TCheckbutton",
                        variable=self.v_auto, command=self._auto).pack(anchor="w", pady=(0, px(6)))
        self.vars = []
        known = set()
        for a in ads:
            v = tk.BooleanVar(value=a["ip"] in chosen)
            known.add(a["ip"])
            row = ttk.Frame(self.box, style="Card.TFrame")
            row.pack(fill="x", pady=px(2))
            ttk.Checkbutton(row, text=a["name"], style="Card.TCheckbutton", variable=v,
                            command=self._some).pack(side="left")
            bits = bin(_ip_int(a["mask"]) or 0).count("1")
            ttk.Label(row, text="%s/%d%s" % (a["ip"], bits, "" if a["up"] else "  · отключён"),
                      style="CardMuted.TLabel", font=FONTS["mono_s"]).pack(side="right")
            self.vars.append((a["ip"], v))
        for ip in sorted(chosen - known):          # выбранный раньше, но сейчас его нет
            v = tk.BooleanVar(value=True)
            row = ttk.Frame(self.box, style="Card.TFrame")
            row.pack(fill="x", pady=px(2))
            ttk.Checkbutton(row, text="(нет в системе)", style="Card.TCheckbutton", variable=v,
                            command=self._some).pack(side="left")
            ttk.Label(row, text=ip, style="CardMuted.TLabel", font=FONTS["mono_s"]).pack(side="right")
            self.vars.append((ip, v))
        if not ads:
            ttk.Label(self.box, text="Сетевых адаптеров с IPv4 не найдено", style="CardMuted.TLabel").pack(anchor="w")
        self.update_idletasks()
        self.geometry("%dx%d" % (max(px(600), self.winfo_reqwidth()), self.winfo_reqheight()))

    def _auto(self):
        if self.v_auto.get():
            for _, v in self.vars:
                v.set(False)

    def _some(self):
        self.v_auto.set(not any(v.get() for _, v in self.vars))

    def ok(self):
        self.app.set_adapters([] if self.v_auto.get() else [ip for ip, v in self.vars if v.get()])
        self.destroy()


class TargetsDialog(tk.Toplevel):
    """Несколько компьютеров с Resolume: имя, IP, порт, вкл/выкл."""

    def __init__(self, app):
        super().__init__(app.root)
        self.app = app
        self.title("Получатели OSC")
        self.configure(bg=BG)
        self.geometry("700x470")
        self.minsize(600, 400)
        self.transient(app.root)
        set_window_icon(self)
        wrap = ttk.Frame(self)
        wrap.pack(fill="both", expand=True, padx=18, pady=16)
        head = ttk.Frame(wrap)
        head.pack(fill="x")
        tk.Label(head, text="Получатели OSC", font=FONTS["title"], bg=BG, fg=FG).pack(side="left")
        ttk.Button(head, text="Найти в сети…", style="Small.TButton",
                   command=lambda: app._find_resolume(add=True)).pack(side="right")
        ttk.Label(wrap, style="Muted.TLabel", wraplength=640, justify="left",
                  text="Команда без пометки «Куда» уходит всем включённым получателям. "
                       "Чтобы отправить только на часть компьютеров, впишите в столбец «Куда» "
                       "их имена через запятую, например:  Экран 1, Свет").pack(anchor="w", pady=(8, 10))

        tc, tb, _ = card(wrap)
        tc.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(tb, columns=("on", "name", "ip", "port"), show="headings",
                                 selectmode="browse", height=6)
        for c, t, w, st in (("on", "", 34, False), ("name", "ИМЯ", 200, True),
                            ("ip", "IP-АДРЕС", 160, True), ("port", "ПОРТ", 80, False)):
            self.tree.heading(c, text=t, anchor="w")
            self.tree.column(c, width=w, anchor="center" if c == "on" else "w", stretch=st)
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", lambda e: self._pick())

        form = ttk.Frame(wrap)
        form.pack(fill="x", pady=(12, 0))
        self.v_name, self.v_ip, self.v_port = tk.StringVar(), tk.StringVar(), tk.StringVar(value=str(RESOLUME_OSC_PORT))
        for col, (lab, var, w, mono) in enumerate((("ИМЯ", self.v_name, 18, False), ("IP", self.v_ip, 16, True),
                                                   ("ПОРТ", self.v_port, 7, True))):
            ttk.Label(form, text=lab, style="Caps.TLabel").grid(row=0, column=col, sticky="w")
            ttk.Entry(form, textvariable=var, width=w, font=FONTS["mono"] if mono else None).grid(
                row=1, column=col, sticky="we", padx=(0, 8))
        form.columnconfigure(0, weight=2)
        form.columnconfigure(1, weight=2)
        btns = ttk.Frame(wrap)
        btns.pack(fill="x", pady=(10, 0))
        for text, style, cmd, side in (("+  Добавить", "Accent", self.add, "left"), ("Сохранить", "", self.save, "left"),
                                       ("Вкл / Выкл", "", self.toggle, "left"), ("Тест", "", self.test, "left"),
                                       ("Удалить", "Danger", self.delete, "right")):
            ttk.Button(btns, text=text, style=(style + ".TButton") if style else "TButton",
                       command=cmd).pack(side=side, padx=(0, 6))
        self.protocol("WM_DELETE_WINDOW", self.destroy)
        dark_titlebar(self)
        self.refresh()

    def refresh(self, select=None):
        self.tree.delete(*self.tree.get_children())
        for i, t in enumerate(self.app.all_targets()):
            self.tree.insert("", "end", iid=str(i), values=("●" if t["on"] else "○", t["name"] + ("  (основной)" if i == 0 else ""),
                                                            t["ip"], t["port"]))
        if select is not None and self.tree.exists(str(select)):
            self.tree.selection_set(str(select))

    def _sel(self):
        s = self.tree.selection()
        return int(s[0]) if s else None

    def _pick(self):
        i = self._sel()
        if i is None:
            return
        t = self.app.all_targets()[i]
        self.v_name.set(t["name"])
        self.v_ip.set(t["ip"])
        self.v_port.set(str(t["port"]))

    def _form(self):
        name, ip = self.v_name.get().strip(), self.v_ip.get().strip()
        try:
            port = int(self.v_port.get())
            assert 0 < port < 65536
        except Exception:
            messagebox.showerror("Порт", "Порт — число от 1 до 65535 (у Resolume обычно %d)" % RESOLUME_OSC_PORT, parent=self)
            return None
        if not ip:
            messagebox.showerror("IP", "Впишите IP-адрес компьютера с Resolume", parent=self)
            return None
        if not name:
            name = "Resolume %d" % (len(self.app.all_targets()) + 1)
        if "," in name or name.startswith("@"):
            messagebox.showerror("Имя", "В имени не должно быть запятых и знака @", parent=self)
            return None
        return dict(name=name, ip=ip, port=port)

    def add(self):
        f = self._form()
        if f:
            self.app.add_target(f["ip"], f["port"], f["name"])
            self.refresh(len(self.app.all_targets()) - 1)

    def save(self):
        i, f = self._sel(), self._form()
        if i is None or not f:
            return
        self.app.set_target(i, **f)
        self.refresh(i)

    def toggle(self):
        i = self._sel()
        if i is not None:
            t = self.app.all_targets()[i]
            self.app.set_target(i, on=not t["on"])
            self.refresh(i)

    def delete(self):
        i = self._sel()
        if i is not None:
            if self.app._ask_remove_target(i, parent=self):
                self.refresh()

    def test(self):
        i = self._sel()
        if i is not None:
            self.app._send_test(only=i)


# ------------------------------------------------- табло на Arduino (USB)

# производители USB-переходников, которые стоят на Arduino / ESP32
USB_SERIAL_VIDS = {0x1A86: "CH340", 0x0403: "FTDI", 0x2341: "Arduino", 0x2A03: "Arduino",
                   0x10C4: "CP210x", 0x303A: "ESP32", 0x239A: "Adafruit"}


def _short_port(dev):
    return os.path.basename(dev) if dev and dev.startswith("/dev/") else (dev or "")


class DisplayLink:
    """Связь с табло: держит USB-соединение, переподключается, отправляет таймкод."""

    BAUD = 115200

    def __init__(self, app):
        self.app = app
        self.target = "off"          # "off" / "auto" / имя порта
        self.status = ("off", "выкл")
        self.ser = None
        self.port = None
        self.ready_at = 0.0
        self._last = {}
        self._stop = threading.Event()
        self._wake = threading.Event()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    @staticmethod
    def ports():
        """[(устройство, описание, vid)] — подходящие последовательные порты."""
        if serial is None:
            return []
        out = []
        try:
            found = serial.tools.list_ports.comports()
        except Exception:
            return []
        for p in found:
            dev = p.device or ""
            if IS_MAC and (dev.startswith("/dev/tty.") or "Bluetooth" in dev or "debug-console" in dev):
                continue                 # на Mac используем /dev/cu.*
            desc = p.description if p.description and p.description != "n/a" else ""
            out.append((dev, desc, p.vid))
        return out

    def _auto_port(self):
        for dev, desc, vid in self.ports():
            if vid in USB_SERIAL_VIDS or any(k in dev.lower() for k in ("usbserial", "wchusb", "usbmodem", "ttyusb", "ttyacm")):
                return dev
        return None

    def set_target(self, target):
        if target != self.target:
            self.target = target
            self._close()
            self._wake.set()

    def _close(self):
        ser, self.ser = self.ser, None
        if ser is not None:
            try:
                ser.close()
            except Exception:
                pass

    def close(self):
        self._stop.set()
        self._wake.set()
        self._close()

    def messages(self, now):
        """Строки для табло (только изменившиеся; медленные — и раз в секунду для надёжности)."""
        tc, st, fps, name, eta = self.app._display_state()
        out = []
        last = self._last
        slow = now - last.get("slow", 0) >= 1.0
        t_line = "T%s|%s|%s" % (tc, st, eta)
        if t_line != last.get("T") or now - last.get("T_at", 0) >= 0.4:
            out.append(t_line)
            last["T"], last["T_at"] = t_line, now
        for key, val in (("F", fps), ("N", name)):
            if val != last.get(key) or slow:
                out.append(key + val)
                last[key] = val
        if slow:
            last["slow"] = now
        return out

    def _run(self):
        next_try = 0.0
        while not self._stop.is_set():
            if self.target == "off" or serial is None:
                self.status = ("off", "выкл" if serial is not None else "нет модуля pyserial")
                self._wake.wait(0.5)
                self._wake.clear()
                continue
            now = time.monotonic()
            if self.ser is None:
                if now < next_try:
                    self._stop.wait(0.1)
                    continue
                port = self._auto_port() if self.target == "auto" else self.target
                if not port:
                    self.status = ("wait", "ищу Arduino… подключите USB")
                    next_try = now + 1.5
                    continue
                try:
                    self.ser = serial.serial_for_url(port, self.BAUD, timeout=0, write_timeout=0.3)
                    self.port = port
                    self.ready_at = now + 2.0        # Arduino Nano/Uno перезагружается при подключении
                    self._last = {}
                    self.status = ("wait", "подключаюсь к %s…" % _short_port(port))
                except Exception as e:
                    self.ser = None
                    self.status = ("err", "%s: занят или недоступен" % _short_port(port))
                    next_try = now + 2.0
                    continue
            if now < self.ready_at:
                self._stop.wait(0.05)
                continue
            try:
                msgs = self.messages(now)
                if msgs:
                    self.ser.write(("\n".join(msgs) + "\n").encode("utf-8"))
                if self.ser.in_waiting:
                    self.ser.read(self.ser.in_waiting)   # приветствие табло — не нужно
                self.status = ("ok", "подключено: %s" % _short_port(self.port))
            except Exception:
                self._close()
                self.status = ("err", "табло отключено — жду переподключения")
                next_try = now + 1.5
                continue
            self._stop.wait(0.01)


# ------------------------------------------------------------------ утилиты

def parse_tc(text):
    """'01:02:03:04' -> (1, 2, 3, 4) или None"""
    m = TC_RE.match(text or "")
    if not m:
        return None
    h, mi, s, f = (int(g) for g in m.groups())
    if h > 23 or mi > 59 or s > 59 or f > 29:
        return None
    return h, mi, s, f


def tc_to_frames(tc, fps):
    h, m, s, f = tc
    return ((h * 60 + m) * 60 + s) * fps + min(f, fps - 1)


def frames_to_tc(n, fps):
    n %= 24 * 3600 * fps
    s, f = divmod(n, fps)
    return s // 3600, (s // 60) % 60, s % 60, f


# Частоты кадров LTC: ключ, подпись, кадров в секунде таймкода, реальная частота, drop-frame
RATES = [
    ("auto", "Авто (по сигналу)", None, None, False),
    ("23.976", "23.976", 24, 24000 / 1001.0, False),
    ("24", "24", 24, 24.0, False),
    ("25", "25", 25, 25.0, False),
    ("29.97df", "29.97 DF", 30, 30000 / 1001.0, True),
    ("29.97", "29.97 ND", 30, 30000 / 1001.0, False),
    ("30", "30", 30, 30.0, False),
]
RATE_HELP = {
    "auto": "частота определяется по сигналу",
    "23.976": "кино в NTSC-странах (24 с замедлением 0,1%)",
    "24": "кино",
    "25": "PAL/SECAM, Россия и Европа",
    "29.97df": "NTSC, drop-frame: в начале минуты пропускаются кадры 00 и 01",
    "29.97": "NTSC, non-drop",
    "30": "30 кадров",
}


def rate_info(key):
    for r in RATES:
        if r[0] == key:
            return r
    return RATES[0]


DF_PER_10MIN = 17982        # кадров за 10 минут в 29.97 drop-frame
DF_PER_DAY = 24 * 6 * DF_PER_10MIN


def tc_to_index(tc, fps, df=False):
    """Таймкод → порядковый номер кадра с 00:00:00:00 (с учётом drop-frame)."""
    if not df:
        return tc_to_frames(tc, fps)
    h, m, s, f = tc
    tm = 60 * h + m
    return (3600 * h + 60 * m + s) * 30 + min(f, 29) - 2 * (tm - tm // 10)


def index_to_tc(n, fps, df=False):
    """Порядковый номер кадра → таймкод (с учётом drop-frame)."""
    if not df:
        return frames_to_tc(n, fps)
    n %= DF_PER_DAY
    d, r = divmod(n, DF_PER_10MIN)
    n += 18 * d + (2 * ((r - 2) // 1798) if r >= 2 else 0)
    return (n // 108000) % 24, (n // 1800) % 60, (n // 30) % 60, n % 30


def fmt_tc_df(tc, df):
    """Drop-frame принято писать с «;» перед кадрами: 00:01:00;02."""
    return ("%02d:%02d:%02d;%02d" if df else "%02d:%02d:%02d:%02d") % tuple(tc)


def fmt_tc(tc):
    return "%02d:%02d:%02d:%02d" % tuple(tc)


TC_TOKEN_RE = re.compile(r"^\d{1,2}[:.]\d{1,2}[:.]\d{1,2}[:.;]\d{1,2}$")


def _split_fields(line):
    """Строка таблицы → поля. Табуляция (Excel/Google Таблицы), «;» или «,» (CSV)."""
    if "\t" in line:
        return [f.strip() for f in line.split("\t")]
    for sep in (";", ","):
        if sep in line:
            parts = [f.strip().strip('"') for f in line.split(sep)]
            # CSV, только если в одном из полей есть таймкод или адрес целиком
            if any(TC_TOKEN_RE.match(f) or (f.startswith("/") and " " not in f) for f in parts):
                return parts
    return None


def parse_cues_text(text, default_tc=(0, 0, 0, 0)):
    """
    Разбирает команды из буфера обмена. Понимает:
      00:01:30:12  /composition/columns/1/connect  1   # заметка
      00:01:30:12 <TAB> Заметка <TAB> /адрес <TAB> аргументы      (Excel, любой порядок столбцов)
      00:01:30:12;/адрес;1;Заметка                               (CSV)
      /адрес 1                                                   (без таймкода — берётся default_tc)
    Возвращает (список команд, число пропущенных строк).
    """
    cues, skipped = [], 0
    for raw in (text or "").replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        line = raw.strip()
        if not line or line.startswith("//"):
            continue
        tc = addr = None
        args, note, to = "", "", ""
        fields = _split_fields(line)
        if fields is not None:
            tof = [f for f in fields if f.startswith("@") and len(f) > 1]
            if tof:
                to = tof[0][1:].strip()
                fields = [f for f in fields if f not in tof]
            ai = next((i for i, f in enumerate(fields) if f.startswith("/") and len(f) > 1), None)
            ti = next((i for i, f in enumerate(fields) if TC_TOKEN_RE.match(f)), None)
            if ai is None:
                skipped += 1            # например, строка заголовков
                continue
            addr = fields[ai].split()[0]
            rest_addr = fields[ai][len(addr):].strip()
            tc = parse_tc(fields[ti]) if ti is not None else None
            others = [(i, f) for i, f in enumerate(fields) if i not in (ai, ti) and f]
            after = [f for i, f in others if i > ai]
            before = [f for i, f in others if i < ai]
            args = " ".join(([rest_addr] if rest_addr else []) + after[:1])
            note = " ".join(before + after[1:])
        else:
            body, _, note = line.partition(" # ")
            if not note and "\t" not in body and " — " in body:
                body, _, note = body.partition(" — ")
            tokens = body.split()
            tot = [t for t in tokens if t.startswith("@") and len(t) > 1]
            if tot:
                to = ",".join(t[1:] for t in tot)
                tokens = [t for t in tokens if t not in tot]
            ti = next((i for i, t in enumerate(tokens) if TC_TOKEN_RE.match(t)), None)
            ai = next((i for i, t in enumerate(tokens) if t.startswith("/") and len(t) > 1), None)
            if ai is None:
                skipped += 1
                continue
            tc = parse_tc(tokens[ti]) if ti is not None else None
            addr = tokens[ai]
            args = " ".join(t for i, t in enumerate(tokens) if i > ai and i != ti)
            pre = " ".join(t for i, t in enumerate(tokens) if i < ai and i != ti)
            note = (pre + " " + note).strip() if pre else note.strip()
        if tc is None and ti is not None:
            skipped += 1                # таймкод был, но неправильный (например, 25:00:00:00)
            continue
        cues.append(dict(tc=tuple(tc or default_tc), address=addr, args=args.strip(), note=note.strip(), to=to))
    return cues, skipped


def cues_to_text(cues):
    """Команды → текст для буфера: столбцы через табуляцию (вставляется в Excel и обратно)."""
    return "\n".join("\t".join((fmt_tc(c["tc"]), c["note"], c["address"], c["args"])
                               + (("@" + c["to"],) if c.get("to") else ())) for c in cues)


def split_targets(text):
    """'Экран 1, Свет' -> ['экран 1', 'свет'];  '' / 'все' -> [] (значит — всем)."""
    t = (text or "").strip()
    if t.lower() in ("", "все", "всем", "all", "*"):
        return []
    return [x.strip().lower() for x in t.replace(";", ",").split(",") if x.strip()]


def parse_osc_args(text):
    """'1 0.5 hello "два слова" true' -> [1, 0.5, 'hello', 'два слова', True]"""
    try:
        tokens = shlex.split(text)
    except ValueError:
        tokens = text.split()
    out = []
    for t in tokens:
        if t.lower() in ("true", "false"):
            out.append(t.lower() == "true")
            continue
        for conv in (int, float):
            try:
                out.append(conv(t))
                break
            except ValueError:
                pass
        else:
            out.append(t)
    return out


# ------------------------------------------------------------ доп. настройки команды
CUE_OPT_DEFAULTS = dict(offset_ms=0, repeat=1, repeat_ms=40, argtype="auto", extra=(), color="", chase=False)
ARG_TYPES = (("auto", "Авто"), ("int", "Целое (int)"), ("float", "Дробное (float)"),
             ("string", "Текст (string)"), ("bool", "Да / нет (bool)"))
CUE_COLORS = (("", "Обычный", None), ("red", "Красный", "#ff6b73"), ("amber", "Жёлтый", "#f5c451"),
              ("green", "Зелёный", "#5fe39a"), ("blue", "Синий", "#7fb0ff"), ("purple", "Фиолетовый", "#c39bff"))


def cue_opts(c):
    """Доп. настройки команды со значениями по умолчанию."""
    o = {k: c.get(k, v) for k, v in CUE_OPT_DEFAULTS.items()}
    o["extra"] = list(o["extra"] or [])
    return o


def cue_has_opts(c):
    o = cue_opts(c)
    return any(o[k] != (list(v) if isinstance(v, tuple) else v) for k, v in CUE_OPT_DEFAULTS.items() if k != "color")


def typed_osc_args(text, argtype="auto"):
    """Аргументы с принудительным типом: Resolume, например, ждёт float для прозрачности."""
    vals = parse_osc_args(text)
    if argtype == "auto":
        return vals
    out = []
    for v in vals:
        try:
            if argtype == "int":
                out.append(int(float(v)) if not isinstance(v, bool) else int(v))
            elif argtype == "float":
                out.append(float(v))
            elif argtype == "bool":
                out.append(v if isinstance(v, bool) else str(v).lower() not in ("0", "0.0", "", "false", "нет", "off"))
            else:
                out.append("true" if v is True else "false" if v is False else str(v))
        except (TypeError, ValueError):
            out.append(v)
    return out


IP_DEST_RE = re.compile(r"^\s*(\d{1,3}(?:\.\d{1,3}){3}|[A-Za-z0-9][A-Za-z0-9.-]*\.local)\s*(?::\s*(\d{1,5}))?\s*$")
SAME_TO = "как у команды"


def parse_ip_dest(tok, default_port=7000):
    """'192.168.1.20:7000' / '192.168.1.20' → ('192.168.1.20', 7000) или None."""
    m = IP_DEST_RE.match(tok or "")
    if not m:
        return None
    ip, port = m.group(1), int(m.group(2) or default_port)
    if not 0 < port < 65536 or ("." in ip and ip[0].isdigit() and any(int(x) > 255 for x in ip.split("."))):
        return None
    return ip, port


def parse_extra_lines(text):
    """Доп. команды, по одной в строке:  [+мс] /адрес аргументы.  → (список, [ошибки])"""
    out, errs = [], []
    for n, raw in enumerate((text or "").splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        delay = 0
        tok = line.split(None, 1)
        if tok[0].startswith("+") or tok[0].lstrip("-").isdigit():
            try:
                delay = int(float(tok[0].lstrip("+").replace("мс", "").replace("ms", "")))
            except ValueError:
                errs.append("строка %d: задержка «%s» — не число" % (n, tok[0]))
                continue
            line = tok[1].strip() if len(tok) > 1 else ""
        addr, _, args = line.partition(" ")
        if not addr.startswith("/") or len(addr) < 2:
            errs.append("строка %d: адрес должен начинаться с /" % n)
            continue
        if delay < 0 or delay > 600000:
            errs.append("строка %d: задержка от 0 до 600000 мс" % n)
            continue
        out.append(dict(delay_ms=delay, address=addr, args=args.strip()))
    return out, errs


def clean_extra(e):
    d = dict(delay_ms=max(0, int(e.get("delay_ms", 0) or 0)), address=str(e["address"]), args=str(e.get("args", "")))
    to = str(e.get("to", "") or "").strip()
    if to and to != SAME_TO:
        d["to"] = to
    return d


def extra_to_text(extra):
    return "\n".join(("+%d " % e["delay_ms"] if e.get("delay_ms") else "") + e["address"] +
                     (" " + e["args"] if e.get("args") else "") for e in extra or [])


# ------------------------------------------------------------ декодер LTC

class LTCDecoder:
    """
    Декодер LTC (SMPTE 12M): бифазный код, 80 бит на кадр,
    синхрослово 0011111111111101 в конце кадра.
    Работает на 24/25/30 (29.97) fps и любой частоте дискретизации.
    """
    SYNC = 0x3FFD

    def __init__(self, samplerate, on_frame):
        self.sr = samplerate
        self.on_frame = on_frame
        self.state = 1
        self.count = 0
        self.bit_len = samplerate / 2150.0    # оценка длины бита в сэмплах
        self.min_len = samplerate / 2600.0
        self.max_len = samplerate / 1800.0
        self.half_pending = False
        self.reg = 0
        self.nbits = 0
        self.peak = 0.0
        self.samples = 0          # сколько сэмплов уже обработано (для измерения частоты)
        self._pos = 0

    def process(self, x):
        if len(x) == 0:
            return
        x = np.asarray(x, dtype=np.float32)
        p = float(np.max(np.abs(x)))
        self.peak = max(p, self.peak * 0.9)
        h = max(self.peak * 0.15, 0.004)       # гистерезис против шума
        if self.peak < 0.004:                  # тишина (≈ −48 дБ) — нечего декодировать
            self.count = min(self.count + len(x), 10 * self.sr)
            self.half_pending = False
            self.samples += len(x)
            return

        s = np.zeros(len(x), dtype=np.int8)
        s[x > h] = 1
        s[x < -h] = -1
        idx = np.where(s != 0, np.arange(len(s)), -1)
        np.maximum.accumulate(idx, out=idx)
        filled = np.where(idx >= 0, s[np.clip(idx, 0, None)], self.state)
        prev = np.concatenate(([self.state], filled[:-1]))
        trans = np.nonzero(filled != prev)[0]
        # шум вместо LTC (таймкод остановили, а на линии фон): переходов гораздо больше,
        # чем бывает в LTC — не гоняем их по одному в Python, иначе окно подтормаживает
        if len(trans) > 3 + 1.5 * len(x) / (self.min_len * 0.5):
            self.state = int(filled[-1])
            self.count = len(x) - int(trans[-1])
            self.half_pending = False
            self.samples += len(x)
            return

        last = 0
        base = self.samples
        for t in trans:
            self._pos = base + int(t)
            self._edge(self.count + int(t) - last)
            self.count = 0
            last = int(t)
        self.count = min(self.count + len(x) - last, 10 * self.sr)
        self.state = int(filled[-1])
        self.samples += len(x)

    def _edge(self, n):
        if n < self.min_len * 0.3 or n > self.max_len * 1.5:
            self.half_pending = False          # помеха или пауза
            return
        if n < self.bit_len * 0.75:            # половина бита
            self._adapt(2 * n)
            if self.half_pending:
                self.half_pending = False
                self._bit(1)
            else:
                self.half_pending = True
        else:                                  # целый бит
            self._adapt(n)
            self.half_pending = False
            self._bit(0)

    def _adapt(self, n):
        bl = 0.95 * self.bit_len + 0.05 * n
        self.bit_len = min(max(bl, self.min_len), self.max_len)

    def _bit(self, b):
        self.reg = ((self.reg << 1) | b) & ((1 << 80) - 1)
        self.nbits += 1
        if self.nbits >= 80 and (self.reg & 0xFFFF) == self.SYNC:
            self._decode()

    def _get(self, start, n):
        v = 0
        for k in range(n):
            v |= ((self.reg >> (79 - (start + k))) & 1) << k
        return v

    def _decode(self):
        ff = self._get(0, 4) + 10 * self._get(8, 2)
        ss = self._get(16, 4) + 10 * self._get(24, 3)
        mm = self._get(32, 4) + 10 * self._get(40, 3)
        hh = self._get(48, 4) + 10 * self._get(56, 2)
        drop = bool(self._get(10, 1))
        if ff > 29 or ss > 59 or mm > 59 or hh > 23:
            return
        self.on_frame(hh, mm, ss, ff, drop, self._pos)


# ------------------------------------------------------------- приложение

class App:
    def __init__(self, root):
        self.root = root
        root.title("LTC2OSC")
        self.prefs = load_prefs()
        self.theme = self.prefs.get("theme") if self.prefs.get("theme") in THEMES else DEFAULT_THEME
        apply_dark_theme(root, self.theme)
        sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
        geo = self.prefs.get("geometry")
        if isinstance(geo, str) and re.match(r"^\d+x\d+[+-]-?\d+[+-]-?\d+$", geo):
            root.geometry(geo)
        else:
            w, h = min(px(1440), sw - px(60)), min(px(900), sh - px(80))
            root.geometry("%dx%d+%d+%d" % (w, h, max(0, (sw - w) // 2), max(0, (sh - h) // 3)))
        root.minsize(px(860), px(600))
        self._log_hist = []
        self._api_names = {}
        self.project_path = self.prefs.get("project")

        self.cues = []
        self.fps = 25
        self.drop = False
        self.fps_mode = "auto"       # выбранная частота (ключ из RATES)
        self.sig_fps = 25            # что пришло в сигнале
        self.sig_drop = False
        self._period_ema = None      # средняя длительность кадра по звуку, с
        self._period_n = 0
        self._last_pos = None
        self._last_idx = None
        self._mismatch_logged = None
        self.last_raw_f = None
        self.cur_frames = None
        self.prev_frames = None
        self.last_frame_time = 0.0
        self.client = None
        self.main_name = "Resolume 1"
        self.extra_targets = []          # [{name, ip, port, on}]
        self._clients = {}               # (ip, port, адаптеры) -> OscOut
        self.adapters = [str(x) for x in (self.prefs.get("adapters") or []) if _ip_int(str(x)) is not None]
        self._out = []                   # [(target, client)] — включённые и правильные
        self.send_tc = False
        self.tc_address = "/ltc"
        self.devices = []
        self.saved_device = None
        self.audio_started = 0.0
        self.silence_hint = False
        self.fired = {}             # id команды -> время срабатывания (для подсветки)
        self._sched = ([], [], 0, 0, 0)  # (кадры, команды, fps, …) — отсортированное расписание
        self._cues_ver = 0
        self._ui = {}               # последние значения виджетов: не перерисовываем лишнее
        self._row_index = {}
        self._undo = []             # снимки списка команд для Ctrl+Z
        self._row_state = None
        self._slow_t = 0.0
        self._status = None
        self.font_key = DEFAULT_FONT_THEME
        self.tc_max = 60


        self.log_q = queue.Queue()
        self.audio_q = queue.Queue(maxsize=200)
        self.mode = None            # None / "audio" / "test"
        self.stream = None
        self.decoder = None
        self.stop_evt = threading.Event()
        self.worker = None

        self._make_vars()
        self._build_ui()
        old = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ltc_osc_config.json")
        self._load_config(CONFIG_FILE if os.path.exists(CONFIG_FILE) else old, quiet=True)
        self._set_font_theme(THEMES[self.theme]["fonts"])
        if not self.log_var.get():
            self._toggle_log(False)
        self._refresh_disp_ports()
        self._refresh_devices()
        self._update_target()
        if SD_ERROR:
            self.log("Звуковой вход недоступен: %s. Работает только тест." % SD_ERROR)
        root.protocol("WM_DELETE_WINDOW", self._on_close)
        root.after(40, self._tick)
        threading.Thread(target=self._watchdog, daemon=True).start()
        root.after(30, self._go_frameless)
        if self.autoupd_var.get():
            root.after(3000, lambda: self.check_updates(manual=False))

    # ---------------------------------------------------------------- UI
    def _make_vars(self):
        """Переменные полей живут всё время работы — окно при смене темы пересобирается, значения остаются."""
        self.f_tc = tk.StringVar(value="00:00:00:00")
        self.f_addr = tk.StringVar(value="/")
        self.f_args = tk.StringVar()
        self.f_note = tk.StringVar()
        self.f_to = tk.StringVar(value="все")
        self.ip_var = tk.StringVar(value="127.0.0.1")
        self.port_var = tk.StringVar(value="8000")
        self.send_tc_var = tk.BooleanVar(value=False)
        self.tc_addr_var = tk.StringVar(value="/ltc")
        self.test_addr_var = tk.StringVar(value=TEST_ADDRESS)
        self.test_args_var = tk.StringVar(value=TEST_ARGS)
        self.chan_var = tk.IntVar(value=1)
        self.ch_peaks = []
        self.dev_var = tk.StringVar()
        self.disp_var = tk.StringVar()
        self.fps_var = tk.StringVar(value="auto")
        self.theme_var = tk.StringVar(value=self.theme)
        self.timeline_var = tk.BooleanVar(value=self.prefs.get("timeline", True))
        self.log_var = tk.BooleanVar(value=self.prefs.get("log", True))
        self.native_var = tk.BooleanVar(value=bool(self.prefs.get("native_frame", False)))
        self.autoupd_var = tk.BooleanVar(value=bool(self.prefs.get("auto_update", True)))
        for v in (self.ip_var, self.port_var, self.send_tc_var, self.tc_addr_var):
            v.trace_add("write", lambda *a: self._update_target())

    # ---------------------------------------------------------------- UI
    def _build_ui(self):
        root = self.root
        frameless = self._frameless_wanted()
        outer = tk.Frame(root, bg=BORDER if frameless else BG, bd=0, highlightthickness=0)
        outer.pack(fill="both", expand=True)
        self.outer = outer
        shell = tk.Frame(outer, bg=BG, bd=0, highlightthickness=0)
        shell.pack(fill="both", expand=True, padx=1 if frameless else 0, pady=1 if frameless else 0)
        self._build_titlebar(shell, frameless)

        wrap = ttk.Frame(shell)
        wrap.pack(fill="both", expand=True, padx=px(14), pady=(px(12), px(14)))
        self.wrap = wrap
        G = px(12)

        # ---------- главный блок: таймкод · следующая команда · кнопки
        hero, hb, _ = card(wrap)
        hero.pack(fill="x")
        self.hero_body = hb
        hb.columnconfigure(0, weight=1)
        left = ttk.Frame(hb, style="Card.TFrame")
        left.grid(row=0, column=0, sticky="nsw")
        top = ttk.Frame(left, style="Card.TFrame")
        top.pack(fill="x")
        ttk.Label(top, text=caps("Таймкод"), style="Caps.TLabel").pack(side="left")
        self.fps_label = ttk.Label(top, text="АВТО ▾", style="CardChipPlain.TLabel", cursor="hand2")
        self.fps_label.pack(side="left", padx=(px(12), 0))
        self.fps_label.bind("<Button-1>", self._show_rate_menu)
        self.rate_menu = tk.Menu(self.root, tearoff=0, bg=PANEL, fg=FG, activebackground=SEL,
                                 activeforeground=FG, selectcolor=ACCENT, bd=0, relief="flat", font=FONTS["ui"])
        for key, label, *_ in RATES:
            if key == "23.976":
                self.rate_menu.add_separator()
            self.rate_menu.add_radiobutton(
                label=("%s fps — %s" % (label, RATE_HELP[key])) if key != "auto" else label + " — " + RATE_HELP[key],
                value=key, variable=self.fps_var, command=self._on_rate_chosen)
        self.tc_canvas = tk.Canvas(left, bg=PANEL, highlightthickness=0, bd=0, width=10, height=10)
        self.tc_canvas.pack(anchor="w", pady=(px(6), 0))
        self.tc_cells = []
        self._tc_str = getattr(self, "_tc_str", None) or "--:--:--:--"
        self._tc_fill = DIM
        self.src_label = ttk.Label(left, text="", style="CardMuted.TLabel")
        self.src_label.pack(anchor="w", pady=(px(2), 0))

        nxt = ttk.Frame(hb, style="Card.TFrame")
        nxt.grid(row=0, column=1, sticky="nsew", padx=(px(28), px(24)))
        self.next_box = nxt
        self._next_shown = True
        self.next_cap = ttk.Label(nxt, text=caps("Следующая команда"), style="Caps.TLabel")
        self.next_cap.pack(anchor="w")
        self.next_name = tk.Label(nxt, text="—", font=FONTS["next"], bg=PANEL, fg=FG, anchor="w", width=26)
        self.next_name.pack(anchor="w", pady=(px(6), 0))
        self.next_eta = tk.Label(nxt, text="", font=FONTS["eta"], bg=PANEL, fg=ACCENT, anchor="w", width=10)
        self.next_eta.pack(anchor="w", pady=(px(2), 0))
        self.next_bar = ProgressBar(nxt, height=px(6))
        self.next_bar.pack(fill="x", pady=(px(10), 0))

        ctl = ttk.Frame(hb, style="Card.TFrame")
        ctl.grid(row=0, column=2, sticky="nse")
        self.ctl_box = ctl
        cap = (lambda t: t) if T["key"] == "broadcast" else caps
        ttk.Label(ctl, text=cap("ВХОД"), style="Caps.TLabel").grid(row=0, column=0, sticky="w")
        self.meter = VuMeter(ctl)
        self.meter.grid(row=1, column=0, rowspan=4, sticky="ns", padx=(0, px(16)), pady=(px(6), 0))
        ttk.Label(ctl, text=cap("ИСТОЧНИК"), style="Caps.TLabel").grid(row=0, column=1, sticky="w")
        self.src_dev = ttk.Label(ctl, text="—", style="Card.TLabel", width=24)
        self.src_dev.grid(row=1, column=1, sticky="w", pady=(px(6), 0))
        self.src_lvl = tk.Label(ctl, text="", font=FONTS["small"], bg=PANEL, fg=MUTED, anchor="w", width=24)
        self.src_lvl.grid(row=2, column=1, sticky="w", pady=(px(2), px(10)))
        self.start_btn = ttk.Button(ctl, text="▶  Старт приёма", style="Accent.TButton", width=18,
                                    command=self._toggle_audio)
        self.start_btn.grid(row=3, column=1, sticky="we")
        self.test_btn = ttk.Button(ctl, text="Тест без LTC", width=18, command=self._toggle_test)
        self.test_btn.grid(row=4, column=1, sticky="we", pady=(px(8), 0))
        self._fit_job = None
        hb.bind("<Configure>", lambda e: self._schedule_fit())

        # ---------- таймлайн
        self.tl_card, tlb, tlh = card(wrap, "Таймлайн")
        ttk.Label(tlh, text="колесо — масштаб  ·  щелчок по метке — выбрать, двойной — открыть",
                  style="CardMuted.TLabel").pack(side="right")
        self.timeline = Timeline(tlb, self, height=px(72))
        self.timeline.pack(fill="x")
        self.tl_anchor = ttk.Frame(wrap, height=1)
        self.tl_anchor.pack(fill="x")
        if self.timeline_var.get():
            self.tl_card.pack(fill="x", pady=(G, 0), before=self.tl_anchor)

        # ---------- низ: команды слева, колонка справа
        main = ttk.Frame(wrap)
        main.pack(fill="both", expand=True, pady=(G, 0))
        main.columnconfigure(0, weight=1)
        main.columnconfigure(1, weight=0, minsize=px(330))
        main.rowconfigure(0, weight=1)
        self._build_cues(main)
        side = ttk.Frame(main, width=px(330))
        side.grid(row=0, column=1, sticky="nsew", padx=(G, 0))
        self.side = side
        self._build_side(side, G)
        if frameless:
            self._add_grips()
        root.bind_all("<Control-o>", lambda e: (self._open(), "break")[1], add="+")
        root.bind_all("<Control-n>", lambda e: (self._new_project(), "break")[1], add="+")
        root.bind_all("<Control-s>", lambda e: (self._save(), "break")[1], add="+")
        root.bind_all("<Control-S>", lambda e: (self._save_as(), "break")[1], add="+")

    # ---------------------------------------------------------- шапка окна
    def _frameless_wanted(self):
        return IS_WIN and not self.native_var.get() and not getattr(self, "_no_frameless", False)

    def _build_titlebar(self, parent, frameless):
        H = px(44)
        bar = tk.Frame(parent, bg=HEADER, height=H, bd=0, highlightthickness=0)
        bar.pack(fill="x")
        bar.pack_propagate(False)
        self.titlebar = bar
        tk.Frame(parent, bg=BORDER, height=1).pack(fill="x")
        logo = tk.Canvas(bar, width=px(26), height=px(26), bg=HEADER, highlightthickness=0, bd=0)
        logo.pack(side="left", padx=(px(14), px(10)))
        self._draw_logo(logo, px(26))
        name = tk.Label(bar, text="LTC2OSC", font=FONTS["brand"], bg=HEADER, fg=FG)
        name.pack(side="left")
        self.proj_label = tk.Label(bar, text="", font=FONTS["small"], bg=HEADER, fg=MUTED)
        self.proj_label.pack(side="left", padx=(px(10), 0))
        self._update_proj_label()
        menus = tk.Frame(bar, bg=HEADER)
        menus.pack(side="left", padx=(px(22), 0))
        self._menu_btns = []
        for title, builder in (("Файл", self._menu_file), ("Команды", self._menu_cues),
                               ("Получатели", self._menu_targets), ("Вид", self._menu_view),
                               ("Справка", self._menu_help)):
            lb = tk.Label(menus, text=title, font=FONTS["ui"], bg=HEADER, fg=MUTED, padx=px(11), pady=px(5), cursor="hand2")
            lb.pack(side="left", padx=(0, px(2)))
            lb.bind("<Enter>", lambda e, w=lb: w.configure(bg=HOVER, fg=FG))
            lb.bind("<Leave>", lambda e, w=lb: w.configure(bg=HEADER, fg=MUTED))
            lb.bind("<Button-1>", lambda e, w=lb, b=builder: self._popup_menu(w, b))
            self._menu_btns.append(lb)
        if frameless:
            wb = tk.Frame(bar, bg=HEADER)
            wb.pack(side="right", fill="y")
            for sym, cmd, hot in (("✕", self._on_close, RED), ("▢", self._toggle_max, HOVER), ("—", self._minimize, HOVER)):
                b = tk.Label(wb, text=sym, font=FONTS["ui"], bg=HEADER, fg=MUTED, width=4, cursor="hand2")
                b.pack(side="right", fill="y")
                b.bind("<Enter>", lambda e, w=b, h=hot: w.configure(bg=h, fg="#ffffff" if h == RED else FG))
                b.bind("<Leave>", lambda e, w=b: w.configure(bg=HEADER, fg=MUTED))
                b.bind("<ButtonRelease-1>", lambda e, c=cmd: c())
        chips = tk.Frame(bar, bg=HEADER)
        chips.pack(side="right", padx=(0, px(12)))
        self.disp_chip = ttk.Label(chips, text="", style="HeadChipStop.TLabel")
        self.status_pill = ttk.Label(chips, text="", style="HeadChipStop.TLabel")
        self.status_pill.pack(side="right")
        self._status = None
        self._set_status("stop")
        for w in (bar, name, self.proj_label, logo, menus):
            w.bind("<ButtonPress-1>", self._start_move)
            w.bind("<B1-Motion>", self._do_move)
            w.bind("<ButtonRelease-1>", self._end_move)
            w.bind("<Double-Button-1>", lambda e: self._toggle_max() if self._frameless_wanted() else None)

    def _draw_logo(self, c, s):
        r = max(3, int(s * 0.28))
        col = ACCENT
        pts = []
        for cx, cy, a0 in ((s - r, r, 0), (r, r, 90), (r, s - r, 180), (s - r, s - r, 270)):
            for k in range(7):
                ang = math.radians(a0 + k * 15)
                pts += [cx + r * math.cos(ang), cy - r * math.sin(ang)]
        c.create_polygon(pts, fill=col, outline="")
        if T["key"] == "studio":
            c.create_polygon(pts, fill=ACCENT2, outline="", stipple="gray50")
        c.create_text(s / 2, s / 2 + 1, text="L", fill=ON_ACCENT, font=FONTS["small_b"])

    def _update_proj_label(self):
        if hasattr(self, "proj_label"):
            name = os.path.basename(self.project_path) if getattr(self, "project_path", None) else ""
            self.proj_label.configure(text=("·  " + os.path.splitext(name)[0]) if name else "")

    def _popup_menu(self, w, builder):
        m = tk.Menu(self.root, tearoff=0, bg=PANEL, fg=FG, activebackground=SEL, activeforeground=FG,
                    selectcolor=ACCENT, bd=0, relief="flat", font=FONTS["ui"], disabledforeground=DIM)
        builder(m)
        try:
            m.tk_popup(w.winfo_rootx(), w.winfo_rooty() + w.winfo_height() + 2)
        finally:
            m.grab_release()

    def _menu_file(self, m):
        m.add_command(label="Новый проект", accelerator="Ctrl+N", command=self._new_project)
        m.add_command(label="Открыть проект…", accelerator="Ctrl+O", command=self._open)
        m.add_command(label="Сохранить", accelerator="Ctrl+S", command=self._save)
        m.add_command(label="Сохранить как…", accelerator="Ctrl+Shift+S", command=self._save_as)
        m.add_separator()
        m.add_command(label="Вставить из буфера (Excel, текст)", accelerator="Ctrl+V", command=self._paste_cues)
        m.add_command(label="Копировать выбранные", accelerator="Ctrl+C", command=self._copy_cues)
        m.add_separator()
        m.add_command(label="Выход", accelerator="Alt+F4", command=self._on_close)

    def _menu_cues(self, m):
        m.add_command(label="Добавить команду", command=self._add_cue)
        m.add_command(label="Добавить тестовую", command=self._add_test_cue)
        m.add_separator()
        m.add_command(label="Открыть выбранную…", accelerator="Enter", command=self._open_cue)
        m.add_command(label="Отправить выбранную", accelerator="Пробел", command=self._send_selected)
        m.add_command(label="Включить / выключить", command=self._toggle_cue)
        m.add_command(label="Удалить", accelerator="Delete", command=self._delete_cue)
        m.add_separator()
        m.add_command(label="Отменить", accelerator="Ctrl+Z", command=self._undo_cues)
        m.add_command(label="Выделить все", accelerator="Ctrl+A", command=self._select_all)

    def _menu_targets(self, m):
        m.add_command(label="Несколько Resolume…", command=self._open_targets)
        m.add_command(label="Найти Resolume в сети…", command=self._find_resolume)
        m.add_command(label="Отправить тестовую команду", command=self._send_test)
        m.add_command(label="Сетевые адаптеры…", command=self._open_adapters)
        m.add_separator()
        m.add_checkbutton(label="Пересылать таймкод в OSC", variable=self.send_tc_var)

    def _menu_view(self, m):
        for key, t in THEMES.items():
            m.add_radiobutton(label="Тема: " + t["name"], value=key, variable=self.theme_var,
                              command=lambda k=key: self._apply_theme(k))
        m.add_separator()
        m.add_checkbutton(label="Таймлайн", variable=self.timeline_var, command=self._apply_timeline)
        m.add_checkbutton(label="Журнал", variable=self.log_var, command=lambda: self._toggle_log(self.log_var.get()))
        if IS_WIN:
            m.add_checkbutton(label="Системная рамка окна Windows", variable=self.native_var, command=self._apply_frame)
        m.add_separator()
        sub = tk.Menu(m, tearoff=0, bg=PANEL, fg=FG, activebackground=SEL, activeforeground=FG,
                      selectcolor=ACCENT, bd=0, relief="flat", font=FONTS["ui"])
        self.fps_var.set(self.fps_mode)
        for key, label, *_ in RATES:
            sub.add_radiobutton(label=label if key == "auto" else label + " fps", value=key,
                                variable=self.fps_var, command=self._on_rate_chosen)
        m.add_cascade(label="Частота кадров", menu=sub)

    def _menu_help(self, m):
        m.add_command(label="Проверить обновления…", command=lambda: self.check_updates(manual=True))
        m.add_command(label="Папка с журналами (hang.log)", command=self._open_cfg_dir)
        m.add_checkbutton(label="Проверять обновления при запуске", variable=self.autoupd_var,
                          command=self._save_prefs)
        if IS_WIN and getattr(sys, "frozen", False):
            try:
                import setup_app
                if not setup_app.is_installed_run():
                    m.add_command(label="Установить LTC2OSC на этот компьютер…", command=self._offer_install)
            except Exception:
                pass
        m.add_separator()
        m.add_command(label="О программе", command=self._about)

    def _about(self):
        ver = APP_VER if EXE_VER == APP_VER else "%s  (программа обновлена, exe %s)" % (APP_VER, EXE_VER)
        messagebox.showinfo("О программе", "LTC2OSC %s\n\nТаймкод LTC → команды OSC для Resolume.\n"
                            "Video Land" % ver, parent=self.root)

    # --------------------------------------------- окно без системной рамки (Windows)
    def _hwnd(self):
        import ctypes
        return ctypes.windll.user32.GetParent(self.root.winfo_id())

    def _go_frameless(self):
        """Своя шапка вместо системной: окно без рамки, но с кнопкой на панели задач и Alt+Tab."""
        if not self._frameless_wanted():
            return
        try:
            import ctypes
            u = ctypes.windll.user32
            self.root.overrideredirect(True)
            self.root.update_idletasks()
            hwnd = self._hwnd()
            GWL_EXSTYLE, GWL_STYLE = -20, -16
            ex = u.GetWindowLongW(hwnd, GWL_EXSTYLE)
            u.SetWindowLongW(hwnd, GWL_EXSTYLE, (ex & ~0x00000080) | 0x00040000)     # не TOOLWINDOW, а APPWINDOW
            st = u.GetWindowLongW(hwnd, GWL_STYLE)
            u.SetWindowLongW(hwnd, GWL_STYLE, st | 0x00020000 | 0x00080000)           # MINIMIZEBOX | SYSMENU
            self.root.withdraw()
            self.root.after(10, self.root.deiconify)
            self.root.bind("<Map>", self._on_map, add="+")
            self.root.bind_all("<Alt-F4>", lambda e: self._on_close())
        except Exception as e:
            self._no_frameless = True
            self.log("Своя рамка окна не включилась (%s) — оставлена системная." % e, "warn")

    def _on_map(self, e=None):
        if e is not None and e.widget is not self.root:
            return
        if self._frameless_wanted():
            try:
                self.root.overrideredirect(True)
            except tk.TclError:
                pass

    def _minimize(self):
        try:
            import ctypes
            ctypes.windll.user32.ShowWindow(self._hwnd(), 6)          # SW_MINIMIZE
        except Exception:
            self.root.iconify()

    def _work_area(self):
        try:
            import ctypes
            from ctypes import wintypes
            r = wintypes.RECT()
            # монитор, на котором окно
            hmon = ctypes.windll.user32.MonitorFromWindow(self._hwnd(), 2)

            class MI(ctypes.Structure):
                _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT),
                            ("rcWork", wintypes.RECT), ("dwFlags", wintypes.DWORD)]
            mi = MI()
            mi.cbSize = ctypes.sizeof(MI)
            if ctypes.windll.user32.GetMonitorInfoW(hmon, ctypes.byref(mi)):
                r = mi.rcWork
            else:
                ctypes.windll.user32.SystemParametersInfoW(0x30, 0, ctypes.byref(r), 0)
            return r.left, r.top, r.right - r.left, r.bottom - r.top
        except Exception:
            return 0, 0, self.root.winfo_screenwidth(), self.root.winfo_screenheight() - 40

    def _toggle_max(self):
        if not self._frameless_wanted():
            self.root.state("normal" if self.root.state() == "zoomed" else "zoomed")
            return
        if getattr(self, "_restore_geo", None):
            self.root.geometry(self._restore_geo)
            self._restore_geo = None
        else:
            self._restore_geo = self.root.geometry()
            x, y, w, h = self._work_area()
            self.root.geometry("%dx%d+%d+%d" % (w, h, x, y))

    def _start_move(self, e):
        if not self._frameless_wanted():
            return
        if getattr(self, "_restore_geo", None):        # из развёрнутого — сначала вернуть размер
            frac = e.x_root / max(1, self.root.winfo_width())
            self.root.geometry(self._restore_geo)
            self._restore_geo = None
            self.root.update_idletasks()
            w = self.root.winfo_width()
            self.root.geometry("+%d+%d" % (e.x_root - int(w * frac), max(0, e.y_root - px(20))))
        # двигаем сами, без системного цикла перетаскивания: он останавливает окно Tk, пока держишь мышь.
        # Координаты курсора берём у системы: x_root из события Tk считает от старого положения окна,
        # пока окно едет — отсюда дрожание.
        px_, py_ = self._pointer()
        self._mv = (px_ - self.root.winfo_x(), py_ - self.root.winfo_y())
        self._mv_to = None

    def _pointer(self):
        if IS_WIN:
            try:
                import ctypes
                from ctypes import wintypes
                pt = wintypes.POINT()
                if ctypes.windll.user32.GetCursorPos(ctypes.byref(pt)):
                    return pt.x, pt.y
            except Exception:
                pass
        return self.root.winfo_pointerxy()

    def _do_move(self, e):
        if not getattr(self, "_mv", None):
            return
        first = self._mv_to is None
        px_, py_ = self._pointer()
        self._mv_to = (px_ - self._mv[0], py_ - self._mv[1])
        if first or not getattr(self, "_mv_job", None):
            self._mv_job = self.root.after(8, self._apply_move)       # не чаще ~120 раз в секунду

    def _apply_move(self):
        self._mv_job = None
        if self._mv_to:
            self.root.geometry("+%d+%d" % self._mv_to)

    def _end_move(self, e):
        if getattr(self, "_mv", None) and self._mv_to and self._pointer()[1] <= 1 and self._frameless_wanted():
            self._mv = None
            self._toggle_max()                    # дотащили до верха экрана — развернуть
            return
        self._mv = None

    def _add_grips(self):
        """Тянуть за края и углы — менять размер окна без системной рамки."""
        B = px(5)
        spec = (("n", dict(relx=0, y=0, relwidth=1, height=B), "sb_v_double_arrow"),
                ("s", dict(relx=0, rely=1, y=-B, relwidth=1, height=B), "sb_v_double_arrow"),
                ("w", dict(x=0, rely=0, width=B, relheight=1), "sb_h_double_arrow"),
                ("e", dict(relx=1, x=-B, rely=0, width=B, relheight=1), "sb_h_double_arrow"),
                ("nw", dict(x=0, y=0, width=B * 2, height=B * 2), "size_nw_se"),
                ("ne", dict(relx=1, x=-B * 2, y=0, width=B * 2, height=B * 2), "size_ne_sw"),
                ("sw", dict(x=0, rely=1, y=-B * 2, width=B * 2, height=B * 2), "size_ne_sw"),
                ("se", dict(relx=1, x=-B * 2, rely=1, y=-B * 2, width=B * 2, height=B * 2), "size_nw_se"))
        for side, place, cur in spec:
            g = tk.Frame(self.outer, bg=BORDER, cursor=cur, bd=0, highlightthickness=0)
            g.place(**place)
            g.bind("<ButtonPress-1>", lambda e, s=side: self._grip_start(e, s))
            g.bind("<B1-Motion>", self._grip_move)
            g.bind("<ButtonRelease-1>", self._grip_end)

    # Размер меняем «рамкой»: пока тянешь — двигается лёгкая полупрозрачная рамка, окно пересобирается
    # один раз, когда отпустил. Живой ресайз большого окна Tk не успевает перерисовывать — остаются следы.
    def _grip_start(self, e, side):
        r = self.root
        x0, y0 = self._pointer()
        self._grip = (side, x0, y0, r.winfo_x(), r.winfo_y(), r.winfo_width(), r.winfo_height())
        self._grip_ev = (x0, y0)
        self._grip_geo = None
        self._restore_geo = None
        try:
            o = tk.Toplevel(r)
            o.overrideredirect(True)
            o.configure(bg=ACCENT)
            tk.Frame(o, bg=BG).pack(fill="both", expand=True, padx=px(3), pady=px(3))
            try:
                o.attributes("-alpha", 0.35)
                o.attributes("-topmost", True)
            except tk.TclError:
                pass
            o.geometry("%dx%d+%d+%d" % (self._grip[5], self._grip[6], self._grip[3], self._grip[4]))
            self._grip_outline = o
        except tk.TclError:
            self._grip_outline = None

    def _grip_move(self, e):
        self._grip_ev = self._pointer()
        geo = self._grip_calc()
        self._grip_geo = geo
        o = getattr(self, "_grip_outline", None)
        if o is not None:
            o.geometry(geo)
        elif not getattr(self, "_grip_job", None):
            self._grip_job = self.root.after(60, lambda: (setattr(self, "_grip_job", None),
                                                          self.root.geometry(self._grip_geo)))

    def _grip_end(self, e):
        o = getattr(self, "_grip_outline", None)
        self._grip_outline = None
        if o is not None:
            o.destroy()
        if getattr(self, "_grip_geo", None):
            self.root.geometry(self._grip_geo)
            self._grip_geo = None

    def _grip_calc(self):
        side, x0, y0, X, Y, W, H = self._grip
        xr, yr = self._grip_ev
        dx, dy = xr - x0, yr - y0
        mw, mh = px(860), px(600)
        if "e" in side:
            W = max(mw, W + dx)
        if "s" in side:
            H = max(mh, H + dy)
        if "w" in side:
            nw = max(mw, W - dx)
            X, W = X + (W - nw), nw
        if "n" in side:
            nh = max(mh, H - dy)
            Y, H = Y + (H - nh), nh
        return "%dx%d+%d+%d" % (W, H, X, Y)

    # ---------------------------------------------------------- таблица команд
    def _build_cues(self, main):
        cuec, cb, chead = card(main, "Команды")
        cuec.grid(row=0, column=0, sticky="nsew")
        self.count_label = ttk.Label(chead, text="0", style="CardChipPlain.TLabel")
        self.count_label.pack(side="left", padx=px(8))
        ttk.Button(chead, text="Сохранить как…", style="Small.TButton", command=self._save_as).pack(side="right")
        ttk.Button(chead, text="Открыть…", style="Small.TButton", command=self._open).pack(side="right", padx=px(6))

        form = ttk.Frame(cb, style="Card.TFrame")
        for col, text in ((0, "ТАЙМКОД"), (2, "ЗАМЕТКА"), (3, "OSC-АДРЕС"), (4, "АРГУМЕНТЫ"), (5, "КУДА")):
            ttk.Label(form, text=caps(text) if T["key"] != "broadcast" else text, style="Caps.TLabel").grid(
                row=0, column=col, sticky="w", pady=(0, px(4)))
        ttk.Entry(form, textvariable=self.f_tc, width=11, font=FONTS["mono"]).grid(row=1, column=0, sticky="we")
        ttk.Button(form, text="◉ сейчас", style="Small.TButton",
                   command=self._use_current_tc).grid(row=1, column=1, padx=(px(6), px(12)), sticky="ns")
        ttk.Entry(form, textvariable=self.f_note, width=8).grid(row=1, column=2, sticky="we", padx=(0, px(8)))
        ttk.Entry(form, textvariable=self.f_addr, width=12, font=FONTS["mono"]).grid(row=1, column=3, sticky="we", padx=(0, px(8)))
        ttk.Entry(form, textvariable=self.f_args, width=8, font=FONTS["mono"]).grid(row=1, column=4, sticky="we")
        self.to_combo = ttk.Combobox(form, textvariable=self.f_to, width=7, values=["все"])
        self.to_combo.grid(row=1, column=5, sticky="we", padx=(px(8), 0))
        form.columnconfigure(2, weight=2)
        form.columnconfigure(3, weight=3)
        form.columnconfigure(4, weight=1)

        btns = ttk.Frame(cb, style="Card.TFrame")
        btns.pack(side="bottom", fill="x", pady=(px(10), 0))
        form.pack(side="bottom", fill="x")
        tk.Frame(cb, bg=BORDER, height=1).pack(side="bottom", fill="x", pady=(px(8), px(10)))
        self.cue_btns = []
        for i, (text, style, cmd, side) in enumerate((("+  Добавить", "Accent", self._add_cue, "left"),
                                       ("Сохранить", "", self._update_cue, "left"),
                                       ("Подробно…", "", self._open_cue, "left"),
                                       ("Отправить", "", self._send_selected, "left"),
                                       ("Вкл / Выкл", "", self._toggle_cue, "left"),
                                       ("Удалить", "Danger", self._delete_cue, "right"))):
            b = ttk.Button(btns, text=text, style=(style + ".TButton") if style else "TButton", command=cmd, width=1)
            b.grid(row=0, column=i, sticky="we", padx=(0 if i == 0 else px(6), 0))
            btns.columnconfigure(i, weight=1, uniform="cb")
            self.cue_btns.append((b, style))
        self._small_btns = False

        tf = ttk.Frame(cb, style="Card.TFrame")
        tf.pack(fill="both", expand=True)
        cols = ("st", "tc", "note", "addr", "args", "to", "go")
        self.tree = ttk.Treeview(tf, columns=cols, show="headings", height=3)
        H = (lambda t: t) if T["key"] == "broadcast" else (lambda t: t)
        for c, title, w, anchor, stretch in (("st", "", px(30), "center", False),
                                             ("tc", "ТАЙМКОД", px(104), "w", False),
                                             ("note", "ЗАМЕТКА", px(120), "w", True),
                                             ("addr", "OSC-АДРЕС", px(170), "w", True),
                                             ("args", "АРГ.", px(56), "w", True),
                                             ("to", "КУДА", px(64), "w", True),
                                             ("go", "ПРОВЕРКА", px(84), "center", False)):
            self.tree.heading(c, text=H(title), anchor=anchor)
            self.tree.column(c, width=w, minwidth=px(56) if stretch else w, anchor=anchor, stretch=stretch)
        for tag, opts in (("even", dict(background=PANEL, foreground=FG)),
                          ("odd", dict(background=STRIPE if T["key"] != "broadcast" else PANEL, foreground=FG)),
                          ("off", dict(background=PANEL, foreground=DIM)),
                          ("off_odd", dict(background=STRIPE if T["key"] != "broadcast" else PANEL, foreground=DIM)),
                          ("done", dict(foreground=mix(MUTED, PANEL, 0.35))),
                          *[("col_" + k, dict(foreground=col)) for k, _, col in CUE_COLORS if k],
                          ("next", dict(background=NEXT_BG, foreground=NEXT_FG, font=FONTS["ui_b"])),
                          ("fired", dict(background=FIRED_BG, foreground=GREEN))):
            self.tree.tag_configure(tag, **opts)
        sbar = ttk.Scrollbar(tf, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sbar.set)
        self.tree.pack(side="left", fill="both", expand=True)
        sbar.pack(side="right", fill="y", padx=(px(6), 0))
        self.tree.bind("<<TreeviewSelect>>", lambda e: self._on_select())
        self.tree.bind("<Double-1>", self._on_tree_double)
        self.tree.bind("<Return>", lambda e: self._open_cue())
        self.tree.bind("<Delete>", lambda e: self._delete_cue())
        self.tree.bind("<BackSpace>", lambda e: self._delete_cue())   # клавиша delete на Mac
        mod = "Command" if IS_MAC else "Control"
        for key, fn in (("v", self._paste_cues), ("c", self._copy_cues),
                        ("z", self._undo_cues), ("a", self._select_all)):
            for k in (key, key.upper()):
                self.tree.bind("<%s-%s>" % (mod, k), lambda e, fn=fn: (fn(), "break")[1])
        if not getattr(self, "_global_keys", False):
            self._global_keys = True
            self.root.bind_all("<%s-z>" % mod, lambda e: self._undo_if_not_entry(e), add="+")
            # Ctrl/Cmd + русская буква на месте V/C/X/Z/A — в таблице и во всех полях ввода
            self.root.bind_all("<%s-Key>" % mod, self._hotkey_any_layout, add="+")
        self.tree.bind("<Button-1>", lambda e: self.tree.focus_set(), add="+")
        # кнопка «▶ тест» в строке: отправить команду сразу, без таймкода
        self.tree.bind("<ButtonRelease-1>", self._on_tree_click, add="+")
        self.tree.bind("<Motion>", self._on_tree_motion, add="+")
        self.tree.bind("<Leave>", lambda e: self.tree.configure(cursor=""), add="+")
        self.tree.bind("<space>", lambda e: (self._send_selected(), "break")[1])
        self.tree.bind("<KP_Enter>", lambda e: (self._send_selected(), "break")[1])

    # ---------------------------------------------------------- правая колонка
    def _build_side(self, side, G):
        oscc, ob, oh = card(side, "Получатели OSC")
        oscc.pack(fill="x")
        ttk.Button(oh, text="Несколько…", style="Small.TButton", command=self._open_targets).pack(side="right")
        r1 = ttk.Frame(ob, style="Card.TFrame")
        r1.pack(fill="x")
        ttk.Label(r1, text="IP", style="CardMuted.TLabel").pack(side="left")
        ttk.Entry(r1, textvariable=self.ip_var, width=14, font=FONTS["mono"]).pack(side="left", padx=(px(6), px(8)), fill="x", expand=True)
        ttk.Label(r1, text="порт", style="CardMuted.TLabel").pack(side="left")
        ttk.Entry(r1, textvariable=self.port_var, width=6, font=FONTS["mono"]).pack(side="left", padx=(px(6), 0))
        rn = ttk.Frame(ob, style="Card.TFrame")
        rn.pack(fill="x", pady=(px(6), 0))
        ttk.Label(rn, text="сеть", style="CardMuted.TLabel").pack(side="left")
        self.net_btn = ttk.Button(rn, text="Авто", style="Link.TButton", command=self._open_adapters)
        self.net_btn.pack(side="left", padx=(px(6), 0))
        self._update_net_label()
        self.targets_box = ttk.Frame(ob, style="Card.TFrame")
        self.targets_box.pack(fill="x", pady=(px(8), 0))
        self.targets_label = ttk.Label(ob, text="", style="CardMuted.TLabel")     # для совместимости
        rb = ttk.Frame(ob, style="Card.TFrame")
        rb.pack(fill="x", pady=(px(8), 0))
        ttk.Button(rb, text="Найти Resolume", style="Small.TButton", command=self._find_resolume).pack(side="left")
        ttk.Button(rb, text="Тест", style="Small.TButton", command=self._send_test).pack(side="left", padx=(px(6), 0))
        self.test_label = ttk.Label(rb, text="", style="CardMuted.TLabel")
        self.test_label.pack(side="left", padx=(px(8), 0))
        r2 = ttk.Frame(ob, style="Card.TFrame")
        r2.pack(fill="x", pady=(px(8), 0))
        ttk.Checkbutton(r2, text="Таймкод в OSC на", style="Card.TCheckbutton",
                        variable=self.send_tc_var).pack(side="left")
        ttk.Entry(r2, textvariable=self.tc_addr_var, width=8, font=FONTS["mono"]).pack(side="left", fill="x", expand=True, padx=(px(8), 0))

        srcc, sb, sh = card(side, "Вход LTC и табло")
        srcc.pack(fill="x", pady=(G, 0))
        ttk.Button(sh, text="обновить", style="Link.TButton", command=self._refresh_devices).pack(side="right")
        r = ttk.Frame(sb, style="Card.TFrame")
        r.pack(fill="x")
        self.dev_combo = ttk.Combobox(r, state="readonly", width=10, textvariable=self.dev_var)
        self.dev_combo.pack(side="left", fill="x", expand=True)
        self.dev_combo.bind("<<ComboboxSelected>>", lambda e: self._on_device_changed())
        ttk.Label(r, text="канал", style="CardMuted.TLabel").pack(side="left", padx=(px(8), px(4)))
        self.chan_spin = ttk.Spinbox(r, from_=1, to=2, textvariable=self.chan_var, width=3)
        self.chan_spin.pack(side="left")
        r4 = ttk.Frame(sb, style="Card.TFrame")
        r4.pack(fill="x", pady=(px(8), 0))
        ttk.Label(r4, text="табло", style="CardMuted.TLabel").pack(side="left")
        self.disp_combo = ttk.Combobox(r4, state="readonly", width=16, textvariable=self.disp_var)
        self.disp_combo.pack(side="left", padx=(px(8), 0), fill="x", expand=True)
        self.disp_combo.bind("<<ComboboxSelected>>", lambda e: self._on_disp_chosen())
        self.disp_combo.bind("<Button-1>", lambda e: self._refresh_disp_ports(), add="+")
        self.disp_status = ttk.Label(sb, text="", style="CardMuted.TLabel")
        self.disp_status.pack(anchor="w", pady=(px(4), 0))
        self._disp_map = {}
        if not hasattr(self, "display"):
            self.display = DisplayLink(self)

        logc, lb, lhead = card(side, "Журнал")
        logc.pack(fill="both", expand=True, pady=(G, 0))
        self.log_card = logc
        self.log_body = lb
        self.log_toggle = ttk.Button(lhead, text="свернуть", style="Link.TButton",
                                     command=self._toggle_log_manual)
        self.log_toggle.pack(side="right")
        self.log_text = tk.Text(lb, height=4, state="disabled", font=FONTS["mono_s"],
                                bg=PANEL, fg=MUTED, insertbackground=FG, relief="flat",
                                highlightthickness=0, selectbackground=SEL, bd=0, wrap="word",
                                spacing1=px(2), spacing3=px(2))
        self.log_text.pack(fill="both", expand=True)
        for tag, color in (("ts", DIM), ("info", MUTED), ("fire", GREEN), ("send", ACCENT_HI),
                           ("test", ACCENT_HI), ("err", RED), ("warn", AMBER)):
            self.log_text.tag_configure(tag, foreground=color)

    def _refresh_targets_box(self):
        box = getattr(self, "targets_box", None)
        if box is None or not box.winfo_exists():
            return
        for w in box.winfo_children():
            w.destroy()
        on = {(t["ip"], t["port"]) for t, _ in self._out}
        for i, t in enumerate(self.all_targets()[:6]):
            row = ttk.Frame(box, style="Card.TFrame")
            row.pack(fill="x", pady=(0, px(3)))
            live = (t["ip"], t["port"]) in on
            dot = tk.Canvas(row, width=px(10), height=px(10), bg=PANEL, highlightthickness=0)
            dot.create_oval(1, 1, px(9), px(9), fill=GREEN if live else DIM, outline="")
            dot.pack(side="left", padx=(0, px(8)))
            ttk.Label(row, text=t["name"] + ("  (основной)" if i == 0 and len(self.all_targets()) > 1 else ""),
                      style="Card.TLabel" if live else "CardMuted.TLabel").pack(side="left")
            if len(self.all_targets()) > 1:
                x = tk.Label(row, text="×", font=FONTS["ui_b"], bg=PANEL, fg=DIM, cursor="hand2", padx=px(4))
                x.pack(side="right", padx=(px(6), 0))
                x.bind("<Enter>", lambda e, w=x: w.configure(fg=RED))
                x.bind("<Leave>", lambda e, w=x: w.configure(fg=DIM))
                x.bind("<Button-1>", lambda e, k=i: self._ask_remove_target(k))
            ttk.Label(row, text="%s : %s" % (t["ip"] or "—", t["port"] or "—"), style="CardMuted.TLabel",
                      font=FONTS["mono_s"]).pack(side="right")
            for w in (row,) + tuple(row.winfo_children()):
                w.bind("<Button-3>", lambda e, k=i: self._target_menu(e, k))
        if len(self.all_targets()) > 6:
            ttk.Label(box, text="… ещё %d" % (len(self.all_targets()) - 6), style="CardMuted.TLabel").pack(anchor="w")

    # ---------------------------------------------------------- тема и вид
    def _apply_theme(self, key):
        if key not in THEMES:
            return
        self.theme = key
        self.theme_var.set(key)
        self._rebuild()
        self._save_prefs()
        self.log("Тема: %s" % THEMES[key]["name"])

    def _rebuild(self):
        """Пересобрать окно (новая тема или рамка). Данные и состояние приёма не трогаем."""
        for w in list(self.root.winfo_children()):
            if isinstance(w, tk.Toplevel):
                w.destroy()
        apply_dark_theme(self.root, self.theme)
        for w in list(self.root.winfo_children()):
            w.destroy()
        self._ui = {}
        self._row_state = None
        self._build_ui()
        self._after_build()

    def _after_build(self):
        self._set_font_theme(THEMES[self.theme]["fonts"])
        self._refresh_tree()
        self._update_target()
        self._refresh_disp_ports()
        if self.devices:
            names = ["%s  [%s]" % (d["name"], self._api_names.get(d["hostapi"], "")) for i, d in self.devices]
            self.dev_combo["values"] = names
        else:
            self._refresh_devices()
        if self.mode == "audio":
            self.start_btn.configure(text="■  Стоп", style="Danger.TButton")
            self.test_btn.state(["disabled"])
        elif self.mode == "test":
            self.test_btn.configure(text="■  Стоп теста", style="Danger.TButton")
            self.start_btn.state(["disabled"])
        self.log_text.configure(state="normal")
        for ts, kind, msg in self._log_hist[-300:]:
            self.log_text.insert("end", ts + "  ", "ts")
            self.log_text.insert("end", msg + "\n", kind)
        self.log_text.see("end")
        self.log_text.configure(state="disabled")
        if not self.log_var.get():
            self._toggle_log(False)

    def _apply_timeline(self):
        on = self.timeline_var.get()
        if on and not self.tl_card.winfo_manager():
            self.tl_card.pack(fill="x", pady=(px(12), 0), before=self.tl_anchor)
        elif not on and self.tl_card.winfo_manager():
            self.tl_card.pack_forget()
        self._save_prefs()

    def _apply_frame(self):
        self._save_prefs()
        if messagebox.askyesno("Рамка окна", "Чтобы сменить рамку окна, программу нужно перезапустить.\n\nПерезапустить сейчас?"):
            self._restart()

    def _restart(self):
        self._on_close(destroy=False)
        try:
            import subprocess
            args = [sys.executable] + ([] if getattr(sys, "frozen", False) else [os.path.abspath(__file__)])
            subprocess.Popen(args, close_fds=True)
        except Exception as e:
            messagebox.showerror("Перезапуск", "Не удалось перезапустить: %s\nЗапустите программу заново." % e)
        self.root.destroy()

    def _save_prefs(self):
        self.prefs.update(theme=self.theme, timeline=bool(self.timeline_var.get()), log=bool(self.log_var.get()),
                          native_frame=bool(self.native_var.get()), auto_update=bool(self.autoupd_var.get()))
        try:
            g = self.root.geometry() if not getattr(self, "_restore_geo", None) else self._restore_geo
            self.prefs["geometry"] = g
        except tk.TclError:
            pass
        save_prefs(self.prefs)

    def _set_font_theme(self, key):
        self.font_key = font_theme(key)[0]
        ghost = apply_font_theme(self.root, self.font_key)
        self._tc_ghost_on = bool(ghost)
        self.tc_max = int(abs(FONTS["tc"].cget("size")) * 1.6)   # насколько часы могут вырасти
        self._layout_tc()
        self._schedule_fit()

    @staticmethod
    def _tc_metrics():
        """Ширина ячейки цифры = самая широкая цифра шрифта, чтобы ничего не обрезалось и не прыгало."""
        f = FONTS["tc"]
        dw = max(f.measure(d) for d in "0123456789-")
        cw = max(f.measure(":"), f.measure(";"))
        pad = max(3, int(dw * 0.06))
        return f, dw, cw, pad

    def _tc_width(self):
        f, dw, cw, pad = self._tc_metrics()
        return 8 * dw + 3 * cw + 2 * pad

    def _layout_tc(self):
        """Раскладывает 11 символов таймкода по ячейкам фиксированной ширины."""
        f, dw, cw, pad = self._tc_metrics()
        c = self.tc_canvas
        c.delete("all")
        cells = []
        x = pad
        for ch in "88:88:88:88":
            w = cw if ch == ":" else dw
            cx = x + w / 2.0
            g = c.create_text(cx, 0, anchor="n", font=f, fill=T["tc_ghost"],
                              text=ch if self._tc_ghost_on else "")
            t = c.create_text(cx, 0, anchor="n", font=f, fill=self._tc_fill, text="",
                              tags=("colon",) if ch == ":" else ())
            cells.append(t)
            x += w
        c.configure(width=int(x + pad), height=f.metrics("linespace"))
        self.tc_cells = cells
        shown, self._tc_str = self._tc_str, None
        self._draw_tc(shown, self._tc_fill)

    def _draw_tc(self, text, fill):
        if fill != self._tc_fill:
            self._tc_fill = fill
            colon = T["tc_colon"] if fill in (T["tc_live"], T["tc_test"]) and T["key"] != "broadcast" else fill
            for i, t in enumerate(self.tc_cells):
                self.tc_canvas.itemconfigure(t, fill=colon if i in (2, 5, 8) else fill)
        old = self._tc_str
        if text != old:
            self._tc_str = text
            for i, t in enumerate(self.tc_cells):
                ch = text[i] if i < len(text) else ""
                if old is None or i >= len(old) or old[i] != ch:
                    self.tc_canvas.itemconfigure(t, text=ch)

    def _schedule_fit(self):
        if self._fit_job is not None:
            self.root.after_cancel(self._fit_job)
        self._fit_job = self.root.after(40, self._fit_tc)

    def _fit_tc(self):
        """Подгоняет размер часов под ширину главного блока и высоту окна."""
        self._fit_job = None
        if not self.hero_body.winfo_exists():
            return
        W = self.hero_body.winfo_width()
        H = self.root.winfo_height()
        if W < 100 or H < 100:
            return
        show_next = W >= px(820)                 # в узком окне прячем «Следующую команду»
        if show_next != self._next_shown:
            self._next_shown = show_next
            if show_next:
                self.next_box.grid()
            else:
                self.next_box.grid_remove()
        small = self.root.winfo_width() < px(1700)     # в узком окне кнопки мельче
        if small != self._small_btns:
            self._small_btns = small
            for b, st in self.cue_btns:
                b.configure(style=("Small" + (st or "Plain") + ".TButton") if small
                            else ((st + ".TButton") if st else "TButton"))
        used = self.ctl_box.winfo_reqwidth() + px(16)
        if show_next:
            used += max(self.next_box.winfo_reqwidth(), px(300)) + px(52)
        avail = W - used
        if H < px(700) and self.timeline_var.get() and self.tl_card.winfo_manager():
            self.tl_card.pack_forget()                     # невысокое окно — таймлайн прячем сам
            self._tl_auto_hidden = True
        elif H >= px(740) and getattr(self, "_tl_auto_hidden", False) and self.timeline_var.get():
            self._tl_auto_hidden = False
            if not self.tl_card.winfo_manager():
                self.tl_card.pack(fill="x", pady=(px(12), 0), before=self.tl_anchor)
        f = FONTS["tc"]
        cur = abs(f.cget("size"))
        size = cur * avail / float(max(self._tc_width(), 1))
        size = min(size, cur * (H * 0.11) / float(max(f.metrics("linespace"), 1)))
        size = int(max(14, min(size, self.tc_max)))
        if size != cur:
            f.configure(size=size)
            self._layout_tc()

    def _toggle_mid(self, show=None):
        pass

    def _toggle_log_manual(self):
        self._log_auto_hidden = False
        self._toggle_log()

    def _toggle_log(self, show=None):
        visible = self.log_body.winfo_manager() != ""
        show = (not visible) if show is None else show
        if show and not visible:
            self.log_body.pack(fill="both", expand=True, padx=px(14), pady=(px(6), px(12)))
            self.log_card.pack_configure(fill="both", expand=True)
        elif not show and visible:
            self.log_body.pack_forget()
            self.log_card.pack_configure(fill="x", expand=False)
        self.log_toggle.configure(text="свернуть" if show else "показать")
        if self.log_var.get() != show:
            self.log_var.set(show)
            self._save_prefs()

    STATUS = {
        "live": ("●  ПРИЁМ LTC", "Live"),
        "test": ("●  ТЕСТОВЫЕ ЧАСЫ", "Test"),
        "nosig": ("●  НЕТ СИГНАЛА", "Nosig"),
        "stop": ("○  ОСТАНОВЛЕНО", "Stop"),
    }

    def _set_ui(self, key, widget, mode=None, **kw):
        """configure() только если значение изменилось — Tk не перерисовывает лишнее."""
        if self._ui.get(key) == kw:
            return
        self._ui[key] = kw
        if mode == "item":
            widget.itemconfigure(kw.pop("item"), **kw)
        else:
            widget.configure(**kw)

    def _set_status(self, key):
        if key != self._status:
            self._status = key
            text, st = self.STATUS[key]
            if T["key"] == "broadcast" and key == "live":
                text = "●  ON AIR · LTC"
            self.status_pill.configure(text=text, style="HeadChip%s.TLabel" % st)

    # ------------------------------------------------------- звуковой вход
    def _refresh_devices(self):
        if sd is None:
            self.dev_combo["values"] = ["(звуковой вход недоступен)"]
            self.dev_combo.current(0)
            return
        try:
            all_dev = sd.query_devices()
            apis = sd.query_hostapis()
        except Exception as e:
            self.log("Не удалось получить список устройств: %s" % e)
            return
        self.devices = [(i, d) for i, d in enumerate(all_dev) if d["max_input_channels"] > 0]
        self._api_names = {k: a["name"] for k, a in enumerate(apis)}
        names = ["%s  [%s]" % (d["name"], apis[d["hostapi"]]["name"]) for i, d in self.devices]
        self.dev_combo["values"] = names
        sel = 0
        if self.saved_device in names:
            sel = names.index(self.saved_device)
        else:
            try:
                default_in = sd.default.device[0]
                for k, (i, d) in enumerate(self.devices):
                    if i == default_in:
                        sel = k
            except Exception:
                pass
        if names:
            self.dev_combo.current(sel)
            self._on_device_changed()

    def _fresh_device(self, entry, reinit=False):
        """Найти выбранное устройство заново по имени и звуковой системе (номера в PortAudio могут сдвинуться)."""
        idx, dev = entry
        try:
            if reinit:
                sd._terminate()
                sd._initialize()
            for i, d in enumerate(sd.query_devices()):
                if d["name"] == dev["name"] and d["hostapi"] == dev["hostapi"] and d["max_input_channels"] > 0:
                    if reinit or i != idx:
                        self.devices = [(j, x) for j, x in enumerate(sd.query_devices()) if x["max_input_channels"] > 0]
                    return i, d
        except Exception:
            pass
        return idx, dev

    def _on_device_changed(self):
        k = self.dev_combo.current()
        if 0 <= k < len(self.devices):
            maxch = self.devices[k][1]["max_input_channels"]
            self.chan_spin.configure(to=maxch)
            if self.chan_var.get() > maxch:
                self.chan_var.set(1)

    def _toggle_audio(self):
        if self.mode == "audio":
            self._stop()
        elif self.mode is None:
            self._start_audio()

    def _start_audio(self):
        if sd is None:
            messagebox.showerror("Нет звука", "Модуль sounddevice не работает:\n%s" % SD_ERROR)
            return
        k = self.dev_combo.current()
        if not (0 <= k < len(self.devices)):
            messagebox.showerror("Нет входа", "Выберите звуковой вход.")
            return
        dev_index, dev = self._fresh_device(self.devices[k])
        try:
            ch = int(self.chan_var.get())
        except (tk.TclError, ValueError):
            ch = 1
        ch = min(max(ch, 1), dev["max_input_channels"])
        sr = int(dev["default_samplerate"])

        self._reset_tc()
        self.decoder = LTCDecoder(sr, self._on_frame)
        self.stop_evt.clear()
        while not self.audio_q.empty():
            self.audio_q.get_nowait()

        nch = max(ch, min(2, int(dev["max_input_channels"])))    # для VU-метра — оба канала
        self.ch_peaks = [0.0] * nch

        def callback(indata, frames, t, status):
            try:
                pk = np.abs(indata).max(axis=0)
                self.ch_peaks = [max(float(p), o * 0.85) for p, o in zip(pk, self.ch_peaks)]
            except Exception:
                pass
            try:
                self.audio_q.put_nowait(indata[:, ch - 1].copy())
            except queue.Full:
                pass

        # пробуем по очереди: оба канала → только нужный → другие частоты (WASAPI капризен к формату)
        tries = []
        for c in (nch, ch):
            for r in (sr, 48000, 44100):
                if (c, r) not in tries:
                    tries.append((c, r))
        # открываем в фоне: некоторые драйверы (WDM-KS, ASIO-обёртки) открываются секундами —
        # окно при этом не должно замирать
        self.start_btn.state(["disabled"])
        self.test_btn.state(["disabled"])
        self.start_btn.configure(text="Открываю вход…")
        res = {}
        devbox = {"idx": dev_index, "dev": dev}

        def opener():
            err = None
            for attempt in range(2):
                for c, r in tries:
                    st = None
                    try:
                        st = sd.InputStream(device=devbox["idx"], channels=c, samplerate=r,
                                            dtype="float32", callback=callback, blocksize=512)
                        st.start()
                    except Exception as e:
                        err = e
                        if st is not None:           # недооткрытый поток держит устройство — закрыть
                            try:
                                st.close()
                            except Exception:
                                pass
                        continue
                    res.update(stream=st, sr=r, ch=c)
                    return
                if attempt:
                    break
                # «Invalid device» — список устройств устарел: перечитываем PortAudio
                devbox["idx"], devbox["dev"] = self._fresh_device((devbox["idx"], devbox["dev"]), reinit=True)
            res["err"] = err

        th = threading.Thread(target=opener, daemon=True)
        th.start()
        t0 = time.monotonic()

        def wait():
            if th.is_alive():
                if time.monotonic() - t0 < 15:
                    self.root.after(50, wait)
                    return
                res["err"] = "драйвер не ответил за 15 секунд"
            self._audio_opened(res, devbox["dev"], ch)
        self.root.after(50, wait)

    def _audio_opened(self, res, dev, ch):
        self.start_btn.state(["!disabled"])
        self.test_btn.state(["!disabled"])
        self.start_btn.configure(text="▶  Старт приёма")
        st = res.get("stream")
        if st is not None and (self.mode is not None or res.get("err")):    # опоздал / уже запустили тест
            try:
                st.close()
            except Exception:
                pass
            return
        err = None if st is not None else (res.get("err") or "неизвестная ошибка")
        if err is None:
            self.stream, sr = st, res["sr"]
            if sr != self.decoder.sr:
                self.decoder = LTCDecoder(sr, self._on_frame)
            self.ch_peaks = [0.0] * res["ch"]
        if err is not None:
            self.stream = None
            self.log("Ошибка звука: %s" % err, "err")
            messagebox.showerror("Ошибка звука", "Не удалось открыть вход «%s».\n\n%s\n\n"
                                 "Проверьте, что устройство подключено и не занято другой программой, "
                                 "нажмите «обновить» или выберите этот же вход с пометкой [MME] или [DirectSound]."
                                 % (dev["name"], err))
            return

        self.worker = threading.Thread(target=self._audio_worker, daemon=True)
        self.worker.start()
        self.mode = "audio"
        self.start_btn.configure(text="■  Стоп", style="Danger.TButton")
        self.test_btn.state(["disabled"])
        self.log("Слушаю: %s, канал %d, %d Гц" % (dev["name"], ch, sr))
        self.audio_started = time.monotonic()
        self.silence_hint = False

    def _audio_worker(self):
        while not self.stop_evt.is_set():
            try:
                block = self.audio_q.get(timeout=0.2)
            except queue.Empty:
                continue
            try:
                self.decoder.process(block)
            except Exception as e:
                self.log("Ошибка декодера: %s" % e, "err")

    # --------------------------------------------------------- тест-режим
    def _test_rate(self):
        key, label, fps, real, df = rate_info(self.fps_mode)
        if fps is None:                      # «Авто» без сигнала — тестируем на 25
            return "25", 25, 25.0, False
        return label, fps, real, df

    def _toggle_test(self):
        if self.mode == "test":
            self._stop()
        elif self.mode is None:
            self._start_test(parse_tc(self.f_tc.get()) or (0, 0, 0, 0))

    def _start_test(self, start):
        label, fps, real, df = self._test_rate()
        self._reset_tc()
        self.stop_evt.clear()
        self.worker = threading.Thread(target=self._test_worker, args=(start, fps, real, df), daemon=True)
        self.worker.start()
        self.mode = "test"
        self.test_btn.configure(text="■  Стоп теста", style="Danger.TButton")
        self.start_btn.state(["disabled"])
        self.log("Тест: внутренние часы %s fps с %s" % (label, fmt_tc_df(start, df)))

    def _test_worker(self, start, fps, real, df):
        base = tc_to_index(start, fps, df)
        t0 = time.perf_counter()
        last = -1
        while not self.stop_evt.is_set():
            n = int((time.perf_counter() - t0) * real)
            if n != last:
                last = n
                h, m, s, f = index_to_tc(base + n - 1, fps, df)   # -1: компенсирует +1 кадр в _on_frame
                self._on_frame(h, m, s, f, df)
            nxt = t0 + (n + 1) / real
            self.stop_evt.wait(max(0.001, nxt - time.perf_counter()))

    # ----------------------------------------------------- выбор частоты
    def _show_rate_menu(self, e=None):
        self.fps_var.set(self.fps_mode)
        w = self.fps_label
        try:
            self.rate_menu.tk_popup(w.winfo_rootx(), w.winfo_rooty() + w.winfo_height() + 2)
        finally:
            self.rate_menu.grab_release()

    def _on_rate_chosen(self):
        key = self.fps_var.get()
        if key == self.fps_mode:
            return
        self.fps_mode = rate_info(key)[0]
        self._period_ema, self._period_n, self._last_pos = None, 0, None
        self._mismatch_logged = None
        info = rate_info(self.fps_mode)
        self.log("Частота кадров: %s" % (info[1] if info[2] is None else info[1] + " fps"))
        if self.mode == "test":              # перезапускаем тест с той же позиции
            start = frames_to_tc(self.cur_frames, self.fps) if self.cur_frames is not None else (0, 0, 0, 0)
            self._stop()
            self._start_test(start)
        self._save_config(CONFIG_FILE)

    def _signal_label(self):
        """Что реально приходит в сигнале: 23.976 / 24 / 25 / 29.97 DF / 29.97 ND / 30."""
        n = self.sig_fps
        if n == 25:
            return "25"
        if n == 30 and self.sig_drop:
            return "29.97 DF"
        real = (1.0 / self._period_ema) if (self._period_ema and self._period_n >= 25) else None
        if n == 24:
            return "23.976" if real and abs(real - 23.976) < abs(real - 24) else "24"
        return "29.97 ND" if real and abs(real - 29.97) < abs(real - 30) else "30"

    # -------------------------------------------------------------- общее
    def _stop(self):
        self.stop_evt.set()
        if self.stream is not None:
            st, self.stream = self.stream, None

            def closer():
                try:
                    st.stop()
                    st.close()
                except Exception:
                    pass
            th = threading.Thread(target=closer, daemon=True)     # драйвер может «думать» — окно не ждёт
            th.start()
            th.join(timeout=0.3)
        if self.worker is not None:
            self.worker.join(timeout=1)
            self.worker = None
        self.mode = None
        self.decoder = None
        self.start_btn.configure(text="▶  Старт приёма", style="Accent.TButton")
        self.test_btn.configure(text="Тест без LTC", style="TButton")
        self.start_btn.state(["!disabled"])
        self.test_btn.state(["!disabled"])
        self.log("Остановлено")

    def _reset_tc(self):
        self.prev_frames = None
        self.cur_frames = None
        self.last_raw_f = None
        self.last_frame_time = 0.0

    def _on_frame(self, h, m, s, f, drop, pos=None):
        """Вызывается на каждый принятый кадр (в фоновом потоке)."""
        # что в сигнале: число кадров (по сбросу номера кадра в 0) и флаг drop-frame
        if self.last_raw_f is not None and f == 0 and self.last_raw_f in (23, 24, 29):
            self.sig_fps = self.last_raw_f + 1
        if f >= self.sig_fps:
            self.sig_fps = 25 if f == 24 else 30
        self.last_raw_f = f
        self.sig_drop = bool(drop)

        key, _, rfps, _, rdf = rate_info(self.fps_mode)
        if rfps is None:                                 # «Авто»
            fps, df = self.sig_fps, self.sig_drop and self.sig_fps == 30
        else:
            fps, df = rfps, rdf
        self.fps, self.drop = fps, df

        # кадр LTC дочитывается к концу кадра, поэтому реально идёт уже следующий
        idx = tc_to_index((h, m, s, f), fps, df) + 1
        cur = tc_to_frames(index_to_tc(idx, fps, df), fps)

        # точная частота по звуку: отличает 23.976 от 24 и 29.97 от 30
        dec = self.decoder
        if pos is not None and dec is not None:
            if self._last_pos is not None and idx - self._last_idx == 1:
                period = (pos - self._last_pos) / float(dec.sr)
                if 0.025 < period < 0.05:
                    e = self._period_ema
                    self._period_ema = period if e is None else e * 0.97 + period * 0.03
                    self._period_n += 1
            self._last_pos, self._last_idx = pos, idx

        prev = self.prev_frames
        self.prev_frames = cur
        self.cur_frames = cur
        self.last_frame_time = time.monotonic()

        if self.send_tc and self._out:
            msg = fmt_tc_df(frames_to_tc(cur, fps), df)
            for _, client in self._out:
                try:
                    client.send_message(self.tc_address, msg)
                except Exception:
                    pass

        if prev is None:
            return
        delta = cur - prev
        if delta > 0:
            frames, cues = self._schedule(fps)[:2]
            i = bisect.bisect_right(frames, prev)
            j = bisect.bisect_right(frames, cur)
            normal = delta <= fps       # обычное воспроизведение; при перемотке — только команды с «при перемотке»
            for cue in cues[i:j]:
                if normal or cue.get("chase"):
                    self._send_cue(cue, delay=0.0 if not normal else self._sched_delay.get(id(cue), 0.0))

    def _schedule(self, fps):
        """Включённые команды, отсортированные по кадру. Пересчитывается только при изменениях."""
        sched = self._sched
        if sched[2] != fps or sched[3:] != (id(self.cues), self._cues_ver):
            pairs, delays = [], {}
            for i, c in enumerate(self.cues):
                if not c["enabled"]:
                    continue
                base = tc_to_frames(c["tc"], fps)
                off = int(c.get("offset_ms") or 0)
                if off:                 # сдвиг: целые кадры — в расписание, остаток — таймером
                    eff = base * 1000.0 / fps + off
                    fr = int(math.floor(eff * fps / 1000.0 + 1e-6))
                    delays[id(c)] = max(0.0, (eff - fr * 1000.0 / fps) / 1000.0)
                    base = fr
                pairs.append((base, i, c))
            pairs.sort(key=lambda p: (p[0], p[1]))
            self._sched_delay = delays
            sched = ([p[0] for p in pairs], [p[2] for p in pairs], fps, id(self.cues), self._cues_ver)
            self._sched = sched
        return sched

    _sched_delay = {}

    def _cues_changed(self):
        self._cues_ver += 1

    def _dests(self, to):
        """Кому отправлять: [(получатель, клиент)], [неизвестные имена]."""
        want = split_targets(to)
        if not want:
            return list(self._out), []
        by_name = {t["name"].strip().lower(): (t, c) for t, c in self._out}
        known = self._target_names()
        return [by_name[n] for n in want if n in by_name], [n for n in want if n not in known]

    def _dests_ext(self, to):
        """Как _dests, но «Куда» может содержать и прямые адреса: 192.168.1.20:7000."""
        dests, unknown = [], []
        names = []
        for tok in (to or "").replace(";", ",").split(","):
            tok = tok.strip()
            if not tok:
                continue
            ipd = parse_ip_dest(tok)
            if ipd:
                c = self._client_for(*ipd)
                if c is not None:
                    dests.append((dict(name="%s:%d" % ipd, ip=ipd[0], port=ipd[1], on=True), c))
                continue
            names.append(tok)
        if names:
            d2, unknown = self._dests(", ".join(names))
            dests += d2
        elif not dests:
            return self._dests("")
        return dests, unknown

    def _send_raw(self, dests, addr, args):
        for t, client in dests:
            try:
                client.send_message(addr, args)
            except Exception as e:
                self.log("Ошибка отправки %s в %s: %s" % (addr, t["name"], e), "err")

    def _send_cue(self, cue, manual=False, delay=0.0):
        if delay > 0.0005:                       # сдвиг внутри кадра (настройка «Сдвиг, мс»)
            threading.Timer(delay, self._send_cue, args=(cue, manual)).start()
            return
        dests, unknown = self._dests_ext(cue.get("to", ""))
        if unknown:
            self.log("Нет получателя: %s (команда %s)" % (", ".join(unknown), cue["address"]), "warn")
        if not dests:
            self.log("Не отправлено %s: нет включённых получателей с правильным IP и портом" % cue["address"], "err")
            return
        o = cue_opts(cue)
        args = typed_osc_args(cue["args"], o["argtype"])
        sent = []
        for t, client in dests:
            try:
                client.send_message(cue["address"], args)
                sent.append(t["name"])
            except Exception as e:
                self.log("Ошибка отправки %s в %s: %s" % (cue["address"], t["name"], e), "err")
        ok_dests = [(t, c) for t, c in dests if t["name"] in sent]
        rep_n = max(1, min(20, int(o["repeat"] or 1)))
        for k in range(1, rep_n):                 # повтор — на случай потери пакета по Wi-Fi
            threading.Timer(k * max(1, int(o["repeat_ms"])) / 1000.0, self._send_raw,
                            args=(ok_dests, cue["address"], args)).start()
        for e in o["extra"]:                      # цепочка доп. команд — у каждой может быть свой «Куда»
            eargs = typed_osc_args(e.get("args", ""), o["argtype"])
            eto = (e.get("to") or "").strip()
            if eto and eto != SAME_TO:
                ed, eunk = self._dests_ext(eto)
                if eunk:
                    self.log("Нет получателя: %s (доп. %s)" % (", ".join(eunk), e["address"]), "warn")
            else:
                ed = ok_dests
            if e.get("delay_ms"):
                threading.Timer(e["delay_ms"] / 1000.0, self._send_raw, args=(ed, e["address"], eargs)).start()
            else:
                self._send_raw(ed, e["address"], eargs)
        if sent:
            if "id" in cue:
                self.fired[cue["id"]] = time.monotonic()
            where = "" if len(self.all_targets()) == 1 else "  [%s]" % ", ".join(sent)
            if rep_n > 1:
                where += "  ×%d" % rep_n
            if o["extra"]:
                where += "  +%d доп." % len(o["extra"])
            self.log("%s  %s  →  %s %s%s" % ("вручную" if manual else fmt_tc(cue["tc"]),
                                             cue.get("note") or "", cue["address"],
                                             " ".join(map(str, args)), where), "send" if manual else "fire")

    def _send_test(self, only=None):
        """Отправляет тестовую команду — её видно в Resolume: Preferences → OSC → монитор."""
        if only is not None:
            t = self.all_targets()[only]
            c = self._client_for(t["ip"], t["port"])
            dests = [(t, c)] if c is not None else []
        else:
            dests = list(self._out)
        if not dests:
            self.test_label.configure(text="нет получателя (IP или порт)", foreground=RED)
            return
        addr = self.test_addr_var.get().strip() or TEST_ADDRESS
        if not addr.startswith("/"):
            addr = "/" + addr
        args = parse_osc_args(self.test_args_var.get())
        names = []
        for t, client in dests:
            try:
                client.send_message(addr, args)
                names.append("%s (%s:%s)" % (t["name"], t["ip"], t["port"]))
            except Exception as e:
                self.log("Тест в %s не отправлен: %s" % (t["name"], e), "err")
        if not names:
            self.test_label.configure(text="ошибка отправки", foreground=RED)
            return
        self.test_label.configure(text="✓ отправлено (%d) в %s" % (len(names), time.strftime("%H:%M:%S")), foreground=GREEN)
        self.log("Тест: %s %s → %s" % (addr, " ".join(map(str, args)), ", ".join(names)), "test")

    # ------------------------------------------------------- табло
    def _refresh_disp_ports(self):
        items = [("Выкл", "off"), ("Авто — найти Arduino", "auto")]
        for dev, desc, vid in DisplayLink.ports():
            label = _short_port(dev)
            hint = USB_SERIAL_VIDS.get(vid) or desc
            items.append(("%s — %s" % (label, hint) if hint else label, dev))
        cur = self.display.target
        if cur not in ("off", "auto") and cur not in [t for _, t in items]:
            items.append(("%s — не подключён" % _short_port(cur), cur))
        self._disp_map = dict(items)
        self.disp_combo["values"] = [n for n, _ in items]
        self.disp_var.set(next((n for n, t in items if t == cur), "Выкл"))

    def _on_disp_chosen(self):
        target = self._disp_map.get(self.disp_var.get(), "off")
        self.display.set_target(target)
        self.log("Табло: %s" % self.disp_var.get())
        self._save_config(CONFIG_FILE)

    def _display_state(self):
        """Что показать на табло: (таймкод, состояние, частота, следующая команда, сколько до неё)."""
        now = time.monotonic()
        cur, fps, drop, mode = self.cur_frames, self.fps, self.drop, self.mode
        live = bool(mode and cur is not None and now - self.last_frame_time < 0.5)
        tc = fmt_tc_df(frames_to_tc(cur, fps), drop) if cur is not None else "--:--:--:--"
        if live:
            st = "L" if mode == "audio" else "T"
        else:
            st = "N" if mode == "audio" else "T" if mode == "test" else "S"
        key, rlabel, rfps, _, rdf = rate_info(self.fps_mode)
        if mode == "audio":
            fl = self._signal_label() if rfps is None else rlabel
        elif mode == "test":
            fl = self._test_rate()[0]
        else:
            fl = "" if rfps is None else rlabel
        fl = fl.replace(" ", "")
        if fl in ("24", "25", "30"):
            fl += "fps"
        name = eta = ""
        if cur is not None:
            frames, cues = self._schedule(fps)[:2]
            k = bisect.bisect_right(frames, cur)
            if k < len(cues):
                c = cues[k]
                name = c["note"] or c["address"]
                left = max(0, tc_to_index(c["tc"], fps, drop) - tc_to_index(frames_to_tc(cur, fps), fps, drop))
                secs = left // max(fps, 1)
                h, rem = divmod(secs, 3600)
                m, sec = divmod(rem, 60)
                eta = ("-%d:%02d:%02d" % (h, m, sec)) if h else ("-%d:%02d" % (m, sec))
        name = name.replace("|", " ").replace("\n", " ").strip()[:24]
        return tc, st, fl, name, eta

    def _find_resolume(self, add=False):
        if getattr(self, "finder", None) is not None and self.finder.winfo_exists():
            self.finder.destroy()
        self.finder = ResolumeFinder(self, add_mode=add)

    def _open_targets(self):
        if getattr(self, "targets_dlg", None) is not None and self.targets_dlg.winfo_exists():
            self.targets_dlg.lift()
        else:
            self.targets_dlg = TargetsDialog(self)

    # ---------------- получатели OSC
    def all_targets(self):
        try:
            port = int(self.port_var.get())
        except (ValueError, tk.TclError):
            port = 0
        return [dict(name=self.main_name, ip=self.ip_var.get().strip(), port=port, on=True)] + self.extra_targets

    def _target_names(self):
        return {t["name"].strip().lower() for t in self.all_targets()}

    def add_target(self, ip, port, name):
        names = self._target_names()
        base, k = name, 2
        while name.strip().lower() in names:
            name = "%s %d" % (base, k)
            k += 1
        if any(t["ip"] == ip and t["port"] == port for t in self.all_targets()):
            self.log("%s:%s уже есть в получателях" % (ip, port), "warn")
            return False
        self.extra_targets.append(dict(name=name, ip=ip, port=int(port), on=True))
        self._targets_changed("Добавлен получатель %s (%s:%s)" % (name, ip, port))
        return True

    def set_target(self, i, **kw):
        if i == 0:
            if "name" in kw:
                self.main_name = kw["name"]
            if "ip" in kw:
                self.ip_var.set(kw["ip"])
            if "port" in kw:
                self.port_var.set(str(kw["port"]))
            if kw.get("on") is False:
                messagebox.showinfo("Основной", "Основной получатель всегда включён.")
        else:
            self.extra_targets[i - 1].update(kw)
        self._targets_changed()

    def _ask_remove_target(self, i, parent=None):
        t = self.all_targets()[i]
        parent = parent or self.root
        if i == 0 and not self.extra_targets:
            messagebox.showinfo("Удалить получателя", "Это единственный получатель — его нельзя удалить, "
                                "но можно поменять IP и порт.", parent=parent)
            return False
        extra = ("\n\nОсновным станет «%s»." % self.extra_targets[0]["name"]) if i == 0 else ""
        if messagebox.askyesno("Удалить получателя", "Удалить «%s» (%s:%s)?%s" % (t["name"], t["ip"], t["port"], extra),
                               parent=parent):
            self.remove_target(i)
            return True
        return False

    def _target_menu(self, e, i):
        t = self.all_targets()[i]
        m = tk.Menu(self.root, tearoff=0, bg=PANEL, fg=FG, activebackground=SEL, activeforeground=FG,
                    bd=0, relief="flat", font=FONTS["ui"], disabledforeground=DIM)
        m.add_command(label=t["name"], state="disabled")
        m.add_command(label="Тест", command=lambda: self._send_test(only=i))
        if i > 0:
            m.add_command(label="Выключить" if t["on"] else "Включить",
                          command=lambda: self.set_target(i, on=not t["on"]))
        if len(self.all_targets()) > 1:
            m.add_command(label="Удалить…", command=lambda: self._ask_remove_target(i))
        m.add_separator()
        m.add_command(label="Все получатели…", command=self._open_targets)
        try:
            m.tk_popup(e.x_root, e.y_root)
        finally:
            m.grab_release()

    def remove_target(self, i):
        if i == 0:                         # основной: его место занимает следующий
            if not self.extra_targets:
                return
            old = self.main_name
            t = self.extra_targets.pop(0)
            self.main_name = t["name"]
            self.ip_var.set(t["ip"])
            self.port_var.set(str(t["port"]))
            self._targets_changed("Удалён получатель %s, основной теперь %s" % (old, t["name"]))
            return
        t = self.extra_targets.pop(i - 1)
        self._targets_changed("Удалён получатель %s" % t["name"])

    def _targets_changed(self, msg=None):
        self._update_target()
        self._save_config(CONFIG_FILE)
        self._refresh_tree()
        if msg:
            self.log(msg)

    def _sources_for(self, ip):
        """С каких адресов этого компьютера слать на ip: адаптер из той же подсети, иначе — все выбранные."""
        chosen = [a for a in self._adapters_now() if a["ip"] in self.adapters]
        if not chosen:
            return (None,)
        same = [a["ip"] for a in chosen if same_subnet(ip, a)]
        return tuple(same[:1] or [a["ip"] for a in chosen])

    def _adapters_now(self):
        t = time.monotonic()
        if (t - getattr(self, "_ad_t", -99) > 10 and threading.current_thread() is threading.main_thread()) \
                or not hasattr(self, "_ad_cache"):      # список адаптеров — не чаще раза в 10 с и только из окна
            self._ad_cache, self._ad_t = list_adapters(), t
        return self._ad_cache

    def _client_for(self, ip, port):
        src = self._sources_for(ip) if ip else (None,)
        key = (ip, port, src)
        c = self._clients.get(key)
        if c is None and ip and 0 < port < 65536:
            try:
                c = self._clients[key] = OscOut(ip, port, src)
            except Exception:
                c = None
        return c

    def set_adapters(self, ips):
        self.adapters = list(ips)
        self.prefs["adapters"] = self.adapters
        self._save_prefs()
        self._ad_t = -99
        for c in self._clients.values():
            try:
                c.close()
            except Exception:
                pass
        self._clients = {}
        self._update_target()
        self._update_net_label()
        names = {a["ip"]: a["name"] for a in self._adapters_now()}
        self.log("Сеть: " + (", ".join("%s (%s)" % (names.get(i, "?"), i) for i in self.adapters)
                             if self.adapters else "авто — как решит Windows"))

    def _net_summary(self):
        if not self.adapters:
            return "Авто"
        names = {a["ip"]: a["name"] for a in self._adapters_now()}
        parts = [names.get(i, i + " (нет)") for i in self.adapters]
        return ", ".join(parts)

    def _update_net_label(self):
        w = getattr(self, "net_btn", None)
        if w is not None and w.winfo_exists():
            txt = self._net_summary()
            w.configure(text=(txt[:34] + "…") if len(txt) > 35 else txt)

    def _open_adapters(self):
        dlg = getattr(self, "net_dlg", None)
        if dlg is not None and dlg.winfo_exists():
            dlg.lift()
            return
        self._ad_t = -99
        self.net_dlg = AdaptersDialog(self)

    def _update_target(self):
        out, used = [], set()
        for t in self.all_targets():
            if t["on"]:
                c = self._client_for(t["ip"], t["port"])
                if c is not None:
                    out.append((t, c))
                    used.add((t["ip"], t["port"]))
        for key in [k for k in self._clients if k not in used and k != (self.ip_var.get().strip(), self._port_or0())]:
            try:
                self._clients.pop(key)._sock.close()
            except Exception:
                pass
        self._out = out
        self.client = out[0][1] if out and out[0][0]["name"] == self.main_name else None
        if hasattr(self, "targets_label"):
            n = len(self.all_targets())
            on = [t["name"] for t, _ in out]
            self.targets_label.configure(text=("только основной" if n == 1 else
                                               "%d из %d: %s" % (len(on), n, ", ".join(on)))[:70])
        if hasattr(self, "to_combo"):
            self.to_combo["values"] = ["все"] + [t["name"] for t in self.all_targets()]
        if hasattr(self, "targets_box"):
            if getattr(self, "_tb_job", None):
                self.root.after_cancel(self._tb_job)
            self._tb_job = self.root.after(150, self._refresh_targets_box)
        try:
            self.send_tc = bool(self.send_tc_var.get())
        except tk.TclError:
            self.send_tc = False
        addr = self.tc_addr_var.get().strip()
        self.tc_address = addr if addr.startswith("/") else "/" + addr

    def _port_or0(self):
        try:
            return int(self.port_var.get())
        except (ValueError, tk.TclError):
            return 0

    def log(self, msg, kind="info"):
        self.log_q.put((time.strftime("%H:%M:%S"), kind, msg))

    def _tick(self):
        self._last_tick_t = time.monotonic()
        try:
            self._tick_body()
        except Exception as e:
            if not getattr(self, "_tick_err", None):
                self._tick_err = True
                self.log("Ошибка обновления окна: %r — подробности в hang.log" % e, "err")
                self._write_diag("ошибка в обновлении окна", exc=True)
        finally:
            self.root.after(40, self._tick)

    def _open_cfg_dir(self):
        d = _config_dir()
        try:
            if IS_WIN:
                os.startfile(d)
            elif IS_MAC:
                subprocess.Popen(["open", d])
            else:
                subprocess.Popen(["xdg-open", d])
        except Exception as e:
            messagebox.showinfo("Папка", d + "\n\n" + str(e), parent=self.root)

    def _write_diag(self, why, exc=False):
        try:
            import faulthandler
            import traceback
            with open(os.path.join(_config_dir(), "hang.log"), "a", encoding="utf-8") as fh:
                fh.write("\n==== %s  LTC2OSC %s  — %s ====\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), APP_VER, why))
                fh.write("режим: %s, вход: %s\n" % (self.mode, self.dev_var.get() if hasattr(self, "dev_var") else ""))
                if exc:
                    fh.write(traceback.format_exc())
                fh.flush()
                faulthandler.dump_traceback(file=fh, all_threads=True)
        except Exception:
            pass

    def _watchdog(self):
        """Если окно перестало обновляться дольше 4 с — записать, где застряли все потоки (hang.log)."""
        dumped = False
        while True:
            time.sleep(1.0)
            last = getattr(self, "_last_tick_t", None)
            if last is None:
                continue
            stall = time.monotonic() - last
            if stall > 4 and not dumped:
                dumped = True
                self._write_diag("окно не отвечает %.0f с" % stall)
            elif stall < 1 and dumped:
                self.log("Окно не отвечало несколько секунд — записано в hang.log (Справка → Папка с журналами)", "warn")
                dumped = False

    def _tick_body(self):
        now = time.monotonic()
        # полная тишина на входе — чаще всего нет разрешения на микрофон
        if (self.mode == "audio" and self.decoder and not self.silence_hint
                and now - self.audio_started > 3 and self.decoder.peak < 1e-4):
            self.silence_hint = True
            if IS_MAC:
                self.log("На входе тишина. Проверьте: Системные настройки → Конфиденциальность "
                         "и безопасность → Микрофон → разрешить для LTC2OSC (или Терминала).", "warn")
            elif IS_WIN:
                self.log("На входе тишина. Проверьте: Параметры → Конфиденциальность → Микрофон → "
                         "разрешить классическим приложениям, и что выбран правильный вход/канал.", "warn")
            else:
                self.log("На входе тишина. Проверьте выбранный вход и канал.", "warn")
        live = bool(self.mode and self.cur_frames is not None and now - self.last_frame_time < 0.5)
        fps = self.fps
        cur = self.cur_frames
        set_ = self._set_ui
        key, rlabel, rfps, _, rdf = rate_info(self.fps_mode)
        warn = None
        if live:
            self._draw_tc(fmt_tc_df(frames_to_tc(cur, fps), self.drop), T["tc_live"] if self.mode == "audio" else T["tc_test"])
            self._set_status("live" if self.mode == "audio" else "test")
            if self.mode == "audio":
                sig = self._signal_label()
                if rfps is None:
                    chip = "%s к/с · АВТО ▾" % sig
                else:
                    chip = "%s к/с ▾" % rlabel
                    if rfps != self.sig_fps or (rdf != self.sig_drop and rfps == 30):
                        warn = sig
            else:
                chip = "%s к/с ▾" % self._test_rate()[0]
            set_("fps", self.fps_label, text=chip, style="CardChipWarn.TLabel" if warn else "CardChipPlain.TLabel")
        else:
            self._draw_tc(self._tc_str or "--:--:--:--", DIM)
            set_("fps", self.fps_label, text=("АВТО ▾" if rfps is None else "%s к/с ▾" % rlabel), style="CardChipStop.TLabel")
            self._set_status("nosig" if self.mode == "audio" else "stop" if self.mode is None else "test")
        if warn and self._mismatch_logged != (self.fps_mode, warn):
            self._mismatch_logged = (self.fps_mode, warn)
            self.log("Выбрано %s fps, а в сигнале %s fps — проверьте настройку частоты" % (rlabel, warn), "warn")
        audio = self.mode == "audio"
        self.meter.set_levels(self.ch_peaks if audio else (), self._safe_chan() - 1)
        set_("src", self.src_label,
             text=("в сигнале %s fps — не совпадает" % warn) if warn
             else "LTC со входа" if audio
             else "внутренние часы" if self.mode == "test" else "нажмите «Старт приёма»")
        dev = self.dev_combo.get().split("  [")[0] if hasattr(self, "dev_combo") else ""
        set_("sdev", self.src_dev, text=(dev or "—") if self.mode != "test" else "Тестовые часы")
        if now - getattr(self, "_db_t", 0) >= 0.25:     # цифры уровня — 4 раза в секунду, чтобы не мельтешили
            self._db_t = now
            self._db_shown = self.meter.db
        db = getattr(self, "_db_shown", None) if audio else None
        set_("slvl", self.src_lvl,
             text=(("ВХОД %d · %s" % (self._safe_chan(), ("%.0f dBFS" % db).replace("-", "−") if db is not None
                                       else "нет сигнала")) if audio
                   else "без звукового входа" if self.mode == "test" else "ВХОД %d · остановлен" % self._safe_chan()),
             fg=(RED if db is not None and db > -3 else GREEN if db is not None and db > -30 else MUTED) if audio else DIM)
        dst = self.display.status
        set_("disp", self.disp_status, text=dst[1],
             foreground={"ok": GREEN, "wait": AMBER, "err": RED}.get(dst[0], DIM))
        on = dst[0] in ("ok", "wait", "err")
        set_("dchip", self.disp_chip, text=("Табло " + _short_port(self.display.port)) if dst[0] == "ok" and self.display.port
             else "Табло" if on else "", style={"ok": "HeadChipPlain.TLabel", "wait": "HeadChipWarn.TLabel",
                                                "err": "HeadChipNosig.TLabel"}.get(dst[0], "HeadChipStop.TLabel"))
        if on and not self.disp_chip.winfo_manager():
            self.disp_chip.pack(side="right", padx=(0, px(8)))
        elif not on and self.disp_chip.winfo_manager():
            self.disp_chip.pack_forget()

        # следующая команда, подсветка строк, таймлайн — 10 раз в секунду, часы и метр — каждый тик
        if now - self._slow_t >= 0.1 or self._row_state is None:
            self._slow_t = now
            self._tick_slow(now, cur, live, fps)
        lines = []
        while not self.log_q.empty():
            lines.append(self.log_q.get_nowait())
        if lines:
            self._log_hist.extend(lines)
            del self._log_hist[:-400]
            self.log_text.configure(state="normal")
            for ts, kind, msg in lines:
                self.log_text.insert("end", ts + "  ", "ts")
                self.log_text.insert("end", msg + "\n", kind)
            n = int(self.log_text.index("end-1c").split(".")[0])
            if n > 500:
                self.log_text.delete("1.0", "%d.0" % (n - 500))
            self.log_text.see("end")
            self.log_text.configure(state="disabled")

    def _tick_slow(self, now, cur, live, fps):
        set_ = self._set_ui
        # следующая команда — бинарный поиск по расписанию
        frames, cues, _ = self._schedule(fps)[:3]
        next_id = None
        if cur is not None:
            k = bisect.bisect_right(frames, cur)
            if k < len(cues):
                c = cues[k]
                next_id = c["id"]
                set_("nname", self.next_name, text=(c["note"] or c["address"])[:40], fg=FG if live else MUTED)
                set_("ncap", self.next_cap, text=caps("Следующая") + "  ·  " + fmt_tc(c["tc"]))
                left = max(0, frames[k] - cur)
                secs = left / float(max(fps, 1))
                if secs >= 3600:
                    eta = "−%d:%02d:%02d" % (secs // 3600, secs % 3600 // 60, secs % 60)
                else:
                    eta = "−%02d:%04.1f" % (secs // 60, secs % 60)
                set_("neta", self.next_eta, text=eta, fg=(RED if T["key"] == "broadcast" else ACCENT) if live else MUTED)
                prev_f = frames[k - 1] if k > 0 else max(0, frames[k] - 60 * fps)
                self.next_bar.set((cur - prev_f) / float(max(1, frames[k] - prev_f)))
            else:
                set_("nname", self.next_name, text="больше команд нет", fg=DIM)
                set_("ncap", self.next_cap, text=caps("Следующая команда"))
                set_("neta", self.next_eta, text="")
                self.next_bar.set(1.0 if cues else 0.0)
        else:
            c = cues[0] if cues else None
            set_("nname", self.next_name, text=(c["note"] or c["address"])[:40] if c else "—", fg=MUTED)
            set_("ncap", self.next_cap, text=caps("Первая команда") + (("  ·  " + fmt_tc(c["tc"])) if c else ""))
            set_("neta", self.next_eta, text="", fg=MUTED)
            self.next_bar.set(0.0)

        # подсветка строк: следующая — синим, только что сработавшая — зелёным
        if self.fired:
            for i, t in list(self.fired.items()):
                if now - t >= 1.2:
                    self.fired.pop(i, None)
        fired = frozenset(self.fired)
        state = (next_id, fired)
        if state != self._row_state:
            old = self._row_state
            self._row_state = state
            if old is None:
                self._retag_rows(next_id, fired)
            else:
                changed = (set(old[1]) ^ set(fired)) | {old[0], next_id}
                self._retag_rows(next_id, fired, changed)

        if self.timeline_var.get() and self.tl_card.winfo_manager():
            self.timeline.redraw()

    # ------------------------------------------------------------ команды
    def _row_tags(self, c, i, next_id=None, fired=()):
        if c["id"] in fired:
            return ("fired",)
        if c["id"] == next_id and c["enabled"]:
            return ("next",)
        if not c["enabled"]:
            return ("off_odd",) if i % 2 else ("off",)
        base = ("odd",) if i % 2 else ("even",)
        return base + (("col_" + c["color"],) if c.get("color") else ())

    def _retag_rows(self, next_id, fired, only=None):
        if only is None:
            items = enumerate(self.cues)
        else:
            items = [(self._row_index[i], self.cues[self._row_index[i]])
                     for i in only if i in self._row_index]
        for i, c in items:
            iid = str(c["id"])
            if self.tree.exists(iid):
                self.tree.item(iid, tags=self._row_tags(c, i, next_id, fired))

    def _refresh_tree(self, select_ids=()):
        self.cues = sorted(self.cues, key=lambda c: c["tc"])
        self.tree.delete(*self.tree.get_children())
        for i, c in enumerate(self.cues):
            o = cue_opts(c)
            note = ("⚙ " if cue_has_opts(c) else "") + c["note"]
            args = c["args"] + ("  +%d" % len(o["extra"]) if o["extra"] else "")
            self.tree.insert("", "end", iid=str(c["id"]),
                             values=("●" if c["enabled"] else "○", fmt_tc(c["tc"]),
                                     note, c["address"], args, c.get("to") or "все", "▶  тест"),
                             tags=self._row_tags(c, i))
        self._row_state = None
        self._row_index = {c["id"]: i for i, c in enumerate(self.cues)}
        self._cues_changed()
        self.count_label.configure(text=str(len(self.cues)))
        sel = [str(i) for i in select_ids if self.tree.exists(str(i))]
        if sel:
            self.tree.selection_set(sel)
            self.tree.see(sel[0])

    def _selected(self):
        ids = set(self.tree.selection())
        return [c for c in self.cues if str(c["id"]) in ids]

    def _form_cue(self):
        tc = parse_tc(self.f_tc.get())
        if tc is None:
            messagebox.showerror("Таймкод", "Таймкод в формате ЧЧ:ММ:СС:КК, например 00:01:30:12")
            return None
        addr = self.f_addr.get().strip()
        if not addr.startswith("/") or len(addr) < 2 or " " in addr:
            messagebox.showerror("OSC-адрес", "Адрес должен начинаться с / и быть без пробелов,\n"
                                              "например /cue/1/go")
            return None
        to = self.f_to.get().strip()
        to = "" if not split_targets(to) else ", ".join(x.strip() for x in to.replace(";", ",").split(",") if x.strip())
        unknown = [n for n in split_targets(to) if n not in self._target_names()
                   and n not in ("все", "всем", "all", "*") and not parse_ip_dest(n)]
        if unknown:
            messagebox.showwarning("Куда", "Нет получателя с именем: %s\n\nИмена задаются в «Несколько Resolume…». "
                                           "Команда сохранится, но пока не будет никуда отправляться." % ", ".join(unknown))
        return dict(tc=tc, address=addr, args=self.f_args.get().strip(),
                    note=self.f_note.get().strip(), to=to)

    def _on_select(self):
        sel = self._selected()
        if sel:
            c = sel[0]
            self.f_tc.set(fmt_tc(c["tc"]))
            self.f_addr.set(c["address"])
            self.f_args.set(c["args"])
            self.f_note.set(c["note"])
            self.f_to.set(c.get("to") or "все")

    def _snapshot(self):
        self._undo.append([dict(c) for c in self.cues])
        del self._undo[:-50]

    def _undo_cues(self):
        if not self._undo:
            self.log("Отменять нечего")
            return
        self.cues = self._undo.pop()
        self._refresh_tree()
        self._save_config(CONFIG_FILE)
        self.log("Отменено последнее изменение списка команд")

    def _undo_if_not_entry(self, e):
        if not isinstance(e.widget, (tk.Entry, ttk.Entry, tk.Text, ttk.Combobox)):
            self._undo_cues()

    def _select_all(self):
        self.tree.selection_set(self.tree.get_children())

    # русская (и украинская) раскладка: какая буква стоит на месте V, C, X, Z, A
    _CYR_KEYSYM = {"Cyrillic_em": "v", "Cyrillic_es": "c", "Cyrillic_che": "x",
                   "Cyrillic_ya": "z", "Cyrillic_ef": "a"}
    _CYR_CHAR = {"м": "v", "с": "c", "ч": "x", "я": "z", "ф": "a"}

    @staticmethod
    def _key_by_code(kc):
        """Физическая клавиша по коду — на случай любой другой раскладки."""
        if IS_WIN:
            return {86: "v", 67: "c", 88: "x", 90: "z", 65: "a"}.get(kc)
        if IS_MAC:
            if kc > 0xFFFF:                     # Tk на Mac кладёт виртуальный код в старшие биты
                for shift in (24, 16):
                    k = {9: "v", 8: "c", 7: "x", 6: "z", 0: "a"}.get((kc >> shift) & 0xFF)
                    if k:
                        return k
            return None
        return {55: "v", 54: "c", 53: "x", 52: "z", 38: "a"}.get(kc)

    def _hotkey_any_layout(self, e):
        """Ctrl/Cmd+V/C/X/Z/A работают и в русской раскладке."""
        ks = e.keysym or ""
        if len(ks) == 1 and ks.isascii() and ks.isalpha():
            return None                         # латиница — работает штатно
        key = (self._CYR_KEYSYM.get(ks) or self._CYR_KEYSYM.get(ks[:9] + ks[9:].lower())
               or self._CYR_CHAR.get((e.char or "").lower()) or self._key_by_code(e.keycode))
        if not key:
            return None
        w = e.widget
        if w is self.tree:
            fn = {"v": self._paste_cues, "c": self._copy_cues, "z": self._undo_cues,
                  "a": self._select_all}.get(key)
            if fn:
                fn()
            return "break"
        if isinstance(w, (tk.Entry, ttk.Entry, tk.Text, ttk.Combobox, ttk.Spinbox, tk.Spinbox)):
            if key == "a":
                try:
                    if isinstance(w, tk.Text):
                        w.tag_add("sel", "1.0", "end-1c")
                    else:
                        w.selection_range(0, "end")
                        w.icursor("end")
                except tk.TclError:
                    pass
            else:
                w.event_generate({"v": "<<Paste>>", "c": "<<Copy>>", "x": "<<Cut>>",
                                  "z": "<<Undo>>"}[key])
            return "break"
        if key == "z":
            self._undo_cues()
            return "break"
        return None

    def _copy_cues(self):
        sel = self._selected() or []
        if not sel:
            self.log("Выделите команды, чтобы скопировать")
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(cues_to_text(sel))
        self.log("Скопировано команд: %d" % len(sel))

    def _paste_cues(self):
        try:
            text = self.root.clipboard_get()
        except tk.TclError:
            text = ""
        if not text.strip():
            self.log("Буфер обмена пуст", "warn")
            return
        default = parse_tc(self.f_tc.get())
        if default is None:
            default = frames_to_tc(self.cur_frames, self.fps) if self.cur_frames is not None else (0, 0, 0, 0)
        new, skipped = parse_cues_text(text, default)
        if not new:
            self.log("В буфере не нашлось команд. Формат строки: 00:01:30:12 /composition/columns/1/connect 1 "
                     "# заметка — или столбцы из Excel.", "warn")
            return
        existing = {(c["tc"], c["address"], c["args"]) for c in self.cues}
        added, dup = [], 0
        for c in new:
            k = (c["tc"], c["address"], c["args"])
            if k in existing:
                dup += 1
                continue
            existing.add(k)
            c.update(id=next(_ids), enabled=True)
            added.append(c)
        if added:
            self._snapshot()
            self.cues = self.cues + added
            self._refresh_tree([c["id"] for c in added])
            self._save_config(CONFIG_FILE)
        msg = "Вставлено команд: %d" % len(added)
        if dup:
            msg += ", уже были в списке: %d" % dup
        if skipped:
            msg += ", пропущено строк: %d" % skipped
        self.log(msg + (" (Ctrl+Z — отменить)" if added and not IS_MAC else " (Cmd+Z — отменить)" if added else ""),
                 "test" if added else "warn")

    def _add_cue(self):
        c = self._form_cue()
        if c:
            self._snapshot()
            c.update(id=next(_ids), enabled=True)
            self.cues = self.cues + [c]
            self._refresh_tree([c["id"]])
            self._save_config(CONFIG_FILE)

    def _add_test_cue(self):
        """Добавляет в список тестовую команду — её видно в OSC-мониторе Resolume, когда таймкод до неё дойдёт."""
        tc = parse_tc(self.f_tc.get())
        if tc is None:
            tc = frames_to_tc(self.cur_frames, self.fps) if self.cur_frames is not None else (0, 0, 0, 0)
        addr = (self.test_addr_var.get().strip() or TEST_ADDRESS)
        if not addr.startswith("/"):
            addr = "/" + addr
        n = 1 + sum(1 for c in self.cues if c["address"] == addr)
        self._snapshot()
        c = dict(id=next(_ids), tc=tuple(tc), address=addr, args=str(n), note="Тест %d" % n, enabled=True, to="")
        self.cues = self.cues + [c]
        self._refresh_tree([c["id"]])
        self._save_config(CONFIG_FILE)
        self.log("Добавлена тестовая команда %s %s в %s" % (addr, n, fmt_tc(tc)), "test")

    def _update_cue(self):
        sel = self._selected()
        if not sel:
            messagebox.showinfo("Изменение", "Выберите команду в таблице.")
            return
        c = self._form_cue()
        if c:
            self._snapshot()
            sel[0].update(c)
            self._refresh_tree([sel[0]["id"]])
            self._save_config(CONFIG_FILE)

    def _delete_cue(self):
        sel = self._selected()
        if sel:
            self._snapshot()
            ids = {c["id"] for c in sel}
            self.cues = [c for c in self.cues if c["id"] not in ids]
            self._refresh_tree()
            self._save_config(CONFIG_FILE)

    def _toggle_cue(self):
        sel = self._selected()
        if sel:
            self._snapshot()
        for c in sel:
            c["enabled"] = not c["enabled"]
        self._refresh_tree([c["id"] for c in sel])
        self._save_config(CONFIG_FILE)

    def _is_test_cell(self, x, y):
        if self.tree.identify_region(x, y) != "cell":
            return None
        col = self.tree.identify_column(x)            # "#6" — номер столбца
        try:
            name = self.tree["columns"][int(col[1:]) - 1]
        except (ValueError, IndexError):
            return None
        return self.tree.identify_row(y) if name == "go" else None

    def _on_tree_motion(self, e):
        self.tree.configure(cursor="hand2" if self._is_test_cell(e.x, e.y) else "")

    def _on_tree_click(self, e):
        iid = self._is_test_cell(e.x, e.y)
        if not iid:
            return None
        cue = next((c for c in self.cues if str(c["id"]) == iid), None)
        if cue:
            self._send_cue(cue, manual=True)
        return "break"

    def _on_tree_double(self, e):
        if self._is_test_cell(e.x, e.y):
            return "break"
        iid = self.tree.identify_row(e.y)
        if iid:
            self.tree.selection_set(iid)
            self._open_cue()
        return "break"

    def _open_cue(self, cue=None):
        """Окно команды: все поля + доп. настройки."""
        if cue is None:
            sel = self._selected()
            if not sel:
                messagebox.showinfo("Команда", "Выберите команду в таблице (или дважды щёлкните по ней).")
                return
            cue = sel[0]
        dlg = getattr(self, "cue_dlg", None)
        if dlg is not None and dlg.winfo_exists():
            dlg.destroy()
        self.cue_dlg = CueDialog(self, cue)

    def _apply_cue_edit(self, cue, new):
        self._snapshot()
        cue.update(new)
        for k, v in CUE_OPT_DEFAULTS.items():      # значения по умолчанию в файл не пишем
            if cue.get(k) == (list(v) if isinstance(v, tuple) else v):
                cue.pop(k, None)
        self._refresh_tree([cue["id"]])
        self._on_select()
        self._save_config(CONFIG_FILE)

    def _send_selected(self):
        sel = self._selected()
        if not sel:
            c = self._form_cue()
            if c:
                self._send_cue(c, manual=True)
        for c in sel:
            self._send_cue(c, manual=True)

    def _use_current_tc(self):
        if self.cur_frames is not None:
            self.f_tc.set(fmt_tc_df(frames_to_tc(self.cur_frames, self.fps), self.drop))

    # ------------------------------------------------------- сохранение
    def _config_dict(self):
        return {
            "osc_ip": self.ip_var.get(),
            "osc_port": self.port_var.get(),
            "osc_name": self.main_name,
            "targets": [dict(t) for t in self.extra_targets],
            "send_tc": bool(self.send_tc_var.get()),
            "tc_address": self.tc_addr_var.get(),
            "test_address": self.test_addr_var.get(),
            "font_theme": self.font_key,
            "fps_mode": self.fps_mode,
            "test_args": self.test_args_var.get(),
            "display_port": self.display.target,
            "device": self.dev_combo.get(),
            "channel": self.chan_var.get() if str(self.chan_spin.get()).isdigit() else 1,
            "cues": [dict(dict(tc=fmt_tc(c["tc"]), address=c["address"], args=c["args"],
                               note=c["note"], enabled=c["enabled"], to=c.get("to", "")),
                          **{k: c[k] for k in CUE_OPT_DEFAULTS if k in c}) for c in self.cues],
        }

    def _save_config(self, path):
        try:
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(self._config_dict(), fh, ensure_ascii=False, indent=2)
        except Exception as e:
            self.log("Не удалось сохранить %s: %s" % (path, e))

    def _load_config(self, path, quiet=False):
        if not os.path.exists(path):
            return
        try:
            with open(path, encoding="utf-8") as fh:
                d = json.load(fh)
        except Exception as e:
            if not quiet:
                messagebox.showerror("Ошибка", "Не удалось открыть файл:\n%s" % e)
            return
        self.ip_var.set(d.get("osc_ip", "127.0.0.1"))
        self.port_var.set(str(d.get("osc_port", "8000")))
        self.main_name = str(d.get("osc_name") or "Resolume 1")
        self.extra_targets = []
        for t in d.get("targets", []) or []:
            try:
                self.extra_targets.append(dict(name=str(t["name"]), ip=str(t["ip"]), port=int(t["port"]),
                                               on=bool(t.get("on", True))))
            except (KeyError, ValueError, TypeError):
                pass
        self.send_tc_var.set(bool(d.get("send_tc", False)))
        self.tc_addr_var.set(d.get("tc_address", "/ltc"))
        self.test_addr_var.set(d.get("test_address", TEST_ADDRESS))
        self.fps_mode = rate_info(d.get("fps_mode", "auto"))[0]
        self.test_args_var.set(str(d.get("test_args", TEST_ARGS)))
        self.display.set_target(d.get("display_port", "off") or "off")
        self.saved_device = d.get("device")
        try:
            self.chan_var.set(int(d.get("channel", 1)))
        except (ValueError, TypeError):
            pass
        cues = []
        for c in d.get("cues", []):
            tc = parse_tc(c.get("tc", ""))
            if tc and str(c.get("address", "")).startswith("/"):
                cue = dict(id=next(_ids), tc=tc, address=c["address"],
                           args=c.get("args", ""), note=c.get("note", ""),
                           enabled=bool(c.get("enabled", True)), to=str(c.get("to", "") or ""))
                try:                                    # доп. настройки (если есть)
                    if c.get("offset_ms"):
                        cue["offset_ms"] = max(-60000, min(60000, int(c["offset_ms"])))
                    if int(c.get("repeat", 1) or 1) > 1:
                        cue["repeat"] = max(1, min(20, int(c["repeat"])))
                        cue["repeat_ms"] = max(1, min(5000, int(c.get("repeat_ms", 40))))
                    if c.get("argtype") in dict(ARG_TYPES) and c["argtype"] != "auto":
                        cue["argtype"] = c["argtype"]
                    if c.get("extra"):
                        cue["extra"] = [clean_extra(e) for e in c["extra"]
                                        if isinstance(e, dict) and str(e.get("address", "")).startswith("/")]
                    if c.get("color") in dict((k, 1) for k, _, _ in CUE_COLORS) and c["color"]:
                        cue["color"] = c["color"]
                    if c.get("chase"):
                        cue["chase"] = True
                except (TypeError, ValueError, KeyError):
                    pass
                cues.append(cue)
        self.cues = cues
        self._refresh_tree()

    def _open(self):
        path = filedialog.askopenfilename(filetypes=[("Список команд", "*.json"), ("Все файлы", "*.*")])
        if path:
            self._load_config(path)
            self._update_target()
            self._save_config(CONFIG_FILE)
            self.project_path = path
            self.prefs["project"] = path
            self._update_proj_label()
            self._save_prefs()
            self.log("Открыт файл %s" % os.path.basename(path))

    def _new_project(self):
        """Пустой список команд. Получатели, вход и настройки остаются."""
        if self.cues:
            r = messagebox.askyesnocancel("Новый проект", "Сохранить текущий проект (%d команд) перед созданием нового?"
                                          % len(self.cues), parent=self.root)
            if r is None:
                return
            if r and not self._save():
                return
        self.cues = []
        self.fired.clear()
        self._cues_changed()
        self._refresh_tree()
        self.project_path = None
        self.prefs["project"] = ""
        self._update_proj_label()
        self._save_config(CONFIG_FILE)
        self._save_prefs()
        self.log("Новый проект: список команд пуст (получатели и настройки сохранены)")

    def _save(self):
        """Сохранить в текущий файл проекта; если его нет — спросить, куда. → True, если сохранено."""
        path = getattr(self, "project_path", None)
        if not path:
            return self._save_as()
        try:
            self._save_config(path)
        except Exception as e:
            messagebox.showerror("Сохранение", "Не удалось сохранить:\n%s" % e, parent=self.root)
            return False
        self.log("Сохранено: %s" % os.path.basename(path))
        return True

    def _save_as(self):
        path = filedialog.asksaveasfilename(defaultextension=".json",
                                            filetypes=[("Список команд", "*.json")])
        if path:
            self._save_config(path)
            self.project_path = path
            self.prefs["project"] = path
            self._update_proj_label()
            self._save_prefs()
            self.log("Сохранено в %s" % os.path.basename(path))
            return True
        return False

    def _on_close(self, destroy=True):
        self.display.close()
        if self.mode:
            self._stop()
        self._save_config(CONFIG_FILE)
        self._save_prefs()
        if destroy:
            self.root.destroy()

    def _safe_chan(self):
        try:
            return int(self.chan_var.get())
        except (tk.TclError, ValueError):
            return 1

    # ------------------------------------------------- установка и обновления (Windows)
    def check_updates(self, manual=False):
        try:
            import setup_app
        except Exception:
            setup_app = None
        if setup_app is None or not hasattr(setup_app, "check_updates"):
            if manual:
                messagebox.showinfo("Обновления", "LTC2OSC %s." % APP_VER)
            return
        setup_app.check_updates(self, manual)

    def _offer_install(self):
        try:
            import setup_app
            setup_app.offer_install(self, force=True)
        except Exception as e:
            messagebox.showerror("Установка", str(e))


def ltc_encode(fps, sr, start_frames, nframes, amp=0.5, real=None, df=False):
    """Генератор LTC-сигнала (для самопроверки декодера). start_frames — номер кадра (tc_to_index)."""
    out, lvl, t = [], 1.0, 0.0
    bitlen = sr / (80.0 * (real or fps))
    for k in range(nframes):
        h, m, s_, f = index_to_tc(start_frames + k, fps, df)
        b = [0] * 80

        def put(st, n, v):
            for i in range(n):
                b[st + i] = (v >> i) & 1
        put(0, 4, f % 10); put(8, 2, f // 10); put(16, 4, s_ % 10); put(24, 3, s_ // 10)
        put(32, 4, m % 10); put(40, 3, m // 10); put(48, 4, h % 10); put(56, 2, h // 10)
        b[10] = 1 if df else 0
        b[64:80] = [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1]
        for bit in b:
            lvl = -lvl
            a0, mid, e = int(round(t)), int(round(t + bitlen / 2)), int(round(t + bitlen))
            if bit:
                out += [lvl] * (mid - a0)
                lvl = -lvl
                out += [lvl] * (e - mid)
            else:
                out += [lvl] * (e - a0)
            t += bitlen
    return np.array(out, dtype=np.float32) * amp


_ST_LINES = []


def selftest(report_path):
    """Скрытая самопроверка собранной программы: LTC2OSC --selftest отчёт.txt"""
    import platform
    import tempfile
    global CONFIG_FILE, PREFS_FILE
    _td = tempfile.mkdtemp()
    CONFIG_FILE = os.path.join(_td, "config.json")
    PREFS_FILE = os.path.join(_td, "ui.json")
    lines, ok = _ST_LINES, True

    def say(flag, text):
        nonlocal ok
        ok = ok and flag
        lines.append(("OK   " if flag else "FAIL ") + text)

    lines.append("Python %s, %s, %s" % (platform.python_version(), platform.platform(),
                                        platform.mac_ver()[0] if IS_MAC else ""))
    load_bundled_fonts()
    root = tk.Tk()
    lines.append("Tk %s" % root.tk.call("info", "patchlevel"))
    apply_dark_theme(root)
    fams = set(tkfont.families(root))
    for fam in sorted({f for t in FONT_THEMES for f in t[2:5] if f}):
        say(fam in fams, "шрифт «%s» подключён" % fam)
    say(sd is not None, "звук (sounddevice/PortAudio): %s" % (SD_ERROR or "работает"))
    if serial is not None:
        try:
            loop = serial.serial_for_url("loop://", 115200, timeout=0.5)
            loop.write(b"T01:00:31:05|L|-0:12\n")
            echo = loop.readline()
            loop.close()
            say(echo.startswith(b"T01:00:31:05"), "табло по USB (pyserial): портов найдено %d" % len(DisplayLink.ports()))
        except Exception as e:
            say(False, "табло по USB (pyserial): %s" % e)
    else:
        say(False, "табло по USB: %s" % SERIAL_ERROR)
    got = []
    dec = LTCDecoder(48000, lambda *a: got.append(a))
    sig = ltc_encode(25, 48000, tc_to_frames((1, 2, 3, 0), 25), 50)
    for i in range(0, len(sig), 512):
        dec.process(sig[i:i + 512])
    say(len(got) >= 48 and got[0][:4] == (1, 2, 3, 0), "декодер LTC: %d кадров из 50" % len(got))
    got = []
    dec = LTCDecoder(48000, lambda *a: got.append(a))
    sig = ltc_encode(30, 48000, tc_to_index((0, 0, 59, 25), 30, True), 10, real=30000 / 1001.0, df=True)
    for i in range(0, len(sig), 512):
        dec.process(sig[i:i + 512])
    labels = [a[:4] for a in got]
    say((0, 1, 0, 2) in labels and (0, 1, 0, 0) not in labels and all(a[4] for a in got),
        "drop-frame 29.97: после 00:00:59;29 идёт 00:01:00;02")
    rx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    rx.bind(("127.0.0.1", 0))
    rx.settimeout(2)
    SimpleUDPClient("127.0.0.1", rx.getsockname()[1]).send_message("/ltc2osc/test", [1])
    try:
        data = rx.recvfrom(1024)[0]
        say(data.startswith(b"/ltc2osc/test"), "отправка OSC")
    except socket.timeout:
        say(False, "отправка OSC: пакет не пришёл")
    app = App(root)
    rx2 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    rx2.bind(("127.0.0.1", 0))
    rx2.settimeout(1)
    app.ip_var.set("127.0.0.1")
    app.port_var.set(str(rx.getsockname()[1]))
    app.extra_targets = [dict(name="Второй", ip="127.0.0.1", port=rx2.getsockname()[1], on=True)]
    app._update_target()

    def got_on(sock):
        try:
            return sock.recvfrom(1024)[0]
        except socket.timeout:
            return b""
    app._send_cue(dict(tc=(0, 0, 0, 0), address="/both", args="1", note="", to=""), manual=True)
    both = got_on(rx).startswith(b"/both") and got_on(rx2).startswith(b"/both")
    app._send_cue(dict(tc=(0, 0, 0, 0), address="/only2", args="1", note="", to="второй"), manual=True)
    rx.settimeout(0.3)
    only = got_on(rx2).startswith(b"/only2") and got_on(rx) == b""
    pc, _ = parse_cues_text("00:00:01:00\tЗаметка\t/a\t1\t@Экран 1, Свет")
    say(both and only and pc and pc[0]["to"] == "Экран 1, Свет",
        "несколько Resolume: «всем» дошло до двух, «Куда: Второй» — только второму")
    # окно команды и доп. настройки
    ex, er = parse_extra_lines("/x 1\n+120 /y 0.5\nплохая строка")
    ta = typed_osc_args("1 0", "float")
    say(len(ex) == 2 and ex[1]["delay_ms"] == 120 and len(er) == 1 and ta == [1.0, 0.0]
        and isinstance(ta[0], float) and typed_osc_args("0.7", "int") == [0], "доп. команды и тип аргументов")
    app.extra_targets = []
    app._update_target()
    rx.settimeout(0.6)
    while got_on(rx):
        pass
    app._send_cue(dict(tc=(0, 0, 0, 0), address="/main", args="1", note="", to="", repeat=2, repeat_ms=30,
                       argtype="float", extra=[dict(delay_ms=0, address="/ex0", args=""),
                                               dict(delay_ms=80, address="/ex1", args="2")]), manual=True)
    got = []
    for _ in range(5):
        d = got_on(rx)
        if d:
            got.append(d.split(b"\0")[0])
    say(sorted(got) == [b"/ex0", b"/ex1", b"/main", b"/main"], "повтор и цепочка доп. команд: %s" % b" ".join(got).decode())
    app.cues = [dict(id=next(_ids), tc=(0, 0, 1, 0), address="/off", args="", note="", enabled=True, to="",
                     offset_ms=-100)]
    app._refresh_tree()
    fr = app._schedule(25)[0]
    say(fr == [22] and abs(app._sched_delay[id(app.cues[0])] - 0.02) < 1e-6, "сдвиг −100 мс: кадр 22 + 20 мс")
    app._open_cue(app.cues[0])
    dlg = app.cue_dlg
    dlg.v_note.set("Из окна")
    dlg.v_off.set("0")
    dlg.v_color.set("Зелёный")
    dlg._add_extra(dict(delay_ms=50, address="/z", args="1"))
    dlg._add_extra(dict(address="/ip", args="2", to="127.0.0.1:%d" % rx2.getsockname()[1]))
    dlg._add_extra()                                  # пустая строка — пропускается
    dlg.save()
    c0 = app.cues[0]
    say(c0["note"] == "Из окна" and "offset_ms" not in c0 and c0.get("color") == "green"
        and c0.get("extra") == [dict(delay_ms=50, address="/z", args="1"),
                                dict(delay_ms=0, address="/ip", args="2", to="127.0.0.1:%d" % rx2.getsockname()[1])]
        and "⚙" in app.tree.item(str(c0["id"]), "values")[2], "окно команды: открыть, изменить, сохранить")
    while got_on(rx2):
        pass
    app._send_cue(c0, manual=True)
    g2 = [got_on(rx2) for _ in range(2)]
    say(any(d.startswith(b"/ip") for d in g2), "доп. адрес со своим IP:порт дошёл до своего получателя")
    # три темы: окно пересобирается, команды остаются
    keep = list(app.cues)
    th_ok = []
    for key in THEMES:
        try:
            app._apply_theme(key)
            root.update()
            th_ok.append(len(app.tree.get_children()) == len(keep) and T["key"] == key)
        except Exception as e:
            th_ok.append(False)
            lines.append("     тема %s: %s" % (key, e))
    say(all(th_ok) and len(th_ok) == 3, "три темы (%s): окно пересобирается, список на месте" % ", ".join(THEMES))
    try:
        import setup_app
        say(setup_app.ver_tuple("2.0.10") > setup_app.ver_tuple("2.0.9") > setup_app.ver_tuple("1.9"),
            "модуль установки и обновлений")
    except Exception as e:
        say(False, "модуль установки и обновлений: %s" % e)
    app.cues = []
    app._new_project()
    # сетевые адаптеры: выбор источника и отправка через привязанный сокет
    ads = [dict(name="Шоу", ip="10.9.2.5", mask="255.255.255.0", up=True),
           dict(name="Офис", ip="192.168.0.100", mask="255.255.0.0", up=True)]
    app._ad_cache, app._ad_t = ads, time.monotonic() + 1e6
    app.adapters = ["10.9.2.5", "192.168.0.100"]
    s1 = app._sources_for("10.9.2.70") == ("10.9.2.5",) and app._sources_for("192.168.210.84") == ("192.168.0.100",)
    s2 = app._sources_for("172.16.0.9") == ("10.9.2.5", "192.168.0.100")
    app.adapters = []
    s3 = app._sources_for("10.9.2.70") == (None,) and len(subnet_hosts(ads[0])) == 254
    try:
        o = OscOut("127.0.0.1", rx.getsockname()[1], ("127.0.0.1",))
        rx.settimeout(0.5)
        while got_on(rx):
            pass
        o.send_message("/nic", [1, 0.5, "x"])
        s4 = got_on(rx).startswith(b"/nic")
        o.close()
    except Exception as e:
        s4 = False
        lines.append("     OscOut: %s" % e)
    app._ad_t = -99
    say(s1 and s2 and s3 and s4, "сетевые адаптеры: подсеть, несколько сетей, отправка с выбранного")
    say(cached_code_ok({"version": "2.1.1", "min_exe": "2.1.0"}, "2.1.0")
        and not cached_code_ok({"version": "2.1.1", "min_exe": "2.2.0"}, "2.1.0")
        and not cached_code_ok({"version": "2.1.0"}, "2.1.0")
        and not cached_code_ok({"version": "2.1.1", "bad": ["2.1.1"]}, "2.1.0"),
        "обновление кода без exe: выбор версии")
    m0 = (app.main_name, app.ip_var.get(), app.port_var.get())
    app.extra_targets = [dict(name="Лишний", ip="127.0.0.1", port=9, on=True)]
    app.remove_target(1)
    ok1 = app.extra_targets == []
    app.extra_targets = [dict(name="Новый главный", ip="127.0.0.2", port=9001, on=True)]
    app.remove_target(0)
    ok2 = app.main_name == "Новый главный" and app.ip_var.get() == "127.0.0.2" and app.extra_targets == []
    app.main_name, _ip, _pt = m0
    app.ip_var.set(_ip); app.port_var.set(_pt); app._update_target()
    say(app.cues == [] and not app.project_path and ok1 and ok2, "новый проект, удаление получателя и основного")
    app.f_tc.set("00:00:10:00")
    app._toggle_test()
    t0 = time.time()
    while time.time() - t0 < 1.5:
        root.update()
        time.sleep(0.02)
    say(app.cur_frames is not None and app.cur_frames > 250, "окно и тестовые часы работают")
    app._toggle_test()
    root.destroy()
    lines.append("ИТОГ: " + ("ВСЁ В ПОРЯДКЕ" if ok else "ЕСТЬ ОШИБКИ"))
    with open(report_path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    return 0 if ok else 1


# Версия самого exe (Python и библиотеки внутри). Код программы может быть новее — скачанный обновлением.
EXE_VER = os.environ.get("LTC2OSC_EXE_VER") or APP_VER
CODE_FILES = ("ltc_to_osc.py", "setup_app.py", "ui_skin.py")


def code_dir():
    return os.path.join(_config_dir(), "code")


def _vt(v):
    out = []
    for p in str(v).strip().lstrip("vV").split("."):
        n = "".join(ch for ch in p if ch.isdigit())
        out.append(int(n) if n else 0)
    return tuple(out + [0] * (4 - len(out)))


def cached_code_ok(meta, exe_ver):
    """Скачанный код подходит, если он новее exe, рассчитан на этот exe и не падал."""
    try:
        return (_vt(meta["version"]) > _vt(exe_ver) and _vt(exe_ver) >= _vt(meta.get("min_exe", "0"))
                and meta["version"] not in meta.get("bad", []))
    except Exception:
        return False


def run_cached_code():
    """Запустить код из обновления (папка настроек/code), если он новее встроенного. → True — отработал."""
    d = code_dir()
    try:
        with open(os.path.join(d, "meta.json"), encoding="utf-8") as fh:
            meta = json.load(fh)
    except Exception:
        return False
    if not cached_code_ok(meta, APP_VER) or not all(os.path.isfile(os.path.join(d, f)) for f in CODE_FILES):
        return False
    import runpy
    os.environ["LTC2OSC_CODE"] = meta["version"]
    os.environ["LTC2OSC_EXE_VER"] = APP_VER
    sys.path.insert(0, d)
    for m in ("setup_app", "ui_skin"):
        sys.modules.pop(m, None)
    try:
        runpy.run_path(os.path.join(d, "ltc_to_osc.py"), run_name="__main__")
        return True
    except SystemExit:
        raise
    except BaseException:
        import traceback
        try:
            with open(os.path.join(_config_dir(), "hang.log"), "a", encoding="utf-8") as fh:
                fh.write("\n==== %s код %s не запустился, работаю на встроенном %s ====\n%s"
                         % (time.strftime("%Y-%m-%d %H:%M:%S"), meta["version"], APP_VER, traceback.format_exc()))
            meta.setdefault("bad", []).append(meta["version"])
            with open(os.path.join(d, "meta.json"), "w", encoding="utf-8") as fh:
                json.dump(meta, fh)
        except Exception:
            pass
        sys.path.remove(d)
        for m in ("setup_app", "ui_skin"):
            sys.modules.pop(m, None)
        os.environ.pop("LTC2OSC_CODE", None)
        os.environ.pop("LTC2OSC_EXE_VER", None)
        return False


def main():
    code_run = bool(os.environ.get("LTC2OSC_CODE"))
    if IS_WIN and getattr(sys, "frozen", False) and "--selftest" not in sys.argv and not code_run:
        try:   # установка / обновление / удаление (Windows, собранный exe)
            import setup_app
            if setup_app.setup_flow(APP_VER, sys.argv[1:]):
                return
        except SystemExit:
            raise
        except Exception:
            pass
        if "--no-code-update" not in sys.argv and run_cached_code():
            return
    if "--selftest" in sys.argv:
        i = sys.argv.index("--selftest")
        path = sys.argv[i + 1] if len(sys.argv) > i + 1 else "selftest.txt"
        try:
            code = selftest(path)
        except Exception:
            import traceback
            with open(path, "w", encoding="utf-8") as fh:
                fh.write("\n".join(_ST_LINES) + "\nFAIL исключение:\n" + traceback.format_exc())
            code = 2
        sys.exit(code)
    if IS_WIN:
        try:   # чёткий интерфейс на мониторах с масштабированием
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
        try:   # своя иконка на панели задач, а не значок Python
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("LTC2OSC.App")
        except Exception:
            pass
    load_bundled_fonts()
    root = tk.Tk()
    set_window_icon(root)
    if IS_MAC:
        try:   # тёмное оформление окна на Mac
            root.tk.call("::tk::unsupported::MacWindowStyle", "appearance", root, "darkaqua")
        except tk.TclError:
            pass
    if IS_WIN:
        global UI_K
        try:
            UI_K = max(1.0, root.winfo_fpixels("1i") / 96.0)
        except tk.TclError:
            pass
    app = App(root)
    if IS_MAC:   # Cmd+Q тоже сохраняет настройки
        root.createcommand("tk::mac::Quit", app._on_close)
    root.mainloop()


if __name__ == "__main__":
    main()
