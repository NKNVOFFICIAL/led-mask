# -*- coding: utf-8 -*-
"""Скругления для ttk: кнопки, карточки, поля, флажки, ползунки, полосы прокрутки — картинками (9-slice).

Чистый Python (без numpy): маленькие PNG с альфой и сглаживанием, рисуются один раз на тему.
apply_skin(root, style, T, fonts) — вызывать после обычной настройки стилей темы.
"""
import base64
import math
import struct
import tkinter as tk
import zlib


def _hex(c):
    c = c.lstrip("#")
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))


def _png(w, h, px):
    """px: функция (x, y) -> (r, g, b, a 0..255)"""
    rows = bytearray()
    for y in range(h):
        rows.append(0)
        for x in range(w):
            rows.extend(px(x, y))

    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    raw = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(bytes(rows), 9)) + chunk(b"IEND", b""))
    return base64.b64encode(raw).decode("ascii")


def _sd_round(x, y, w, h, r):
    """Расстояние со знаком до скруглённого прямоугольника (0,0)-(w,h)."""
    cx, cy = w / 2.0, h / 2.0
    qx = abs(x - cx) - (cx - r)
    qy = abs(y - cy) - (cy - r)
    out = math.hypot(max(qx, 0.0), max(qy, 0.0))
    return out + min(max(qx, qy), 0.0) - r


def _cov(d):
    return max(0.0, min(1.0, 0.5 - d))


def _png_rows(w, h, rows):
    raw = bytearray()
    for r in rows:
        raw.append(0)
        raw.extend(r)

    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    data = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(bytes(raw), 6)) + chunk(b"IEND", b""))
    return base64.b64encode(data).decode("ascii")


def rounded(w, h, r, fill, border=None, bw=1.0, line=None, line_h=2, bg=None):
    """Скруглённый прямоугольник: заливка, рамка, линия снизу (для вкладок).
    bg — цвет под углами: картинка получается непрозрачной (Tk рисует такие в разы быстрее).
    Считаются только края (углы и рамка), середина строк и одинаковые строки копируются — быстро даже для
    больших картинок; большие картинки нужны, чтобы ttk растягивал их немногими кусками."""
    f = _hex(fill) if fill else None
    b = _hex(border) if border else None
    ln = _hex(line) if line else None
    g = _hex(bg) if bg else None

    def px(x, y):
        X, Y = x + 0.5, y + 0.5
        if ln and y >= h - line_h:
            return (ln[0], ln[1], ln[2], 255)
        a_out = _cov(_sd_round(X, Y, w, h, r))
        if b:
            a_in = _cov(_sd_round(X - bw, Y - bw, w - 2 * bw, h - 2 * bw, max(0.5, r - bw)))
            inner = f if f else (g or (0, 0, 0))
            c = [b[i] + (inner[i] - b[i]) * a_in for i in range(3)]
        else:
            c = list(f) if f else list(g or (0, 0, 0))
        if g:
            c = [g[i] + (c[i] - g[i]) * a_out for i in range(3)]
            return (int(c[0]), int(c[1]), int(c[2]), 255)
        return (int(c[0]), int(c[1]), int(c[2]), int(255 * a_out))
    e = int(math.ceil(max(r, bw) + 2))           # ширина «края», дальше по строке всё одинаково
    e = min(e, w // 2)
    rows = []
    cache = {}
    for y in range(h):
        edge_y = y < e or y >= h - max(e, line_h if ln else 0)
        key = None if edge_y else "mid"
        if key in cache:
            rows.append(cache[key])
            continue
        left = bytearray()
        for x in range(e):
            left.extend(px(x, y))
        mid = bytes(px(e, y)) * (w - 2 * e)
        right = bytearray()
        for x in range(w - e, w):
            right.extend(px(x, y))
        row = bytes(left) + mid + bytes(right)
        if key:
            cache[key] = row
        rows.append(row)
    return _png_rows(w, h, rows)


def _seg_dist(px_, py_, ax, ay, bx, by):
    vx, vy = bx - ax, by - ay
    t = max(0.0, min(1.0, ((px_ - ax) * vx + (py_ - ay) * vy) / (vx * vx + vy * vy)))
    return math.hypot(px_ - (ax + t * vx), py_ - (ay + t * vy))


def checkbox(s, fill, border, mark=None, radio=False, bg=None):
    f, b = _hex(fill), _hex(border)
    g = _hex(bg) if bg else None
    m = _hex(mark) if mark else None
    r = s / 2.0 if radio else 4.0

    def px(x, y):
        X, Y = x + 0.5, y + 0.5
        a_out = _cov(_sd_round(X, Y, s, s, r))
        if a_out <= 0 and not g:
            return (0, 0, 0, 0)
        a_in = _cov(_sd_round(X - 1, Y - 1, s - 2, s - 2, max(0.5, r - 1)))
        c = [b[i] + (f[i] - b[i]) * a_in for i in range(3)]
        if m:
            if radio:
                k = _cov(math.hypot(X - s / 2.0, Y - s / 2.0) - s * 0.2)
            else:
                d = min(_seg_dist(X, Y, s * .26, s * .52, s * .43, s * .69), _seg_dist(X, Y, s * .43, s * .69, s * .75, s * .33))
                k = _cov(d - 1.1)
            c = [c[i] + (m[i] - c[i]) * k for i in range(3)]
        if g:
            c = [g[i] + (c[i] - g[i]) * a_out for i in range(3)]
            return (int(c[0]), int(c[1]), int(c[2]), 255)
        return (int(c[0]), int(c[1]), int(c[2]), int(255 * a_out))
    return _png(s, s, px)


def circle(s, fill, ring=None, bg=None):
    f = _hex(fill)
    rg = _hex(ring) if ring else None
    g = _hex(bg) if bg else None

    def px(x, y):
        d = math.hypot(x + 0.5 - s / 2.0, y + 0.5 - s / 2.0) - (s / 2.0 - 0.5)
        a = _cov(d)
        if g:
            return (int(g[0] + (f[0] - g[0]) * a), int(g[1] + (f[1] - g[1]) * a), int(g[2] + (f[2] - g[2]) * a), 255)
        if a <= 0:
            return (0, 0, 0, 0)
        c = f
        if rg:
            k = _cov(math.hypot(x + 0.5 - s / 2.0, y + 0.5 - s / 2.0) - (s / 2.0 - 2.5))
            c = tuple(int(rg[i] + (f[i] - rg[i]) * k) for i in range(3))
        return (c[0], c[1], c[2], int(255 * a))
    return _png(s, s, px)


def _replace(layout, mapping):
    out = []
    for name, opts in layout:
        opts = dict(opts)
        if name in mapping:
            opts.pop("border", None)     # с этим ключом ttk не рисует текст поверх картинки
        if "children" in opts:
            opts["children"] = _replace(opts["children"], mapping)
        out.append((mapping.get(name, name), opts))
    return out


_N = [0]          # имена элементов ttk глобальны — счётчик на весь процесс
_BASE = {}        # исходные раскладки ttk (до замены), чтобы смена темы строилась от них


class Skin:
    def __init__(self, root):
        self.root = root
        self.imgs = {}

    def img(self, data):
        im = tk.PhotoImage(master=self.root, data=data)
        self.imgs[str(im)] = im
        return str(im)

    def element(self, st, base, states, border, sticky="nsew", padding=None):
        """states: [(state_spec или '', png)] — первым идёт обычное состояние."""
        _N[0] += 1
        name = "sk%d.%s" % (_N[0], base)
        first = self.img(states[0][1])
        spec = []
        for stt, png in states[1:]:
            spec.append((stt, self.img(png)))
        kw = {"border": border, "sticky": sticky}
        if padding is not None:
            kw["padding"] = padding
        if sticky != "":
            # картинка большая (для быстрой отрисовки), но минимальный размер виджета — только по краям
            b = border if isinstance(border, (tuple, list)) else (border, border)
            bx, by = (b[0], b[1]) if len(b) >= 2 else (b[0], b[0])
            kw["width"] = 2 * bx + 2
            kw["height"] = 2 * by + 2
        st.element_create(name, "image", first, *spec, **kw)
        return name


def apply_skin(root, st, T, F, scale=1.0):
    """Скругления для текущей темы. Возвращает Skin (держит ссылки на картинки).

    Картинки непрозрачные, углы запечены под фон, на котором стоит виджет:
      обычные стили — на карточке; «Bg.*» — на фоне страницы; «Head.*» — в шапке/нижней панели;
      флажки: «TCheckbutton» — на фоне, «Card.TCheckbutton» — на карточке.
    """
    sk = Skin(root)
    for nm in ("TButton", "TMenubutton", "Toolbutton", "TEntry", "TCombobox", "TSpinbox", "TCheckbutton", "TRadiobutton"):
        if nm not in _BASE:
            try:
                _BASE[nm] = st.layout(nm)
            except tk.TclError:
                pass
    k = max(1.0, float(scale))              # масштаб Windows: углы, флажки, ползунки крупнее

    def q(n):
        return int(round(n * k))
    R = q(7)
    S = 2 * R + 4
    BW, BH = q(120), q(44)        # большие картинки: ttk тянет середину кусками размером с неё
    CTX = (("", T["card"]), ("Bg.", T["bg"]), ("Head.", T["header"]))

    def set_layout(style, base_layout_of, top_from, el):
        lay = _BASE.get(base_layout_of)
        if lay is None:
            return
        st.layout(style, _replace(lay, {top_from: el}))

    def btn(bg, fill, hover, press, border=None, bhover=None):
        return [("", rounded(BW, BH, R, fill, border, bg=bg)),
                ("pressed", rounded(BW, BH, R, press, bhover or border, bg=bg)),
                ("active", rounded(BW, BH, R, hover, bhover or border, bg=bg))]

    variants = {
        "TButton": (T["button"], T["button_hover"], T["border"], T["border"], T["muted"]),
        "Accent.TButton": (T["accent"], T["accent_hover"], T["accent_hover"]),
        "Success.TButton": (T["success"], T["success_hover"], T["success_hover"]),
        "Danger.TButton": (T["danger"], T["danger_hover"], T["danger_hover"]),
        "Ghost.TButton": (T["button"], T["button_hover"], T["border"], T["border"], T["accent"]),
        "Icon.TButton": (T["field"], T["button_hover"], T["border"], T["border"], T["muted"]),
    }
    for pre, bg in CTX:
        for style, cols in variants.items():
            el = sk.element(st, "b", btn(bg, *cols), border=R + 1, padding=(q(6), q(3)))
            set_layout(pre + style, "TButton", "Button.border", el)
            st.configure(pre + style, background=bg)
        for style, cols in (("TMenubutton", variants["TButton"]), ("Accent.TMenubutton", variants["Accent.TButton"])):
            el = sk.element(st, "mb", btn(bg, *cols), border=R + 1, padding=(q(6), q(3)))
            set_layout(pre + style, "TMenubutton", "Menubutton.border", el)
            st.configure(pre + style, background=bg)
    hb = sk.element(st, "mb", btn(T["header"], T["header"], T["button_hover"], T["border"]), border=R + 1, padding=(q(6), q(3)))
    set_layout("Header.TMenubutton", "TMenubutton", "Menubutton.border", hb)
    st.configure("Header.TMenubutton", background=T["header"])
    st.configure("TButton", padding=(q(8), q(3)))
    for nm in ("Accent.TButton", "Success.TButton", "Danger.TButton"):
        st.configure(nm, padding=(q(10), q(4)))
    st.configure("Icon.TButton", padding=(q(3), 0), font=F["small"], width=0)
    st.configure("Ghost.TButton", padding=(q(8), q(3)))
    st.configure("TMenubutton", padding=(q(8), q(3)))

    # сегменты (на карточке и на фоне) и вкладки
    for style, bg in (("Toolbutton", T["card"]), ("Seg.Toolbutton", T["bg"])):
        seg = sk.element(st, "seg", [("", rounded(BW, BH, R, T["button"], T["border"], bg=bg)),
                                     ("selected", rounded(BW, BH, R, T["accent"], bg=bg)),
                                     ("active", rounded(BW, BH, R, T["button_hover"], T["border"], bg=bg))],
                         border=R + 1, padding=(q(6), q(3)))
        set_layout(style, "Toolbutton", "Toolbutton.border", seg)
    tab = sk.element(st, "tab", [("", rounded(BW, BH, 0, T["bg"])),
                                 ("selected", rounded(BW, BH, 0, T["bg"], line=T["accent"], line_h=q(2))),
                                 ("active", rounded(BW, BH, 0, T["bg"], line=T["border"], line_h=q(2)))], border=q(4))
    set_layout("Tab.Toolbutton", "Toolbutton", "Toolbutton.border", tab)

    # карточки (стоят на фоне страницы)
    card = sk.element(st, "card", [("", rounded(q(400), q(300), q(10), T["card"], T["border"], bg=T["bg"]))], border=q(10) + 1)
    st.layout("Card.TFrame", [(card, {"sticky": "nsew"})])
    st.configure("Card.TFrame", background=T["card"])
    cardsel = sk.element(st, "cards", [("", rounded(q(400), q(300), q(10), T["card"], T["accent"], bw=1.5 * k, bg=T["bg"]))], border=q(10) + 1)
    st.layout("CardSel.TFrame", [(cardsel, {"sticky": "nsew"})])
    st.configure("CardSel.TFrame", background=T["card"])

    # чипы в шапке
    for nm, fill, fg in (("Chip", T["chip"], T["fg"]), ("ChipOk", T.get("chip_ok", T["chip"]), T["success"]),
                         ("ChipWarn", T.get("chip_warn", T["chip"]), T["warn"]),
                         ("ChipBad", T.get("chip_bad", T["chip"]), T["danger"]),
                         ("ChipAccent", T.get("chip_warn", T["chip"]), T["accent"])):
        el = sk.element(st, "chip", [("", rounded(BW, BH, R, fill, bg=T["header"]))], border=R + 1)
        st.layout(nm + ".TLabel", [(el, {"sticky": "nsew", "children": [
            ("Label.padding", {"sticky": "nsew", "children": [("Label.label", {"sticky": "nsew"})]})]})])
        st.configure(nm + ".TLabel", background=fill, foreground=fg, font=F["small_bold"], padding=(q(10), q(4)))

    # поля ввода
    for pre, bg in CTX:
        fld = [("", rounded(BW * 2, BH, R, T["field"], T["border"], bg=bg)),
               ("focus", rounded(BW * 2, BH, R, T["field"], T["accent"], bg=bg)),
               ("disabled", rounded(BW * 2, BH, R, T["bg"], T["border"], bg=bg))]
        for style, top in (("TEntry", "Entry.field"), ("TCombobox", "Combobox.field"), ("TSpinbox", "Spinbox.field")):
            el = sk.element(st, "f", fld, border=R + 1, padding=(q(5), q(3)))
            set_layout(pre + style, style, top, el)
            st.configure(pre + style, padding=(q(3), q(1)), bordercolor=T["field"], lightcolor=T["field"],
                         darkcolor=T["field"], background=T["field"])
            st.map(pre + style, bordercolor=[("focus", T["field"])], lightcolor=[("focus", T["field"])],
                   darkcolor=[("focus", T["field"])], background=[("active", T["field"]), ("pressed", T["field"])])

    # флажки и переключатели: обычные — на фоне, Card.* — на карточке
    CB = q(16)
    for pre, bg in (("", T["bg"]), ("Card.", T["card"])):
        cb = sk.element(st, "cb", [("", checkbox(CB, T["field"], T["border"], bg=bg)),
                                   ("selected", checkbox(CB, T["accent"], T["accent"], T["on_accent"], bg=bg)),
                                   ("active", checkbox(CB, T["field"], T["muted"], bg=bg))], border=0, sticky="")
        rb = sk.element(st, "rb", [("", checkbox(CB, T["field"], T["border"], radio=True, bg=bg)),
                                   ("selected", checkbox(CB, T["field"], T["accent"], T["accent"], radio=True, bg=bg)),
                                   ("active", checkbox(CB, T["field"], T["muted"], radio=True, bg=bg))], border=0, sticky="")
        for base, ind, el in (("TCheckbutton", "Checkbutton.indicator", cb), ("TRadiobutton", "Radiobutton.indicator", rb)):
            set_layout(pre + base, base, ind, el)
            st.configure(pre + base, indicatormargin=(0, 0, q(8), 0))

    # ползунок: обычный — на карточке, Head.* — в шапке
    for pre, bg in (("", T["card"]), ("Head.", T["header"]), ("Bg.", T["bg"])):
        tr = sk.element(st, "trough", [("", rounded(q(240), q(6), q(3), T["field"], T["border"], bg=bg))],
                        border=(q(4), q(2)), sticky="ew")
        sl = sk.element(st, "slider", [("", circle(q(16), T["accent"], bg=bg)), ("active", circle(q(16), T["accent_hover"], bg=bg)),
                                       ("pressed", circle(q(16), T["accent_hover"], bg=bg))], border=0, sticky="")
        st.layout(pre + "Horizontal.TScale", [(tr, {"sticky": "ew", "children": [(sl, {"side": "left", "sticky": ""})]})])
        st.configure(pre + "Horizontal.TScale", background=bg)

    # полосы прокрутки: тонкие, без стрелок
    th_v = sk.element(st, "thumb", [("", rounded(q(8), q(160), q(4), T["border"], bg=T["card"])),
                                    ("active", rounded(q(8), q(160), q(4), T["muted"], bg=T["card"]))], border=(0, q(5)), sticky="nsew")
    th_h = sk.element(st, "thumb", [("", rounded(q(160), q(8), q(4), T["border"], bg=T["card"])),
                                    ("active", rounded(q(160), q(8), q(4), T["muted"], bg=T["card"]))], border=(q(5), 0), sticky="nsew")
    st.layout("Vertical.TScrollbar", [("Vertical.Scrollbar.trough", {"sticky": "ns", "children": [
        (th_v, {"expand": "1", "sticky": "nswe"})]})])
    st.layout("Horizontal.TScrollbar", [("Horizontal.Scrollbar.trough", {"sticky": "ew", "children": [
        (th_h, {"expand": "1", "sticky": "nswe"})]})])
    for o in ("Vertical", "Horizontal"):
        st.configure(o + ".TScrollbar", troughcolor=T["card"], background=T["card"], bordercolor=T["card"],
                     lightcolor=T["card"], darkcolor=T["card"], width=q(10), arrowsize=q(10))
    return sk
